from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_file
import sqlite3
import os
from werkzeug.utils import secure_filename
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
import random
import time
import cv2
import numpy as np
from deepface import DeepFace
from skimage import io as skio
from skimage.filters import laplace
import speech_recognition as sr
import re
import datetime
import base64
from Levenshtein import distance as levenshtein_distance
import uuid
from PIL import Image, ImageDraw, ImageFont
import tensorflow as tf
from tensorflow.keras.applications.efficientnet import EfficientNetB0, preprocess_input
import io
import json
import librosa
import noisereduce as nr
from pydub import AudioSegment
import logging
import html
from perlin_noise import PerlinNoise
from scipy.ndimage import map_coordinates


# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

app = Flask(__name__)
app.secret_key = os.urandom(24).hex()
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['CAPTCHA_FOLDER'] = 'static/captchas'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'wav', 'mp3'}

# Email configuration (replace with your credentials)
EMAIL_ADDRESS = 'pittalasandeep124@gmail.com'
EMAIL_PASSWORD = 'gisy baks rkou vpey'

# Ensure directories exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['CAPTCHA_FOLDER'], exist_ok=True)

class ImageComparison:
    def __init__(self):
        self.model = EfficientNetB0(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
        self.model = tf.keras.models.Model(inputs=self.model.input, outputs=self.model.output)

    def preprocess_image(self, image_path):
        try:
            img = Image.open(image_path).resize((224, 224))
            img_array = np.array(img)
            img_array = np.expand_dims(img_array, axis=0)
            img_array = preprocess_input(img_array)
            return img_array
        except Exception as e:
            logging.error(f"Error preprocessing image: {e}")
            return None

    def get_features(self, image_path):
        img = self.preprocess_image(image_path)
        if img is None:
            return None
        features = self.model.predict(img)
        return features.flatten()

    def compare_images(self, image1_path, image2_path):
        try:
            features1 = self.get_features(image1_path)
            features2 = self.get_features(image2_path)
            if features1 is None or features2 is None:
                return False
            similarity = np.dot(features1, features2) / (np.linalg.norm(features1) * np.linalg.norm(features2))
            return similarity > 0.85
        except Exception as e:
            logging.error(f"Image comparison error: {e}")
            return False

image_comparator = ImageComparison()

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def validate_image(image_path, enforce_face=True):
    try:
        img = skio.imread(image_path)
        gray = skio.color.rgb2gray(img)
        brightness = np.mean(gray) * 255
        if brightness < 60:
            return False, "Image is too dark"
        laplacian_var = laplace(gray).var()
        if laplacian_var < 100:
            return False, "Image is too blurry"
        if enforce_face:
            faces = DeepFace.extract_faces(img_path=image_path, detector_backend='opencv', enforce_detection=False)
            face_count = len(faces)
            if face_count != 1:
                return False, f"Exactly one face must be detected, found {face_count}"
        return True, ""
    except Exception as e:
        logging.error(f"Image validation failed: {e}")
        return False, f"Image validation failed: {str(e)}"

def adjust_image_brightness_contrast(image_path):
    try:
        img = cv2.imread(image_path)
        img_yuv = cv2.cvtColor(img, cv2.COLOR_BGR2YUV)
        img_yuv[:,:,0] = cv2.equalizeHist(img_yuv[:,:,0])
        img_adjusted = cv2.cvtColor(img_yuv, cv2.COLOR_YUV2BGR)
        img_adjusted = cv2.bilateralFilter(img_adjusted, 9, 75, 75)
        cv2.imwrite(image_path, img_adjusted)
    except Exception as e:
        logging.error(f"Image adjustment failed: {e}")

def enhance_audio(audio_path):
    try:
        audio = AudioSegment.from_file(audio_path)
        normalized_audio = audio.normalize()
        y, sr = librosa.load(audio_path)
        reduced_noise = nr.reduce_noise(y=y, sr=sr)
        enhanced_path = audio_path.replace('.wav', '_enhanced.wav')
        librosa.output.write_wav(enhanced_path, reduced_noise, sr)
        return enhanced_path
    except Exception as e:
        logging.error(f"Audio enhancement failed: {e}")
        return audio_path

def extract_text_from_audio(audio_path):
    try:
        enhanced_path = enhance_audio(audio_path)
        recognizer = sr.Recognizer()
        with sr.AudioFile(enhanced_path) as source:
            audio_data = recognizer.record(source)
            text = recognizer.recognize_google(audio_data)
            return text.lower(), 1.0
    except Exception as e:
        logging.error(f"Audio transcription failed: {e}")
        return "", 0.0

def generate_badge(test_name, user_name, score, certificate_id, achievement_type):
    img = Image.new('RGB', (800, 600), color='#ffffff')
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype('static/fonts/Roboto-Bold.ttf', 48)
        small_font = ImageFont.truetype('static/fonts/Roboto-Regular.ttf', 32)
    except:
        font = ImageFont.load_default()
        small_font = ImageFont.load_default()
    
    # Background gradient
    for y in range(600):
        r = int(232 + (255-232) * y/600)
        g = int(244 + (255-244) * y/600)
        b = int(248 + (255-248) * y/600)
        draw.line([(0, y), (800, y)], fill=(r, g, b))
    
    # Border and text
    draw.rectangle([(50, 50), (750, 550)], outline='#0288d1', width=8)
    draw.ellipse([(30, 30, 70, 70), (730, 30, 770, 70), (30, 530, 70, 570), (730, 530, 770, 570)], fill='#0288d1')
    draw.text((400, 120), f"Certificate of {achievement_type}", font=font, fill='#01579b', anchor='mm')
    draw.text((400, 220), user_name, font=small_font, fill='#01579b', anchor='mm')
    draw.text((400, 300), test_name, font=small_font, fill='#01579b', anchor='mm')
    draw.text((400, 380), f"Score: {score}%", font=small_font, fill='#01579b', anchor='mm')
    draw.text((400, 460), f"ID: {certificate_id[:8]}", font=small_font, fill='#01579b', anchor='mm')
    
    badge_path = os.path.join(app.config['UPLOAD_FOLDER'], f"badge_{certificate_id}.png")
    img.save(badge_path)
    return badge_path

def send_email(to_email, subject, body, html_body=None, attachment_path=None):
    msg = MIMEMultipart()
    msg['From'] = EMAIL_ADDRESS
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))
    if html_body:
        msg.attach(MIMEText(html_body, 'html'))
    if attachment_path:
        with open(attachment_path, 'rb') as f:
            img = MIMEImage(f.read())
            img.add_header('Content-Disposition', 'attachment', filename=os.path.basename(attachment_path))
            msg.attach(img)
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        server.sendmail(EMAIL_ADDRESS, to_email, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        logging.error(f"Email sending failed: {e}")
        return False

def validate_password(password):
    return (len(password) >= 6 and
            re.search(r"[A-Z]", password) and
            re.search(r"[a-z]", password) and
            re.search(r"\d", password) and
            re.search(r"[!@#$%^&*(),.?\":{}|<>]", password))

def validate_email(email):
    return bool(re.match(r'^[a-zA-Z0-9._%+-]+@gmail\.com$', email))

def validate_mobile(mobile):
    return len(mobile) == 10 and mobile.isdigit()

def sanitize_input(input_str):
    return html.escape(str(input_str).strip())

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn



def generate_captcha():
    # Generate random 6-digit CAPTCHA text
    captcha_text = str(random.randint(100000, 999999))
    captcha_filename = f"captcha_{uuid.uuid4()}.png"
    captcha_path = os.path.join(app.config['CAPTCHA_FOLDER'], captcha_filename)

    try:
        # Create a 400x120 white image
        img = Image.new('RGB', (400, 120), color=(255, 255, 255))
        draw = ImageDraw.Draw(img)

        # Add random noise dots
        for _ in range(1500):
            x = random.randint(0, 399)
            y = random.randint(0, 119)
            draw.point((x, y), fill=(random.randint(100, 200), random.randint(100, 200), random.randint(100, 200)))

        # Use default font with larger size
        try:
            font = ImageFont.load_default().font_variant(size=60)  # Scale default font to ~60px
        except AttributeError:
            font = ImageFont.load_default()  # Fallback for older PIL versions
            logging.warning("Font scaling not supported, using default size")

        # Draw CAPTCHA text with slight rotation
        for i, char in enumerate(captcha_text):
            x = 50 + i * 50  # Space characters evenly
            y = 30
            char_img = Image.new('RGBA', (80, 80), (0, 0, 0, 0))
            char_draw = ImageDraw.Draw(char_img)
            color = (random.randint(0, 80), random.randint(0, 80), random.randint(0, 80))
            char_draw.text((10, 10), char, font=font, fill=color + (255,))
            angle = random.uniform(-15, 15)  # Slight rotation
            char_img = char_img.rotate(angle, expand=1)
            img.paste(char_img, (x, y), char_img)

        # Add random lines
        for _ in range(4):
            x1, y1 = random.randint(0, 400), random.randint(0, 120)
            x2, y2 = random.randint(0, 400), random.randint(0, 120)
            draw.line((x1, y1, x2, y2), fill=(random.randint(100, 200), random.randint(100, 200), random.randint(100, 200)), width=2)

        # Save the CAPTCHA image
        img.save(captcha_path, 'PNG')
    except Exception as e:
        logging.error(f"Failed to generate CAPTCHA: {e}")
        raise RuntimeError("CAPTCHA generation failed")

    # Clean up old CAPTCHA files (older than 1 hour)
    try:
        now = time.time()
        for f in os.listdir(app.config['CAPTCHA_FOLDER']):
            f_path = os.path.join(app.config['CAPTCHA_FOLDER'], f)
            if os.path.isfile(f_path) and now - os.path.getmtime(f_path) > 3600:
                os.remove(f_path)
    except Exception as e:
        logging.error(f"Failed to clean up CAPTCHA files: {e}")

    # Store CAPTCHA text in session
    session['captcha_text'] = captcha_text
    return captcha_filename
def profile_logo():
    default_logo = 'images/default_admin_logo.png'
    if 'user_id' not in session:
        return default_logo
    try:
        with get_db_connection() as conn:
            user = conn.execute('SELECT profile_image, role FROM users WHERE id = ?', (session['user_id'],)).fetchone()
            if user:
                if user['role'] == 'admin':
                    return default_logo
                elif user['role'] == 'user' and user['profile_image']:
                    return user['profile_image'].replace(app.static_folder + '/', '')
                else:
                    return default_logo
            else:
                return default_logo
    except Exception as e:
        logging.error(f"Error fetching profile logo: {e}")
        return default_logo

@app.route('/')
def index():
    return render_template('index.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}), logo=profile_logo())

@app.route('/about')
def about():
    return render_template('about.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}), logo=profile_logo())

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        email = sanitize_input(request.form.get('email'))
        subject = sanitize_input(request.form.get('subject'))
        message = sanitize_input(request.form.get('message'))
        if not all([email, subject, message]):
            flash('All fields are required', 'danger')
            return render_template('contact.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}),logo=profile_logo())
        if not validate_email(email):
            flash('Invalid Gmail address', 'danger')
            return render_template('contact.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}),logo=profile_logo())
        try:
            with get_db_connection() as conn:
                conn.execute('INSERT INTO queries (email, subject, message) VALUES (?, ?, ?)', (email, subject, message))
                conn.commit()
            html_body = """
            <div style="font-family: Arial, sans-serif; padding: 20px; background: linear-gradient(to bottom, #e8f4f8, #ffffff); border-radius: 10px;">
                <h2 style="color: #2c5282; text-align: center;">Query Received</h2>
                <p style="color: #4a5568;">Thank you for contacting us. We have received your query and will respond soon.</p>
                <p style="color: #4a5568; text-align: center;">&copy; 2025 Your Platform</p>
            </div>
            """
            send_email(email, "Query Received", "Your query has been received.", html_body)
            send_email('sandeeppittala2707@gmail.com', "New Query", f"Email: {email}\nSubject: {subject}\nMessage: {message}")
            flash('Query submitted successfully', 'success')
            return redirect(url_for('contact'))
        except Exception as e:
            logging.error(f"Contact form error: {e}")
            flash('An error occurred. Please try again.', 'danger')
    return render_template('contact.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}), logo=profile_logo())

@app.route('/login', methods=['GET', 'POST'])
def login():
    captcha_filename = generate_captcha()
    if request.method == 'POST':
        captcha_answer = request.form.get('captcha_answer', '').strip()
        if captcha_answer != session.get('captcha_text'):
            flash('Invalid CAPTCHA', 'danger')
            return render_template('login.html', captcha_image=captcha_filename)
        email = sanitize_input(request.form.get('email'))
        password = request.form.get('password')
        role = request.form.get('role')
        if not all([email, password, role]):
            flash('All fields are required', 'danger')
            return render_template('login.html', captcha_image=captcha_filename)
        if not validate_email(email):
            flash('Invalid Gmail address', 'danger')
            return render_template('login.html', captcha_image=captcha_filename)
        try:
            with get_db_connection() as conn:
                if role == 'user':
                    user = conn.execute('SELECT * FROM users WHERE email = ? AND password = ?', (email, password)).fetchone()
                else:
                    user = conn.execute('SELECT * FROM admins WHERE email = ? AND password = ?', (email, password)).fetchone()
                if user:
                    session['user_id'] = user['id']
                    session['role'] = role
                    session['user'] = {
                        'name': user['name'],
                        'username': user['username'],
                        'profile_image': user['profile_image'] if role == 'user' else 'static/images/admin.png',
                        'hall_ticket': user.get('hall_ticket', '') if role == 'user' else ''
                    }
                    flash('Login successful', 'success')
                    return redirect(url_for('user_dashboard' if role == 'user' else 'admin_dashboard'))
                else:
                    flash('Invalid email or password', 'danger')
        except Exception as e:
            logging.error(f"Login error: {e}")
            flash('An error occurred. Please try again.', 'danger')
    return render_template('login.html', captcha_image=captcha_filename,logo=profile_logo())

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    step = session.get('forgot_step', 1)
    email = session.get('forgot_email', '')
    if request.method == 'POST':
        if step == 1:
            email = sanitize_input(request.form.get('email'))
            if not validate_email(email):
                flash('Invalid Gmail address', 'danger')
                return render_template('forgot_password.html', step=1, email=email)
            try:
                with get_db_connection() as conn:
                    user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
                    if user:
                        otp = str(random.randint(100000, 999999))
                        session['otp'] = otp
                        session['otp_email'] = email
                        session['otp_time'] = time.time()
                        session['forgot_step'] = 2
                        session['forgot_email'] = email
                        html_body = """
                        <div style="font-family: Arial, sans-serif; padding: 20px; background: linear-gradient(to bottom, #e8f4f8, #ffffff); border-radius: 10px;">
                            <h2 style="color: #2c5282; text-align: center;">Password Reset OTP</h2>
                            <p style="color: #4a5568;">Your OTP is <strong>{}</strong>. It is valid for 5 minutes.</p>
                            <p style="color: #4a5568; text-align: center;">&copy; 2025 Your Platform</p>
                        </div>
                        """.format(otp)
                        send_email(email, "Password Reset OTP", f"Your OTP is {otp}", html_body)
                        flash('OTP sent to your email', 'success')
                    else:
                        flash('Email not found', 'danger')
            except Exception as e:
                logging.error(f"Forgot password error: {e}")
                flash('An error occurred. Please try again.', 'danger')
        elif step == 2:
            otp = request.form.get('otp').strip()
            if 'resend' in request.form:
                otp = str(random.randint(100000, 999999))
                session['otp'] = otp
                session['otp_time'] = time.time()
                html_body = """
                <div style="font-family: Arial, sans-serif; padding: 20px; background: linear-gradient(to bottom, #e8f4f8, #ffffff); border-radius: 10px;">
                    <h2 style="color: #2c5282; text-align: center;">Password Reset OTP</h2>
                    <p style="color: #4a5568;">Your new OTP is <strong>{}</strong>. It is valid for 5 minutes.</p>
                    <p style="color: #4a5568; text-align: center;">&copy; 2025 Your Platform</p>
                </div>
                """.format(otp)
                send_email(session['otp_email'], "Password Reset OTP", f"Your OTP is {otp}", html_body)
                flash('OTP resent', 'success')
            elif otp == session.get('otp') and time.time() - session.get('otp_time') < 300:
                session['forgot_step'] = 3
                return redirect(url_for('reset_password'))
            else:
                flash('Invalid or expired OTP', 'danger')
    remaining_time = 300 - (time.time() - session.get('otp_time', time.time())) if step == 2 else 0
    return render_template('forgot_password.html', step=step, email=email, remaining_time=max(0, remaining_time),logo=profile_logo())

@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    if 'otp_email' not in session:
        flash('Session expired. Please start over.', 'danger')
        return redirect(url_for('forgot_password'))
    if request.method == 'POST':
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
        elif not validate_password(password):
            flash('Password must be at least 6 characters with uppercase, lowercase, digit, and special character', 'danger')
        else:
            try:
                with get_db_connection() as conn:
                    conn.execute('UPDATE users SET password = ? WHERE email = ?', (password, session['otp_email']))
                    conn.commit()
                flash('Password reset successfully', 'success')
                session.clear()
                return redirect(url_for('login'))
            except Exception as e:
                logging.error(f"Reset password error: {e}")
                flash('An error occurred. Please try again.', 'danger')
    return render_template('reset_password.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    captcha_filename = generate_captcha()
    step = session.get('register_step', 1)
    if request.method == 'POST':
        captcha_answer = request.form.get('captcha_answer', '').strip()
        if captcha_answer != session.get('captcha_text'):
            flash('Invalid CAPTCHA', 'danger')
            return render_template('register.html', step=step, data=session.get('register_data', {}), captcha_image=captcha_filename)
        if step == 1:
            data = {
                'name': sanitize_input(request.form.get('name', '')),
                'email': sanitize_input(request.form.get('email', '')),
                'username': sanitize_input(request.form.get('username', '')),
                'mobile': sanitize_input(request.form.get('mobile', '')),
                'degree': sanitize_input(request.form.get('degree', '')),
                'course': sanitize_input(request.form.get('course', '')),
                'college': sanitize_input(request.form.get('college', '')),
                'branch': sanitize_input(request.form.get('branch', '')),
                'hall_ticket': sanitize_input(request.form.get('hall_ticket', '')),
                'semester': sanitize_input(request.form.get('semester', '')),
                'cgpa': sanitize_input(request.form.get('cgpa', '')),
                'location': sanitize_input(request.form.get('location', '')),
                'address': sanitize_input(request.form.get('address', '')),
                'state': sanitize_input(request.form.get('state', '')),
            }
            if not all(data.values()):
                flash('All fields are required', 'danger')
            elif not validate_email(data['email']):
                flash('Email must be a valid Gmail address', 'danger')
            elif not validate_mobile(data['mobile']):
                flash('Mobile number must be exactly 10 digits', 'danger')
            else:
                try:
                    with get_db_connection() as conn:
                        existing = conn.execute('SELECT * FROM users WHERE email = ? OR username = ?', (data['email'], data['username'])).fetchone()
                        if existing:
                            flash('Email or username already exists', 'danger')
                        else:
                            session['register_data'] = data
                            session['register_step'] = 2
                            flash('Please upload or capture images', 'info')
                except Exception as e:
                    logging.error(f"Register step 1 error: {e}")
                    flash('An error occurred. Please try again.', 'danger')
        elif step == 2:
            profile_image = request.files.get('profile_image')
            id_card_image = request.files.get('id_card_image')
            profile_data = request.form.get('profile_image_data')
            id_card_data = request.form.get('id_card_image_data')
            profile_path = id_card_path = None
            if profile_image and allowed_file(profile_image.filename):
                profile_filename = secure_filename(profile_image.filename)
                profile_path = os.path.join(app.config['UPLOAD_FOLDER'], f"profile_{uuid.uuid4()}_{profile_filename}")
                profile_image.save(profile_path)
                adjust_image_brightness_contrast(profile_path)
                valid, msg = validate_image(profile_path)
                if not valid:
                    flash(f"Profile image: {msg}", 'danger')
                    return render_template('register.html', step=2, data=session.get('register_data', {}), captcha_image=captcha_filename)
            elif profile_data:
                profile_data = profile_data.split(',')[1]
                profile_path = os.path.join(app.config['UPLOAD_FOLDER'], f"profile_{uuid.uuid4()}.png")
                with open(profile_path, 'wb') as f:
                    f.write(base64.b64decode(profile_data))
                adjust_image_brightness_contrast(profile_path)
                valid, msg = validate_image(profile_path)
                if not valid:
                    flash(f"Profile image: {msg}", 'danger')
                    return render_template('register.html', step=2, data=session.get('register_data', {}), captcha_image=captcha_filename)
            if id_card_image and allowed_file(id_card_image.filename):
                id_card_filename = secure_filename(id_card_image.filename)
                id_card_path = os.path.join(app.config['UPLOAD_FOLDER'], f"id_card_{uuid.uuid4()}_{id_card_filename}")
                id_card_image.save(id_card_path)
                adjust_image_brightness_contrast(id_card_path)
                valid, msg = validate_image(id_card_path, enforce_face=False)
                if not valid:
                    flash(f"ID card image: {msg}", 'danger')
                    return render_template('register.html', step=2, data=session.get('register_data', {}), captcha_image=captcha_filename)
            elif id_card_data:
                id_card_data = id_card_data.split(',')[1]
                id_card_path = os.path.join(app.config['UPLOAD_FOLDER'], f"id_card_{uuid.uuid4()}.png")
                with open(id_card_path, 'wb') as f:
                    f.write(base64.b64decode(id_card_data))
                adjust_image_brightness_contrast(id_card_path)
                valid, msg = validate_image(id_card_path, enforce_face=False)
                if not valid:
                    flash(f"ID card image: {msg}", 'danger')
                    return render_template('register.html', step=2, data=session.get('register_data', {}), captcha_image=captcha_filename)
            if profile_path and id_card_path:
                session['profile_path'] = profile_path
                session['id_card_path'] = id_card_path
                otp = str(random.randint(100000, 999999))
                session['otp'] = otp
                session['otp_email'] = session['register_data']['email']
                session['otp_time'] = time.time()
                html_body = """
                <div style="font-family: Arial, sans-serif; padding: 20px; background: linear-gradient(to bottom, #e8f4f8, #ffffff); border-radius: 10px;">
                    <h2 style="color: #2c5282; text-align: center;">Registration OTP</h2>
                    <p style="color: #4a5568;">Your OTP is <strong>{}</strong>. It is valid for 5 minutes.</p>
                    <p style="color: #4a5568; text-align: center;">&copy; 2025 Your Platform</p>
                </div>
                """.format(otp)
                send_email(session['otp_email'], "Registration OTP", f"Your OTP is {otp}", html_body)
                session['register_step'] = 3
                return redirect(url_for('verify_otp'))
            else:
                flash('Both images are required', 'danger')
    return render_template('register.html', step=step, data=session.get('register_data', {}), captcha_image=captcha_filename,logo=profile_logo())

@app.route('/verify_otp', methods=['GET', 'POST'])
def verify_otp():
    if 'otp_email' not in session:
        flash('Session expired. Please start over.', 'danger')
        return redirect(url_for('register'))
    if request.method == 'POST':
        otp = request.form.get('otp').strip()
        if 'resend' in request.form:
            otp = str(random.randint(100000, 999999))
            session['otp'] = otp
            session['otp_time'] = time.time()
            html_body = """
            <div style="font-family: Arial, sans-serif; padding: 20px; background: linear-gradient(to bottom, #e8f4f8, #ffffff); border-radius: 10px;">
                <h2 style="color: #2c5282; text-align: center;">Registration OTP</h2>
                <p style="color: #4a5568;">Your new OTP is <strong>{}</strong>. It is valid for 5 minutes.</p>
                <p style="color: #4a5568; text-align: center;">&copy; 2025 Your Platform</p>
            </div>
            """.format(otp)
            send_email(session['otp_email'], "Registration OTP", f"Your OTP is {otp}", html_body)
            flash('OTP resent', 'success')
        elif otp == session.get('otp') and time.time() - session.get('otp_time') < 300:
            session['register_step'] = 4
            return redirect(url_for('set_password'))
        else:
            flash('Invalid or expired OTP', 'danger')
    remaining_time = 300 - (time.time() - session.get('otp_time', time.time()))
    return render_template('verify_otp.html', remaining_time=max(0, remaining_time))

@app.route('/set_password', methods=['GET', 'POST'])
def set_password():
    if 'otp_email' not in session or 'register_data' not in session:
        flash('Session expired. Please start over.', 'danger')
        return redirect(url_for('register'))
    if request.method == 'POST':
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
        elif not validate_password(password):
            flash('Password must be at least 6 characters with uppercase, lowercase, digit, and special character', 'danger')
        else:
            try:
                with get_db_connection() as conn:
                    data = session['register_data']
                    conn.execute('''INSERT INTO users (name, email, username, mobile, degree, course, college, branch, hall_ticket, semester, cgpa, location, address, state, profile_image, id_card_image, password)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                                    (data['name'], data['email'], data['username'], data['mobile'], data['degree'], data['course'], data['college'], data['branch'], data['hall_ticket'], data['semester'], data['cgpa'], data['location'], data['address'], data['state'], session['profile_path'], session['id_card_path'], password))
                    conn.commit()
                flash('Registration successful. Please login.', 'success')
                session.clear()
                return redirect(url_for('login'))
            except Exception as e:
                logging.error(f"Set password error: {e}")
                flash('An error occurred. Please try again.', 'danger')
    return render_template('set_password.html')

@app.route('/user_dashboard')
def user_dashboard():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            tests = conn.execute('''
                SELECT t.id, t.name, t.duration, te.date, te.start_time, te.end_time
                FROM tests t
                JOIN test_enrollments te ON t.id = te.test_id
                LEFT JOIN test_attempts ta ON t.id = ta.test_id AND ta.user_id = ?
                WHERE te.user_id = ? AND ta.id IS NULL AND te.end_time > ?
            ''', (session['user_id'], session['user_id'], datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))).fetchall()
            challenges = conn.execute('''
                SELECT c.id, c.name, c.duration, ce.date, ce.start_time, ce.end_time
                FROM challenges c
                JOIN challenge_enrollments ce ON c.id = ce.challenge_id
                LEFT JOIN challenge_attempts ca ON c.id = ca.challenge_id AND ca.user_id = ?
                WHERE ce.user_id = ? AND ca.id IS NULL AND ce.end_time > ?
            ''', (session['user_id'], session['user_id'], datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))).fetchall()
        return render_template('user_dashboard.html', tests=tests, challenges=challenges, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())
    except Exception as e:
        logging.error(f"User dashboard error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('login'))

@app.route('/my_learning')
def my_learning():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            test_attempts = conn.execute('''
                SELECT ta.id, t.name, ta.score, ta.date, 'Test' as type, ta.certificate_id
                FROM test_attempts ta
                JOIN tests t ON ta.test_id = t.id
                WHERE ta.user_id = ?
            ''', (session['user_id'],)).fetchall()
            challenge_attempts = conn.execute('''
                SELECT ca.id, c.name, ca.score, ca.date, 'Challenge' as type, ca.certificate_id
                FROM challenge_attempts ca
                JOIN challenges c ON ca.challenge_id = c.id
                WHERE ca.user_id = ?
            ''', (session['user_id'],)).fetchall()
            attempts = test_attempts + challenge_attempts
        return render_template('my_learning.html', attempts=attempts, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())
    except Exception as e:
        logging.error(f"My learning error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('login'))

@app.route('/view_attempt/<int:attempt_id>/<string:type>')
def view_attempt(attempt_id, type):
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            if type == 'Test':
                attempt = conn.execute('''
                    SELECT ta.score, t.name, t.duration, ta.certificate_id
                    FROM test_attempts ta
                    JOIN tests t ON ta.test_id = t.id
                    WHERE ta.id = ? AND ta.user_id = ?
                ''', (attempt_id, session['user_id'])).fetchone()
                answers = conn.execute('''
                    SELECT tq.question_text, tq.correct_option, ta.answer
                    FROM test_answers ta
                    JOIN test_questions tq ON ta.question_id = tq.id
                    WHERE ta.attempt_id = ?
                ''', (attempt_id,)).fetchall()
                correct = sum(1 for a in answers if a['answer'] == a['correct_option'])
                total = len(answers)
            else:
                attempt = conn.execute('''
                    SELECT ca.score, c.name, c.duration, ca.certificate_id
                    FROM challenge_attempts ca
                    JOIN challenges c ON ca.challenge_id = c.id
                    WHERE ca.id = ? AND ca.user_id = ?
                ''', (attempt_id, session['user_id'])).fetchone()
                answers = conn.execute('''
                    SELECT cq.question_text, cq.correct_answer, ca.answer
                    FROM challenge_answers ca
                    JOIN challenge_questions cq ON ca.question_id = cq.id
                    WHERE ca.attempt_id = ?
                ''', (attempt_id,)).fetchall()
                correct = sum(1 for a in answers if levenshtein_distance(a['answer'].lower(), a['correct_answer'].lower()) < 5)
                total = len(answers)
            graph_data = {
                'correct': (correct / total * 100) if total > 0 else 0,
                'wrong': ((total - correct) / total * 100) if total > 0 else 0,
                'score': attempt['score']
            }
        return render_template('view_attempt.html', attempt=attempt, graph_data=graph_data, type=type, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())
    except Exception as e:
        logging.error(f"View attempt error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('my_learning'))

@app.route('/download_badge/<string:certificate_id>')
def download_badge(certificate_id):
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        badge_path = os.path.join(app.config['UPLOAD_FOLDER'], f"badge_{certificate_id}.png")
        return send_file(badge_path, as_attachment=True)
    except Exception as e:
        logging.error(f"Download badge error: {e}")
        flash('Badge not found', 'danger')
        return redirect(url_for('my_learning'))

@app.route('/attendance')
def attendance():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            test_attempts = conn.execute('''
                SELECT t.name, ta.date, t.duration, ta.score, ta.time
                FROM test_attempts ta
                JOIN tests t ON ta.test_id = t.id
                WHERE ta.user_id = ?
            ''', (session['user_id'],)).fetchall()
            challenge_attempts = conn.execute('''
                SELECT c.name, ca.date, c.duration, ca.score, ca.time
                FROM challenge_attempts ca
                JOIN challenges c ON ca.challenge_id = c.id
                WHERE ca.user_id = ?
            ''', (session['user_id'],)).fetchall()
        return render_template('attendance.html', test_attempts=test_attempts, challenge_attempts=challenge_attempts, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())
    except Exception as e:
        logging.error(f"Attendance error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('login'))

@app.route('/material')
def material():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    courses = [
    {'name': 'Python Programming', 'notes': 'https://docs.python.org/3/tutorial/tutorial.pdf', 'recording': 'https://www.youtube.com/watch?v=_uQrJ0TkZlc'},
    {'name': 'Data Structures', 'notes': 'https://www.cs.cmu.edu/~adamchik/15-121/lectures/Trees/trees.pdf', 'recording': 'https://www.youtube.com/watch?v=bum_19loj9A'},
    {'name': 'Algorithms', 'notes': 'https://algs4.cs.princeton.edu/lectures/algorithms.pdf', 'recording': 'https://www.youtube.com/watch?v=8hly31xKli0'},
    {'name': 'C Programming', 'notes': 'https://people.cs.pitt.edu/~kirk/cs1501/handouts/c.pdf', 'recording': 'https://www.youtube.com/watch?v=KJgsSFOSQv0'},
    {'name': 'Java Programming', 'notes': 'https://www.cs.cmu.edu/~basser/java/java_tutorial.pdf', 'recording': 'https://www.youtube.com/watch?v=grEKMHGYyns'},
    {'name': 'JavaScript Basics', 'notes': 'https://eloquentjavascript.net/Eloquent_JavaScript.pdf', 'recording': 'https://www.youtube.com/watch?v=PkZNo7MFNFg'},
    {'name': 'Object Oriented Programming', 'notes': 'https://www.cs.umd.edu/class/fall2002/cmsc132/oop.pdf', 'recording': 'https://www.youtube.com/watch?v=pTB0EiLXUC8'},
    {'name': 'HTML and CSS', 'notes': 'https://htmlreference.io/pdf/html5-cheatsheet.pdf', 'recording': 'https://www.youtube.com/watch?v=mU6anWqZJcc'},
    {'name': 'SQL Database', 'notes': 'https://www.postgresqltutorial.com/wp-content/uploads/2018/05/PostgreSQL-Cheat-Sheet.pdf', 'recording': 'https://www.youtube.com/watch?v=HXV3zeQKqGY'},
    {'name': 'Git Version Control', 'notes': 'https://git-scm.com/book/en/v2/pdf/Git-SCM-Book.pdf', 'recording': 'https://www.youtube.com/watch?v=USjZcfj8yxE'},
    {'name': 'Linux Command Line', 'notes': 'https://tldp.org/LDP/abs/abs-guide.pdf', 'recording': 'https://www.youtube.com/watch?v=IVquJh3DXUA'},
    {'name': 'Python for Data Science', 'notes': 'https://jakevdp.github.io/PythonDataScienceHandbook/python_datascience_handbook.pdf', 'recording': 'https://www.youtube.com/watch?v=LHBE6Q9XlzI'},
    {'name': 'Machine Learning Basics', 'notes': 'https://cs229.stanford.edu/notes2020fall/cs229-notes1.pdf', 'recording': 'https://www.youtube.com/watch?v=GwIo3gDZCVQ'},
    {'name': 'Deep Learning', 'notes': 'http://www.deeplearningbook.org/contents/intro.pdf', 'recording': 'https://www.youtube.com/watch?v=aircAruvnKk'},
    {'name': 'ReactJS Fundamentals', 'notes': 'https://reactjs.org/docs/react-api.pdf', 'recording': 'https://www.youtube.com/watch?v=w7ejDZ8SWv8'},
    {'name': 'Node.js Basics', 'notes': 'https://nodejs.org/en/docs/guides/nodejs-docker-webapp.pdf', 'recording': 'https://www.youtube.com/watch?v=TlB_eWDSMt4'},
    {'name': 'Android Development', 'notes': 'https://developer.android.com/codelabs/basic-android-kotlin-training-getting-started/pdf', 'recording': 'https://www.youtube.com/watch?v=fis26HvvDII'},
    {'name': 'iOS Swift Programming', 'notes': 'https://swift.org/documentation/#the-swift-programming-language', 'recording': 'https://www.youtube.com/watch?v=comQ1-x2a1Q'},
    {'name': 'Docker for Developers', 'notes': 'https://docs.docker.com/engine/pdf/docker-cheatsheet.pdf', 'recording': 'https://www.youtube.com/watch?v=YFl2mCHdv24'},
    {'name': 'Kubernetes Introduction', 'notes': 'https://kubernetes.io/docs/tutorials/kubernetes-basics/pdf/kubernetes-basics.pdf', 'recording': 'https://www.youtube.com/watch?v=X48VuDVv0do'},
    {'name': 'REST API Design', 'notes': 'https://pages.apigee.com/rs/apigee/images/api-design-ebook-2012-03.pdf', 'recording': 'https://www.youtube.com/watch?v=Q-BpqyOT3a8'},
    {'name': 'GraphQL Basics', 'notes': 'https://graphql.org/learn/schema.pdf', 'recording': 'https://www.youtube.com/watch?v=ed8SzALpx1Q'},
    {'name': 'TypeScript Essentials', 'notes': 'https://www.typescriptlang.org/assets/typescript-handbook.pdf', 'recording': 'https://www.youtube.com/watch?v=BwuLxPH8IDs'},
    {'name': 'Angular Framework', 'notes': 'https://angular.io/generated/zips/angular-official.pdf', 'recording': 'https://www.youtube.com/watch?v=2OHbjep_WjQ'},
    {'name': 'Vue.js Guide', 'notes': 'https://vuejs.org/v2/guide/index.pdf', 'recording': 'https://www.youtube.com/watch?v=4deVCNJq3qc'},
    {'name': 'Ruby on Rails', 'notes': 'https://guides.rubyonrails.org/v6.0/rails_application_templates.html', 'recording': 'https://www.youtube.com/watch?v=fmyvWz5TUWg'},
    {'name': 'PHP Basics', 'notes': 'https://www.php.net/manual/en/langref.php', 'recording': 'https://www.youtube.com/watch?v=OK_JCtrrv-c'},
    {'name': 'Go Language', 'notes': 'https://golang.org/doc/go1.5.pdf', 'recording': 'https://www.youtube.com/watch?v=YS4e4q9oBaU'},
    {'name': 'Rust Programming', 'notes': 'https://doc.rust-lang.org/book/title-page.pdf', 'recording': 'https://www.youtube.com/watch?v=zF34dRivLOw'},
    {'name': 'Scala Introduction', 'notes': 'https://docs.scala-lang.org/resources/the-scala-language.pdf', 'recording': 'https://www.youtube.com/watch?v=8s7XwnKoLkU'},
    {'name': 'Perl Basics', 'notes': 'https://perldoc.perl.org/perl.pdf', 'recording': 'https://www.youtube.com/watch?v=OX5nU1n7QpA'},
    {'name': 'Shell Scripting', 'notes': 'https://www.shellscript.sh/manual/shellscript.pdf', 'recording': 'https://www.youtube.com/watch?v=oxuRxtrO2Ag'},
    {'name': 'MATLAB Programming', 'notes': 'https://www.mathworks.com/help/pdf_doc/matlab/matlab_prog.pdf', 'recording': 'https://www.youtube.com/watch?v=J4uN6jAxOMA'},
    {'name': 'Unity Game Development', 'notes': 'https://unity3d.com/files/UnityManual.pdf', 'recording': 'https://www.youtube.com/watch?v=IlKaB1etrik'},
    {'name': 'Unreal Engine Basics', 'notes': 'https://docs.unrealengine.com/Images/Programming/Introduction/ProgrammingQuickStart/ProgrammingQuickStart.pdf', 'recording': 'https://www.youtube.com/watch?v=ScXN6ypNi6M'},
    {'name': 'Flutter Mobile Apps', 'notes': 'https://flutter.dev/assets/flutter-logo-sharing-7252bce950f1e208d3816b63ce152a06.pdf', 'recording': 'https://www.youtube.com/watch?v=fq4N0hgOWzU'},
    {'name': 'React Native', 'notes': 'https://reactnative.dev/docs/getting-started.pdf', 'recording': 'https://www.youtube.com/watch?v=0-S5a0eXPoc'},
    {'name': 'ASP.NET Core', 'notes': 'https://docs.microsoft.com/en-us/aspnet/core/overview.pdf', 'recording': 'https://www.youtube.com/watch?v=C5cnZ-gZy2I'},
    {'name': 'Django Framework', 'notes': 'https://docs.djangoproject.com/en/3.2/_downloads/django-cheat-sheet.pdf', 'recording': 'https://www.youtube.com/watch?v=F5mRW0jo-U4'},
    {'name': 'Flask Microframework', 'notes': 'https://flask.palletsprojects.com/en/1.1.x/_downloads/flask-cheat-sheet.pdf', 'recording': 'https://www.youtube.com/watch?v=Z1RJmh_OqeA'},
    {'name': 'TensorFlow Basics', 'notes': 'https://tensorflow.org/tutorials/tensorflow_cheat_sheet.pdf', 'recording': 'https://www.youtube.com/watch?v=aircAruvnKk'},
    {'name': 'Cybersecurity Fundamentals', 'notes': 'https://csrc.nist.gov/csrc/media/publications/sp/800-12/archive/1995-08-01/documents/800-12.pdf', 'recording': 'https://www.youtube.com/watch?v=inWWhr5tnEA'},
    {'name': 'Blockchain Programming', 'notes': 'https://bitcoin.org/bitcoin.pdf', 'recording': 'https://www.youtube.com/watch?v=SSo_EIwHSd4'},
    {'name': 'AWS Cloud Computing', 'notes': 'https://d1.awsstatic.com/training-and-certification/docs/AWS_Certified_Solutions_Architect_Associate_Sample_Questions.pdf', 'recording': 'https://www.youtube.com/watch?v=ulprqHHWlng'},
    {'name': 'Azure Fundamentals', 'notes': 'https://aka.ms/azurerootcertificates', 'recording': 'https://www.youtube.com/watch?v=sqlEOqA2CJY'},
    {'name': 'Google Cloud Platform', 'notes': 'https://cloud.google.com/docs/overview', 'recording': 'https://www.youtube.com/watch?v=6vkxr65gNJA'},
    {'name': 'Big Data with Hadoop', 'notes': 'https://hadoop.apache.org/docs/current/hadoop-project-dist/hadoop-common/files/hadoop-common-2.7.7.pdf', 'recording': 'https://www.youtube.com/watch?v=vn1cRI23dcY'},
    {'name': 'SQL Server Basics', 'notes': 'https://docs.microsoft.com/en-us/sql/ssms/media/ssms-cheat-sheet.pdf', 'recording': 'https://www.youtube.com/watch?v=7LzPMLy9Y6A'},
]

    return render_template('material.html', courses=courses, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
            if request.method == 'POST':
                if 'update_info' in request.form:
                    data = {
                        'name': sanitize_input(request.form.get('name')),
                        'mobile': sanitize_input(request.form.get('mobile')),
                        'degree': sanitize_input(request.form.get('degree')),
                        'course': sanitize_input(request.form.get('course')),
                        'college': sanitize_input(request.form.get('college')),
                        'branch': sanitize_input(request.form.get('branch')),
                        'hall_ticket': sanitize_input(request.form.get('hall_ticket')),
                        'semester': sanitize_input(request.form.get('semester')),
                        'cgpa': sanitize_input(request.form.get('cgpa')),
                        'location': sanitize_input(request.form.get('location')),
                        'address': sanitize_input(request.form.get('address')),
                        'state': sanitize_input(request.form.get('state')),
                    }
                    if not all(data.values()):
                        flash('All fields are required', 'danger')
                    elif not validate_mobile(data['mobile']):
                        flash('Mobile number must be exactly 10 digits', 'danger')
                    else:
                        conn.execute('''UPDATE users SET name=?, mobile=?, degree=?, course=?, college=?, branch=?, hall_ticket=?, semester=?, cgpa=?, location=?, address=?, state=?
                                        WHERE id=?''', (*data.values(), session['user_id']))
                        conn.commit()
                        session['user']['name'] = data['name']
                        flash('Profile updated', 'success')
                elif 'update_password' in request.form:
                    password = request.form.get('password')
                    confirm_password = request.form.get('confirm_password')
                    if password != confirm_password:
                        flash('Passwords do not match', 'danger')
                    elif not validate_password(password):
                        flash('Password must be at least 6 characters with uppercase, lowercase, digit, and special character', 'danger')
                    else:
                        conn.execute('UPDATE users SET password=? WHERE id=?', (password, session['user_id']))
                        conn.commit()
                        flash('Password updated', 'success')
            user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
        return render_template('profile.html', db_user=user, logged_in=True, user_role=session['role'], session_user=session['user'],logo=profile_logo())
    except Exception as e:
        logging.error(f"Profile error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('login'))

@app.route('/admin_dashboard')
def admin_dashboard():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    return render_template('admin_dashboard.html', logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())

@app.route('/add_test', methods=['GET', 'POST'])
def add_test():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        name = sanitize_input(request.form.get('name'))
        questions = []
        i = 0
        while f'question_{i}' in request.form:
            question = sanitize_input(request.form.get(f'question_{i}'))
            options = [sanitize_input(request.form.get(f'option_{j}_{i}')) for j in range(1, 5)]
            correct_option = int(request.form.get(f'correct_option_{i}'))
            if all(options) and question and correct_option in [1, 2, 3, 4]:
                questions.append((question, *options, correct_option))
            i += 1
        if not name or not questions:
            flash('Test name and at least one question required', 'danger')
        else:
            try:
                with get_db_connection() as conn:
                    duration = len(questions) * 60
                    conn.execute('INSERT INTO tests (name, duration, description) VALUES (?, ?, ?)', (name, duration, f"Test: {name}"))
                    test_id = conn.execute('SELECT last_insert_rowid()').fetchone()[0]
                    conn.executemany('INSERT INTO test_questions (test_id, question_text, option_1, option_2, option_3, option_4, correct_option) VALUES (?, ?, ?, ?, ?, ?, ?)',
                                     [(test_id, *q) for q in questions])
                    conn.commit()
                flash('Test added successfully', 'success')
                return redirect(url_for('admin_dashboard'))
            except Exception as e:
                logging.error(f"Add test error: {e}")
                flash('An error occurred. Please try again.', 'danger')
    return render_template('add_test.html', logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())

@app.route('/enrolled_tests', methods=['GET', 'POST'])
def enrolled_tests():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        test_id = request.form.get('test_id')
        date = request.form.get('date')
        start_time = request.form.get('start_time')
        end_time = request.form.get('end_time')
        if not all([test_id, date, start_time, end_time]):
            flash('All fields are required', 'danger')
        else:
            try:
                with get_db_connection() as conn:
                    test = conn.execute('SELECT name FROM tests WHERE id = ?', (test_id,)).fetchone()
                    users = conn.execute('SELECT id, email FROM users').fetchall()
                    for user in users:
                        conn.execute('INSERT OR IGNORE INTO test_enrollments (user_id, test_id, date, start_time, end_time) VALUES (?, ?, ?, ?, ?)',
                                     (user['id'], test_id, date, start_time, end_time))
                        html_body = """
                        <div style="font-family: Arial, sans-serif; padding: 20px; background: linear-gradient(to bottom, #e8f4f8, #ffffff); border-radius: 10px;">
                            <h2 style="color: #2c5282; text-align: center;">Test Enrollment</h2>
                            <p style="color: #4a5568;">You are enrolled in {}.</p>
                            <p style="color: #4a5568;">Date: {}</p>
                            <p style="color: #4a5568;">Time: {} to {}</p>
                            <p style="color: #4a5568; text-align: center;">&copy; 2025 Your Platform</p>
                        </div>
                        """.format(test['name'], date, start_time, end_time)
                        send_email(user['email'], "Test Enrollment", f"Enrolled in {test['name']}", html_body)
                    conn.commit()
                flash('Test enrolled successfully', 'success')
                return redirect(url_for('admin_dashboard'))
            except Exception as e:
                logging.error(f"Enroll test error: {e}")
                flash('An error occurred. Please try again.', 'danger')
    with get_db_connection() as conn:
        tests = conn.execute('SELECT id, name FROM tests').fetchall()
    return render_template('enrolled_tests.html', tests=tests, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())

@app.route('/add_challenge', methods=['GET', 'POST'])
def add_challenge():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        name = sanitize_input(request.form.get('name'))
        questions = []
        i = 0
        while f'question_{i}' in request.form:
            question = sanitize_input(request.form.get(f'question_{i}'))
            question_type = sanitize_input(request.form.get(f'question_type_{i}'))
            correct_answer = sanitize_input(request.form.get(f'correct_answer_{i}'))
            if all([question, question_type, correct_answer]):
                questions.append((question, question_type, correct_answer))
            i += 1
        if not name or not questions:
            flash('Challenge name and at least one question required', 'danger')
        else:
            try:
                with get_db_connection() as conn:
                    duration = len(questions) * 60
                    conn.execute('INSERT INTO challenges (name, duration, description) VALUES (?, ?, ?)', (name, duration, f"Challenge: {name}"))
                    challenge_id = conn.execute('SELECT last_insert_rowid()').fetchone()[0]
                    conn.executemany('INSERT INTO challenge_questions (challenge_id, question_text, question_type, correct_answer) VALUES (?, ?, ?, ?)',
                                     [(challenge_id, *q) for q in questions])
                    conn.commit()
                flash('Challenge added successfully', 'success')
                return redirect(url_for('admin_dashboard'))
            except Exception as e:
                logging.error(f"Add challenge error: {e}")
                flash('An error occurred. Please try again.', 'danger')
    return render_template('add_challenge.html', logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())

@app.route('/enrolled_challenges', methods=['GET', 'POST'])
def enrolled_challenges():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        challenge_id = request.form.get('challenge_id')
        date = request.form.get('date')
        start_time = request.form.get('start_time')
        end_time = request.form.get('end_time')
        if not all([challenge_id, date, start_time, end_time]):
            flash('All fields are required', 'danger')
        else:
            try:
                with get_db_connection() as conn:
                    challenge = conn.execute('SELECT name FROM challenges WHERE id = ?', (challenge_id,)).fetchone()
                    users = conn.execute('SELECT id, email FROM users').fetchall()
                    for user in users:
                        conn.execute('INSERT OR IGNORE INTO challenge_enrollments (user_id, challenge_id, date, start_time, end_time) VALUES (?, ?, ?, ?, ?)',
                                     (user['id'], challenge_id, date, start_time, end_time))
                        html_body = """
                        <div style="font-family: Arial, sans-serif; padding: 20px; background: linear-gradient(to bottom, #e8f4f8, #ffffff); border-radius: 10px;">
                            <h2 style="color: #2c5282; text-align: center;">Challenge Enrollment</h2>
                            <p style="color: #4a5568;">You are enrolled in {}.</p>
                            <p style="color: #4a5568;">Date: {}</p>
                            <p style="color: #4a5568;">Time: {} to {}</p>
                            <p style="color: #4a5568; text-align: center;">&copy; 2025 Your Platform</p>
                        </div>
                        """.format(challenge['name'], date, start_time, end_time)
                        send_email(user['email'], "Challenge Enrollment", f"Enrolled in {challenge['name']}", html_body)
                    conn.commit()
                flash('Challenge enrolled successfully', 'success')
                return redirect(url_for('admin_dashboard'))
            except Exception as e:
                logging.error(f"Enroll challenge error: {e}")
                flash('An error occurred. Please try again.', 'danger')
    with get_db_connection() as conn:
        challenges = conn.execute('SELECT id, name FROM challenges').fetchall()
    return render_template('enrolled_challenges.html', challenges=challenges, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())

@app.route('/manage_admins', methods=['GET', 'POST'])
def manage_admins():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        email = sanitize_input(request.form.get('email'))
        password = request.form.get('password')
        name = sanitize_input(request.form.get('name'))
        username = sanitize_input(request.form.get('username'))
        if not all([email, password, name, username]):
            flash('All fields are required', 'danger')
        elif not validate_email(email):
            flash('Invalid Gmail address', 'danger')
        elif not validate_password(password):
            flash('Password must be at least 6 characters with uppercase, lowercase, digit, and special character', 'danger')
        else:
            try:
                with get_db_connection() as conn:
                    existing = conn.execute('SELECT * FROM admins WHERE email = ? OR username = ?', (email, username)).fetchone()
                    if existing:
                        flash('Email or username already exists', 'danger')
                    else:
                        conn.execute('INSERT INTO admins (name, email, username, password, profile_image) VALUES (?, ?, ?, ?, ?)',
                                     (name, email, username, password, 'static/images/admin.png'))
                        conn.commit()
                        html_body = """
                        <div style="font-family: Arial, sans-serif; padding: 20px; background: linear-gradient(to bottom, #e8f4f8, #ffffff); border-radius: 10px;">
                            <h2 style="color: #2c5282; text-align: center;">Admin Account Created</h2>
                            <p style="color: #4a5568;">Email: {}</p>
                            <p style="color: #4a5568;">Password: {}</p>
                            <p style="color: #4a5568;">Login at: {}</p>
                            <p style="color: #4a5568; text-align: center;">&copy; 2025 Your Platform</p>
                        </div>
                        """.format(email, password, url_for('login', _external=True))
                        send_email(email, "Admin Account Created", f"Your admin account is created.", html_body)
                        flash('Admin added successfully', 'success')
                        return redirect(url_for('admin_dashboard'))
            except Exception as e:
                logging.error(f"Manage admins error: {e}")
                flash('An error occurred. Please try again.', 'danger')
    return render_template('manage_admins.html', logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())

@app.route('/view_users')
def view_users():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            users = conn.execute('SELECT * FROM users').fetchall()
        return render_template('view_users.html', users=users, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())
    except Exception as e:
        logging.error(f"View users error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/delete_user/<int:user_id>')
def delete_user(user_id):
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            conn.execute('DELETE FROM users WHERE id = ?', (user_id,))
            conn.commit()
        flash('User deleted successfully', 'success')
    except Exception as e:
        logging.error(f"Delete user error: {e}")
        flash('An error occurred. Please try again.', 'danger')
    return redirect(url_for('view_users'))

@app.route('/view_attempts')
def view_attempts():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            test_attempts = conn.execute('''
                SELECT ta.id, t.name, ta.date, u.name as user_name, u.college, u.hall_ticket, ta.score, ta.remarks
                FROM test_attempts ta
                JOIN tests t ON ta.test_id = t.id
                JOIN users u ON ta.user_id = u.id
            ''').fetchall()
            challenge_attempts = conn.execute('''
                SELECT ca.id, c.name, ca.date, u.name as user_name, u.college, u.hall_ticket, ca.score, ca.remarks
                FROM challenge_attempts ca
                JOIN challenges c ON ca.challenge_id = c.id
                JOIN users u ON ca.user_id = u.id
            ''').fetchall()
        return render_template('view_attempts.html', test_attempts=test_attempts, challenge_attempts=challenge_attempts, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())
    except Exception as e:
        logging.error(f"View attempts error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/view_tests')
def view_tests():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            tests = conn.execute('SELECT * FROM tests').fetchall()
        return render_template('view_tests.html', tests=tests, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"View tests error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/view_challenges')
def view_challenges():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            challenges = conn.execute('SELECT * FROM challenges').fetchall()
        return render_template('view_challenges.html', challenges=challenges, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())
    except Exception as e:
        logging.error(f"View challenges error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))



@app.route('/test/<int:test_id>', methods=['GET', 'POST'])
def test(test_id):
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            test = conn.execute('SELECT * FROM tests WHERE id = ?', (test_id,)).fetchone()
            if not test:
                flash('Test not found', 'danger')
                return redirect(url_for('user_dashboard'))
            attempt = conn.execute('SELECT * FROM test_attempts WHERE test_id = ? AND user_id = ? AND step < 5',
                                  (test_id, session['user_id'])).fetchone()
            if not attempt:
                attempt = conn.execute('INSERT INTO test_attempts (test_id, user_id, date, time, step, current_question, remaining_time, paused, pause_start, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                                      (test_id, session['user_id'], datetime.datetime.now().strftime('%Y-%m-%d'), datetime.datetime.now().strftime('%H:%M:%S'), 1, 0, test['duration'], False, 0, '')).lastrowid
                conn.commit()
                attempt = conn.execute('SELECT * FROM test_attempts WHERE id = ?', (attempt,)).fetchone()
            if request.method == 'POST':
                step = attempt['step']
                if step == 1:
                    image_data = request.form.get('image_data')
                    if image_data:
                        image_data = image_data.split(',')[1]
                        image_path = os.path.join(app.config['UPLOAD_FOLDER'], f"test_{attempt['id']}_checkin.png")
                        with open(image_path, 'wb') as f:
                            f.write(base64.b64decode(image_data))
                        adjust_image_brightness_contrast(image_path)
                        valid, msg = validate_image(image_path)
                        if not valid:
                            flash(msg, 'danger')
                            return render_template('test_page.html', test=test, step=1, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())
                        user = conn.execute('SELECT profile_image FROM users WHERE id = ?', (session['user_id'],)).fetchone()
                        if not image_comparator.compare_images(image_path, user['profile_image']):
                            flash('Face verification failed', 'danger')
                            return render_template('test_page.html', test=test, step=1, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())
                        conn.execute('UPDATE test_attempts SET checkin_image = ?, step = 2 WHERE id = ?', (image_path, attempt['id']))
                        conn.commit()
                elif step == 2:
                    if request.form.get('checks_passed') == 'true':
                        conn.execute('UPDATE test_attempts SET step = 3 WHERE id = ?', (attempt['id'],))
                        conn.commit()
                    else:
                        flash('System checks failed', 'danger')
                elif step == 3:
                    conn.execute('UPDATE test_attempts SET step = 4 WHERE id = ?', (attempt['id'],))
                    conn.commit()
                elif step == 4:
                    if request.form.get('continue'):
                        pause_duration = time.time() - attempt['pause_start'] if attempt['pause_start'] else 0
                        remaining_time = max(0, attempt['remaining_time'] - pause_duration)
                        conn.execute('UPDATE test_attempts SET paused = ?, pause_start = ?, remaining_time = ? WHERE id = ?', 
                                     (False, 0, remaining_time, attempt['id']))
                        conn.commit()
                    elif request.form.get('pause'):
                        conn.execute('UPDATE test_attempts SET paused = ?, pause_start = ? WHERE id = ?', 
                                     (True, time.time(), attempt['id']))
                        conn.commit()
                    elif request.form.get('question_id'):
                        answer = request.form.get('answer')
                        question_id = request.form.get('question_id')
                        current_question = int(request.form.get('current_question', attempt['current_question']))
                        if answer:
                            conn.execute('INSERT OR REPLACE INTO test_answers (attempt_id, question_id, answer) VALUES (?, ?, ?)',
                                         (attempt['id'], question_id, answer))
                            conn.commit()
                        questions = conn.execute('SELECT id FROM test_questions WHERE test_id = ?', (test_id,)).fetchall()
                        if current_question >= len(questions) or request.form.get('finish'):
                            answers = conn.execute('SELECT tq.correct_option, ta.answer FROM test_answers ta JOIN test_questions tq ON ta.question_id = tq.id WHERE ta.attempt_id = ?', (attempt['id'],)).fetchall()
                            score = sum(1 for a in answers if a['answer'] == a['correct_option']) / len(answers) * 100 if answers else 0
                            certificate_id = str(uuid.uuid4()) if score >= 80 else None
                            if certificate_id:
                                badge_path = generate_badge(test['name'], session['user']['name'], score, certificate_id, 'Test')
                                html_body = f"""
                                <div style="font-family: Arial, sans-serif; padding: 20px; background: linear-gradient(to bottom, #e8f4f8, #ffffff); border-radius: 10px;">
                                    <h2 style="color: #2c5282; text-align: center;">Congratulations!</h2>
                                    <p style="color: #4a5568;">You have earned a badge for {test['name']} with a score of {score}%.</p>
                                    <p style="color: #4a5568; text-align: center;">© 2025 Your Platform</p>
                                </div>
                                """
                                send_email(session['user']['email'], "Test Badge", "Congratulations on your achievement!", html_body, badge_path)
                            conn.execute('UPDATE test_attempts SET score = ?, step = 5, certificate_id = ? WHERE id = ?', 
                                         (score, certificate_id, attempt['id']))
                            conn.commit()
                            return redirect(url_for('my_learning'))
                        conn.execute('UPDATE test_attempts SET current_question = ? WHERE id = ?', (current_question, attempt['id']))
                        conn.commit()
                    elif request.form.get('monitor'):
                        image_data = request.form.get('monitor_image')
                        remarks = attempt['remarks'] or ''
                        if image_data:
                            image_path = os.path.join(app.config['UPLOAD_FOLDER'], f"test_{attempt['id']}_monitor_{int(time.time())}.png")
                            image_data = image_data.split(',')[1]
                            with open(image_path, 'wb') as f:
                                f.write(base64.b64decode(image_data))
                            adjust_image_brightness_contrast(image_path)
                            valid, msg = validate_image(image_path)
                            if not valid:
                                remarks += f"{datetime.datetime.now()}: {msg}\n"
                                conn.execute('UPDATE test_attempts SET paused = ?, pause_start = ?, remarks = ? WHERE id = ?', 
                                             (True, time.time(), remarks, attempt['id']))
                                conn.commit()
                            else:
                                checkin_image = conn.execute('SELECT checkin_image FROM test_attempts WHERE id = ?', (attempt['id'],)).fetchone()['checkin_image']
                                if not image_comparator.compare_images(image_path, checkin_image):
                                    remarks += f"{datetime.datetime.now()}: Face mismatch detected\n"
                                    conn.execute('UPDATE test_attempts SET paused = ?, pause_start = ?, remarks = ? WHERE id = ?', 
                                                 (True, time.time(), remarks, attempt['id']))
                                    conn.commit()
                        audio_level = float(request.form.get('audio_level', 0))
                        network_status = request.form.get('network_status') == 'true'
                        if audio_level > 0.5:
                            remarks += f"{datetime.datetime.now()}: High audio volume detected\n"
                            conn.execute('UPDATE test_attempts SET paused = ?, pause_start = ?, remarks = ? WHERE id = ?', 
                                         (True, time.time(), remarks, attempt['id']))
                            conn.commit()
                        if not network_status:
                            remarks += f"{datetime.datetime.now()}: Poor network detected\n"
                            conn.execute('UPDATE test_attempts SET paused = ?, pause_start = ?, remarks = ? WHERE id = ?', 
                                         (True, time.time(), remarks, attempt['id']))
                            conn.commit()
            attempt = conn.execute('SELECT * FROM test_attempts WHERE id = ?', (attempt['id'],)).fetchone()
            questions = conn.execute('SELECT * FROM test_questions WHERE test_id = ?', (test_id,)).fetchall()
            answers = conn.execute('SELECT question_id FROM test_answers WHERE attempt_id = ?', (attempt['id'],)).fetchall()
            answered_questions = {a['question_id'] for a in answers}
            return render_template('test_page.html', test=test, step=attempt['step'], question=questions[attempt['current_question']] if attempt['step'] == 4 and attempt['current_question'] < len(questions) else None, 
                                 questions=questions, answered_questions=answered_questions, attempt=attempt, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())
    except Exception as e:
        logging.error(f"Test error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('user_dashboard'))

@app.route('/challenge/<int:challenge_id>', methods=['GET', 'POST'])
def challenge(challenge_id):
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            challenge = conn.execute('SELECT * FROM challenges WHERE id = ?', (challenge_id,)).fetchone()
            if not challenge:
                flash('Challenge not found', 'danger')
                return redirect(url_for('user_dashboard'))
            attempt = conn.execute('SELECT * FROM challenge_attempts WHERE challenge_id = ? AND user_id = ? AND step < 5',
                                  (challenge_id, session['user_id'])).fetchone()
            if not attempt:
                attempt = conn.execute('INSERT INTO challenge_attempts (challenge_id, user_id, date, time, step, current_question, remaining_time, paused, pause_start, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                                      (challenge_id, session['user_id'], datetime.datetime.now().strftime('%Y-%m-%d'), datetime.datetime.now().strftime('%H:%M:%S'), 1, 0, challenge['duration'], False, 0, '')).lastrowid
                conn.commit()
                attempt = conn.execute('SELECT * FROM challenge_attempts WHERE id = ?', (attempt,)).fetchone()
            if request.method == 'POST':
                step = attempt['step']
                if step == 1:
                    image_data = request.form.get('image_data')
                    if image_data:
                        image_data = image_data.split(',')[1]
                        image_path = os.path.join(app.config['UPLOAD_FOLDER'], f"challenge_{attempt['id']}_checkin.png")
                        with open(image_path, 'wb') as f:
                            f.write(base64.b64decode(image_data))
                        adjust_image_brightness_contrast(image_path)
                        valid, msg = validate_image(image_path)
                        if not valid:
                            flash(msg, 'danger')
                            return render_template('challenge_page.html', challenge=challenge, step=1, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())
                        user = conn.execute('SELECT profile_image FROM users WHERE id = ?', (session['user_id'],)).fetchone()
                        if not image_comparator.compare_images(image_path, user['profile_image']):
                            flash('Face verification failed', 'danger')
                            return render_template('challenge_page.html', challenge=challenge, step=1, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())
                        conn.execute('UPDATE challenge_attempts SET checkin_image = ?, step = 2 WHERE id = ?', (image_path, attempt['id']))
                        conn.commit()
                elif step == 2:
                    if request.form.get('checks_passed') == 'true':
                        conn.execute('UPDATE challenge_attempts SET step = 3 WHERE id = ?', (attempt['id'],))
                        conn.commit()
                    else:
                        flash('System checks failed', 'danger')
                elif step == 3:
                    conn.execute('UPDATE challenge_attempts SET step = 4 WHERE id = ?', (attempt['id'],))
                    conn.commit()
                elif step == 4:
                    if request.form.get('continue'):
                        pause_duration = time.time() - attempt['pause_start'] if attempt['pause_start'] else 0
                        remaining_time = max(0, attempt['remaining_time'] - pause_duration)
                        conn.execute('UPDATE challenge_attempts SET paused = ?, pause_start = ?, remaining_time = ? WHERE id = ?', 
                                     (False, 0, remaining_time, attempt['id']))
                        conn.commit()
                    elif request.form.get('pause'):
                        conn.execute('UPDATE challenge_attempts SET paused = ?, pause_start = ? WHERE id = ?', 
                                     (True, time.time(), attempt['id']))
                        conn.commit()
                    elif request.form.get('question_id'):
                        audio_file = request.files.get('audio')
                        question_id = request.form.get('question_id')
                        current_question = int(request.form.get('current_question', attempt['current_question']))
                        if audio_file and allowed_file(audio_file.filename):
                            audio_path = os.path.join(app.config['UPLOAD_FOLDER'], f"challenge_{attempt['id']}_{question_id}.wav")
                            audio_file.save(audio_path)
                            text, confidence = extract_text_from_audio(audio_path)
                            correct_answer = conn.execute('SELECT correct_answer FROM challenge_questions WHERE id = ?', (question_id,)).fetchone()['correct_answer']
                            score = 100 - (levenshtein_distance(text.lower(), correct_answer.lower()) / max(len(text), len(correct_answer)) * 100)
                            conn.execute('INSERT OR REPLACE INTO challenge_answers (attempt_id, question_id, answer, score) VALUES (?, ?, ?, ?)',
                                         (attempt['id'], question_id, text, score))
                            conn.commit()
                        questions = conn.execute('SELECT id FROM challenge_questions WHERE challenge_id = ?', (challenge_id,)).fetchall()
                        if current_question >= len(questions) or request.form.get('finish'):
                            answers = conn.execute('SELECT score FROM challenge_answers WHERE attempt_id = ?', (attempt['id'],)).fetchall()
                            score = sum(a['score'] for a in answers) / len(answers) if answers else 0
                            certificate_id = str(uuid.uuid4()) if score >= 80 else None
                            if certificate_id:
                                badge_path = generate_badge(challenge['name'], session['user']['name'], score, certificate_id, 'Challenge')
                                html_body = f"""
                                <div style="font-family: Arial, sans-serif; padding: 20px; background: linear-gradient(to bottom, #e8f4f8, #ffffff); border-radius: 10px;">
                                    <h2 style="color: #2c5282; text-align: center;">Congratulations!</h2>
                                    <p style="color: #4a5568;">You have earned a badge for {challenge['name']} with a score of {score}%.</p>
                                    <p style="color: #4a5568; text-align: center;">© 2025 Your Platform</p>
                                </div>
                                """
                                send_email(session['user']['email'], "Challenge Badge", "Congratulations on your achievement!", html_body, badge_path)
                            conn.execute('UPDATE challenge_attempts SET score = ?, step = 5, certificate_id = ? WHERE id = ?', 
                                         (score, certificate_id, attempt['id']))
                            conn.commit()
                            return redirect(url_for('my_learning'))
                        conn.execute('UPDATE challenge_attempts SET current_question = ? WHERE id = ?', (current_question, attempt['id']))
                        conn.commit()
                    elif request.form.get('monitor'):
                        image_data = request.form.get('monitor_image')
                        remarks = attempt['remarks'] or ''
                        if image_data:
                            image_path = os.path.join(app.config['UPLOAD_FOLDER'], f"challenge_{attempt['id']}_monitor_{int(time.time())}.png")
                            image_data = image_data.split(',')[1]
                            with open(image_path, 'wb') as f:
                                f.write(base64.b64decode(image_data))
                            adjust_image_brightness_contrast(image_path)
                            valid, msg = validate_image(image_path)
                            if not valid:
                                remarks += f"{datetime.datetime.now()}: {msg}\n"
                                conn.execute('UPDATE challenge_attempts SET paused = ?, pause_start = ?, remarks = ? WHERE id = ?', 
                                             (True, time.time(), remarks, attempt['id']))
                                conn.commit()
                            else:
                                checkin_image = conn.execute('SELECT checkin_image FROM challenge_attempts WHERE id = ?', (attempt['id'],)).fetchone()['checkin_image']
                                if not image_comparator.compare_images(image_path, checkin_image):
                                    remarks += f"{datetime.datetime.now()}: Face mismatch detected\n"
                                    conn.execute('UPDATE challenge_attempts SET paused = ?, pause_start = ?, remarks = ? WHERE id = ?', 
                                                 (True, time.time(), remarks, attempt['id']))
                                    conn.commit()
                        audio_level = float(request.form.get('audio_level', 0))
                        network_status = request.form.get('network_status') == 'true'
                        if audio_level > 0.5:
                            remarks += f"{datetime.datetime.now()}: High audio volume detected\n"
                            conn.execute('UPDATE challenge_attempts SET paused = ?, pause_start = ?, remarks = ? WHERE id = ?', 
                                         (True, time.time(), remarks, attempt['id']))
                            conn.commit()
                        if not network_status:
                            remarks += f"{datetime.datetime.now()}: Poor network detected\n"
                            conn.execute('UPDATE challenge_attempts SET paused = ?, pause_start = ?, remarks = ? WHERE id = ?', 
                                         (True, time.time(), remarks, attempt['id']))
                            conn.commit()
            attempt = conn.execute('SELECT * FROM challenge_attempts WHERE id = ?', (attempt['id'],)).fetchone()
            questions = conn.execute('SELECT * FROM challenge_questions WHERE challenge_id = ?', (challenge_id,)).fetchall()
            answers = conn.execute('SELECT question_id FROM challenge_answers WHERE attempt_id = ?', (attempt['id'],)).fetchall()
            answered_questions = {a['question_id'] for a in answers}
            return render_template('challenge_page.html', challenge=challenge, step=attempt['step'], question=questions[attempt['current_question']] if attempt['step'] == 4 and attempt['current_question'] < len(questions) else None, 
                                 questions=questions, answered_questions=answered_questions, attempt=attempt, logged_in=True, user_role=session['role'], user=session['user'],logo=profile_logo())
    except Exception as e:
        logging.error(f"Challenge error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('user_dashboard'))

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'success')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)