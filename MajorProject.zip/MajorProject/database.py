import sqlite3

def init_db():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()

    # Creating tables
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        username TEXT NOT NULL UNIQUE,
        mobile TEXT NOT NULL,
        degree TEXT,
        course TEXT,
        college TEXT,
        branch TEXT,
        hall_ticket TEXT,
        semester TEXT,
        cgpa TEXT,
        location TEXT,
        address TEXT,
        state TEXT,
        profile_image TEXT,
        id_card_image TEXT,
        password TEXT NOT NULL
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        username TEXT NOT NULL UNIQUE,
        profile_image TEXT,
        password TEXT NOT NULL
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS tests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        duration INTEGER NOT NULL,
        description TEXT
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS test_questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        test_id INTEGER,
        question_text TEXT NOT NULL,
        option_1 TEXT,
        option_2 TEXT,
        option_3 TEXT,
        option_4 TEXT,
        correct_option INTEGER,
        FOREIGN KEY (test_id) REFERENCES tests(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS test_enrollments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        test_id INTEGER,
        date TEXT,
        start_time TEXT,
        end_time TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (test_id) REFERENCES tests(id),
        UNIQUE(user_id, test_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS test_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        test_id INTEGER,
        user_id INTEGER,
        date TEXT,
        time TEXT,
        score REAL,
        remarks TEXT,
        severity TEXT,
        step INTEGER,
        current_question INTEGER,
        remaining_time INTEGER,
        checkin_image TEXT,
        FOREIGN KEY (test_id) REFERENCES tests(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS test_answers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        attempt_id INTEGER,
        question_id INTEGER,
        answer INTEGER,
        FOREIGN KEY (attempt_id) REFERENCES test_attempts(id),
        FOREIGN KEY (question_id) REFERENCES test_questions(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS challenges (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        duration INTEGER NOT NULL,
        description TEXT
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS challenge_questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        challenge_id INTEGER,
        question_text TEXT NOT NULL,
        question_type TEXT,
        correct_answer TEXT,
        FOREIGN KEY (challenge_id) REFERENCES challenges(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS challenge_enrollments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        challenge_id INTEGER,
        date TEXT,
        start_time TEXT,
        end_time TEXT,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (challenge_id) REFERENCES challenges(id),
        UNIQUE(user_id, challenge_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS challenge_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        challenge_id INTEGER,
        user_id INTEGER,
        date TEXT,
        time TEXT,
        score REAL,
        remarks TEXT,
        severity TEXT,
        step INTEGER,
        current_question INTEGER,
        remaining_time INTEGER,
        checkin_image TEXT,
        audio_path TEXT,
        FOREIGN KEY (challenge_id) REFERENCES challenges(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS challenge_answers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        attempt_id INTEGER,
        question_id INTEGER,
        answer TEXT,
        score REAL,
        FOREIGN KEY (attempt_id) REFERENCES challenge_attempts(id),
        FOREIGN KEY (question_id) REFERENCES challenge_questions(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS queries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL,
        subject TEXT NOT NULL,
        message TEXT NOT NULL,
        response TEXT,
        responded_at TEXT
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS achievements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        certificate_id TEXT NOT NULL,
        user_name TEXT NOT NULL,
        test_name TEXT NOT NULL,
        score REAL NOT NULL,
        type TEXT NOT NULL,
        date TEXT NOT NULL
    )''')

    # Create indexes for performance
    c.execute('CREATE INDEX IF NOT EXISTS idx_test_enrollments_user_test ON test_enrollments(user_id, test_id)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_challenge_enrollments_user_challenge ON challenge_enrollments(user_id, challenge_id)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_test_attempts_user ON test_attempts(user_id)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_challenge_attempts_user ON challenge_attempts(user_id)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_achievements_user ON achievements(user_name)')

    # Inserting admin credentials
    admins = [
        ('Admin One', 'admin1@gmail.com', 'admin1', 'static/uploads/admin1.jpg', 'Admin@123'),
        ('Admin Two', 'admin2@gmail.com', 'admin2', 'static/uploads/admin2.jpg', 'Admin@123'),
        ('Admin Three', 'admin3@gmail.com', 'admin3', 'static/uploads/admin3.jpg', 'Admin@123'),
        ('Admin Four', 'admin4@gmail.com', 'admin4', 'static/uploads/admin4.jpg', 'Admin@123'),
        ('Admin Five', 'admin5@gmail.com', 'admin5', 'static/uploads/admin5.jpg', 'Admin@123'),
    ]
    c.executemany('INSERT OR IGNORE INTO admins (name, email, username, profile_image, password) VALUES (?, ?, ?, ?, ?)', admins)

    # Inserting tests
    tests = [
        ('Python Basics', 600, 'Test your Python programming skills'),
        ('Java Fundamentals', 600, 'Test your Java programming knowledge'),
        ('Verbal Ability', 600, 'Assess your verbal and comprehension skills'),
        ('Aptitude Test', 600, 'Evaluate your quantitative aptitude'),
        ('Logical Reasoning', 600, 'Test your logical reasoning abilities'),
        ('CSS Essentials', 600, 'Check your CSS styling knowledge'),
        ('HTML Basics', 600, 'Test your HTML structuring skills'),
        ('JavaScript Core', 600, 'Assess your JavaScript programming skills'),
        ('C Programming', 600, 'Test your C programming knowledge'),
        ('SQL Queries', 600, 'Evaluate your SQL database skills'),
    ]
    c.executemany('INSERT OR IGNORE INTO tests (name, duration, description) VALUES (?, ?, ?)', tests)

    # Inserting test questions
    test_questions = {
        1: [  # Python Basics
            ('What is the output of print(2 ** 3)?', '8', '6', '9', '7', 1),
            ('Which keyword is used to define a function in Python?', 'func', 'def', 'function', 'lambda', 2),
            ('What does the len() function do?', 'Returns the length of an object', 'Returns the type', 'Converts to string', 'Checks equality', 1),
            ('Which of these is a Python data structure?', 'Array', 'List', 'Record', 'All of the above', 2),
            ('What is the correct file extension for Python files?', '.py', '.python', '.pt', '.p', 1),
            ('How do you insert comments in Python?', '// Comment', '# Comment', '/* Comment */', '<!-- Comment -->', 2),
            ('What is the output of print(type([]))?', '<class "list">', '<class "tuple">', '<class "dict">', '<class "set">', 1),
            ('Which operator is used for floor division?', '/', '//', '%', '**', 2),
            ('What does the break statement do?', 'Exits the loop', 'Skips to next iteration', 'Restarts the loop', 'Pauses the loop', 1),
            ('Which method converts a string to uppercase?', 'upper()', 'toUpper()', 'uppercase()', 'caps()', 1),
        ],
        2: [  # Java Fundamentals
            ('What is the size of int in Java?', '4 bytes', '2 bytes', '8 bytes', '1 byte', 1),
            ('Which keyword is used to inherit a class?', 'extends', 'implements', 'super', 'this', 1),
            ('What is the default value of a boolean variable?', 'true', 'false', '0', 'null', 2),
            ('Which of these is not a Java access modifier?', 'public', 'private', 'protected', 'static', 4),
            ('What does JVM stand for?', 'Java Virtual Machine', 'Java Variable Manager', 'Java Version Monitor', 'Java Visual Model', 1),
            ('Which method is the entry point of a Java program?', 'start()', 'main()', 'run()', 'execute()', 2),
            ('What is the output of System.out.println(5 + 3 + "2");?', '82', '10', '532', '8', 3),
            ('Which keyword is used to create an object?', 'new', 'create', 'object', 'instance', 1),
            ('What is the parent class of all classes in Java?', 'Class', 'Object', 'System', 'Base', 2),
            ('Which exception is thrown when dividing by zero?', 'IOException', 'NullPointerException', 'ArithmeticException', 'ClassNotFoundException', 3),
        ],
        3: [  # Verbal Ability
            ('Choose the synonym of "big":', 'Small', 'Large', 'Tiny', 'Short', 2),
            ('What is the antonym of "happy"?', 'Joyful', 'Sad', 'Excited', 'Pleased', 2),
            ('Complete the sentence: She ___ to the store.', 'go', 'goes', 'gone', 'going', 2),
            ('Identify the correctly spelled word:', 'Recieve', 'Receive', 'Receeve', 'Recive', 2),
            ('What is the meaning of "benevolent"?', 'Kind', 'Angry', 'Sad', 'Tired', 1),
            ('Choose the correct plural form of "child":', 'Childs', 'Children', 'Childes', 'Childern', 2),
            ('Which word is a verb?', 'House', 'Run', 'Blue', 'Tree', 2),
            ('Find the error: He run fast.', 'run', 'fast', 'He', 'No error', 1),
            ('What is a group of lions called?', 'Pack', 'Pride', 'Herd', 'Flock', 2),
            ('Choose the correct preposition: I am going ___ school.', 'to', 'at', 'in', 'on', 1),
        ],
        4: [  # Aptitude Test
            ('What is 15% of 200?', '30', '25', '20', '35', 1),
            ('If 3x = 12, what is x?', '3', '4', '5', '6', 2),
            ('A train travels 120 km in 2 hours. What is its speed?', '60 km/h', '50 km/h', '70 km/h', '80 km/h', 1),
            ('What is the next number in the series: 2, 4, 6, 8, ...?', '10', '9', '11', '12', 1),
            ('If a shirt costs $20 after a 20% discount, what was the original price?', '$25', '$22', '$24', '$26', 1),
            ('What is the LCM of 6 and 8?', '24', '12', '16', '18', 1),
            ('If 5 workers complete a job in 10 days, how long will 10 workers take?', '5 days', '6 days', '4 days', '8 days', 1),
            ('What is the square root of 144?', '12', '14', '16', '10', 1),
            ('If x + y = 10 and x - y = 4, what is x?', '7', '6', '8', '5', 1),
            ('What is 2/3 of 90?', '60', '45', '30', '75', 1),
        ],
        5: [  # Logical Reasoning
            ('If all cats are mammals and some mammals are dogs, are all cats dogs?', 'Yes', 'No', 'Maybe', 'Cannot determine', 2),
            ('What comes next: A, C, E, I, ...?', 'I', 'J', 'K', 'L', 2),
            ('If today is Monday, what day is it after 10 days?', 'Wednesday', 'Thursday', 'Friday', 'Tuesday', 2),
            ('Which number does not belong: 2, 3, 5, 7, 9?', '9', '2', '3', '5', 1),
            ('If A is taller than B and B is taller than C, who is the tallest?', 'A', 'B', 'C', 'Cannot determine', 1),
            ('What is the missing number: 1, 4, 9, 16, ...?', '25', '20', '18', '22', 1),
            ('If some roses are red and all red flowers are beautiful, are some roses beautiful?', 'Yes', 'No', 'Maybe', 'Cannot determine', 1),
            ('Which word does not belong: Apple, Banana, Carrot, Orange?', 'Carrot', 'Apple', 'Banana', 'Orange', 1),
            ('If 3 pens cost $6, how much do 5 pens cost?', '$10', '$8', '$12', '$9', 1),
            ('What is the next term: 1, 2, 4, 7, 11, ...?', '16', '15', '17', '18', 1),
        ],
        6: [  # CSS Essentials
            ('What does CSS stand for?', 'Cascading Style Sheets', 'Creative Style System', 'Colorful Style Sheets', 'Computer Style System', 1),
            ('Which property sets the background color?', 'color', 'background-color', 'bgcolor', 'background', 2),
            ('How do you select an element with id "myId"?', '.myId', '#myId', 'myId', '*myId', 2),
            ('What is the default value of position property?', 'static', 'relative', 'absolute', 'fixed', 1),
            ('Which unit is relative to the font size of the element?', 'px', 'em', '%', 'vw', 2),
            ('What does the box-sizing: border-box do?', 'Includes padding and border in width', 'Excludes padding', 'Sets border to zero', 'Changes box model', 1),
            ('How do you center a block element horizontally?', 'margin: auto', 'text-align: center', 'float: center', 'position: center', 1),
            ('Which property controls text size?', 'font-size', 'text-size', 'size', 'font-style', 1),
            ('What is the correct syntax for a CSS comment?', '/* Comment */', '// Comment', '# Comment', '<!-- Comment -->', 1),
            ('Which property sets the space between elements?', 'margin', 'padding', 'border', 'spacing', 1),
        ],
        7: [  # HTML Basics
            ('What does HTML stand for?', 'HyperText Markup Language', 'HighText Machine Language', 'HyperTool Markup Language', 'HomeTool Markup Language', 1),
            ('Which tag is used for a hyperlink?', '<link>', '<a>', '<href>', '<url>', 2),
            ('What is the correct HTML for an image?', '<img src="image.jpg">', '<image src="image.jpg">', '<img href="image.jpg">', '<pic src="image.jpg">', 1),
            ('Which tag defines a paragraph?', '<p>', '<para>', '<text>', '<paragraph>', 1),
            ('What is the purpose of the <head> tag?', 'Contains metadata', 'Defines the body', 'Creates a header', 'Styles the page', 1),
            ('Which attribute specifies an alternate text for an image?', 'alt', 'title', 'src', 'desc', 1),
            ('How do you create an ordered list?', '<ol>', '<ul>', '<li>', '<list>', 1),
            ('Which tag is used for the largest heading?', '<h1>', '<h6>', '<head>', '<heading>', 1),
            ('What is the correct HTML for a line break?', '<br>', '<break>', '<lb>', '<newline>', 1),
            ('Which tag is used to define a table?', '<table>', '<tab>', '<tr>', '<td>', 1),
        ],
        8: [  # JavaScript Core
            ('What is the output of console.log(typeof null)?', 'object', 'null', 'undefined', 'string', 1),
            ('Which method adds an element to the end of an array?', 'push()', 'pop()', 'shift()', 'unshift()', 1),
            ('How do you declare a variable in ES6?', 'var', 'let', 'const', 'All of the above', 4),
            ('What is the output of 2 + "2"?', '4', '22', 'NaN', 'undefined', 2),
            ('Which event occurs when a user clicks an element?', 'onclick', 'onchange', 'onhover', 'onload', 1),
            ('What does JSON stand for?', 'JavaScript Object Notation', 'Java Source Object Notation', 'JavaScript Online Notation', 'Java Standard Object Notation', 1),
            ('How do you access the first element of an array?', 'array[0]', 'array[1]', 'array.first', 'array.get(0)', 1),
            ('Which method converts a string to an integer?', 'parseInt()', 'toString()', 'parseFloat()', 'Number()', 1),
            ('What is a closure in JavaScript?', 'A function with access to its outer scope', 'A loop structure', 'A conditional statement', 'A variable type', 1),
            ('What is the output of console.log(!!"false")?', 'true', 'false', 'undefined', 'null', 1),
        ],
        9: [  # C Programming
            ('What is the size of a char in C?', '1 byte', '2 bytes', '4 bytes', '8 bytes', 1),
            ('Which symbol is used for a pointer?', '*', '&', '%', '#', 1),
            ('What is the output of printf("%d", 5/2)?', '2', '2.5', '3', '0', 1),
            ('Which header file is used for input/output functions?', 'stdio.h', 'stdlib.h', 'string.h', 'math.h', 1),
            ('What does the break statement do in a loop?', 'Exits the loop', 'Skips to next iteration', 'Restarts the loop', 'Pauses the loop', 1),
            ('Which keyword is used to define a constant?', 'const', 'constant', 'define', 'static', 1),
            ('What is the correct syntax for a function declaration?', 'return_type function_name()', 'function_name return_type()', 'return_type: function_name', 'function function_name()', 1),
            ('What is the output of printf("%c", 65)?', 'A', '65', 'a', '0', 1),
            ('Which operator is used to access structure members?', '.', '->', '*', '&', 1),
            ('What does malloc() do?', 'Allocates memory', 'Frees memory', 'Reallocates memory', 'Clears memory', 1),
        ],
        10: [  # SQL Queries
            ('Which SQL keyword is used to retrieve data?', 'SELECT', 'GET', 'FETCH', 'RETRIEVE', 1),
            ('What does the JOIN clause do?', 'Combines rows from two or more tables', 'Deletes rows', 'Updates rows', 'Inserts rows', 1),
            ('Which function counts the number of rows?', 'COUNT()', 'SUM()', 'AVG()', 'MAX()', 1),
            ('What is the correct syntax for a primary key?', 'PRIMARY KEY', 'KEY', 'UNIQUE', 'INDEX', 1),
            ('Which clause filters the results?', 'WHERE', 'FROM', 'SELECT', 'ORDER BY', 1),
            ('What does the GROUP BY clause do?', 'Groups rows with same values', 'Sorts rows', 'Filters rows', 'Joins tables', 1),
            ('Which keyword deletes rows from a table?', 'DELETE', 'REMOVE', 'DROP', 'TRUNCATE', 1),
            ('What is the output of SELECT LENGTH("SQL")?', '3', '4', '2', '5', 1),
            ('Which clause sorts the results?', 'ORDER BY', 'GROUP BY', 'WHERE', 'HAVING', 1),
            ('What does the INNER JOIN return?', 'Matching rows from both tables', 'All rows from both tables', 'Non-matching rows', 'First table rows only', 1),
        ],
    }

    for test_id, questions in test_questions.items():
        c.executemany('INSERT OR IGNORE INTO test_questions (test_id, question_text, option_1, option_2, option_3, option_4, correct_option) VALUES (?, ?, ?, ?, ?, ?, ?)', 
                     [(test_id, *q) for q in questions])

    # Inserting challenges
    challenges = [
        ('Pronunciation Challenge 1', 600, 'Test your word and sentence pronunciation skills'),
        ('Pronunciation Challenge 2', 600, 'Improve your pronunciation accuracy'),
        ('Pronunciation Challenge 3', 600, 'Practice clear word and sentence pronunciation'),
        ('Pronunciation Challenge 4', 600, 'Enhance your speaking clarity'),
        ('Pronunciation Challenge 5', 600, 'Master pronunciation techniques'),
        ('Pronunciation Challenge 6', 600, 'Refine your speech clarity'),
        ('Pronunciation Challenge 7', 600, 'Advance your pronunciation skills'),
        ('Pronunciation Challenge 8', 600, 'Perfect your word and sentence pronunciation'),
    ]
    c.executemany('INSERT OR IGNORE INTO challenges (name, duration, description) VALUES (?, ?, ?)', challenges)

    # Inserting challenge questions with correct answers
    challenge_questions = {
        1: [
            ('Pronounce the word: apple', 'word', 'apple'),
            ('Pronounce the word: knowledge', 'word', 'knowledge'),
            ('Pronounce the word: rhythm', 'word', 'rhythm'),
            ('Pronounce the word: suggestion', 'word', 'suggestion'),
            ('Pronounce the sentence: The quick brown fox jumps.', 'sentence', 'the quick brown fox jumps'),
            ('Pronounce the sentence: She sells seashells by the seashore.', 'sentence', 'she sells seashells by the seashore'),
            ('Pronounce the sentence: I have two cats.', 'sentence', 'i have two cats'),
            ('Pronounce the sentence: The sun sets slowly.', 'sentence', 'the sun sets slowly'),
            ('Pronounce the word: beautiful', 'word', 'beautiful'),
            ('Pronounce the sentence: We are going to the park.', 'sentence', 'we are going to the park'),
        ],
        2: [
            ('Pronounce the word: banana', 'word', 'banana'),
            ('Pronounce the word: opportunity', 'word', 'opportunity'),
            ('Pronounce the word: chaos', 'word', 'chaos'),
            ('Pronounce the word: technology', 'word', 'technology'),
            ('Pronounce the sentence: The dog barks loudly.', 'sentence', 'the dog barks loudly'),
            ('Pronounce the sentence: Peter Piper picked a peck of pickled peppers.', 'sentence', 'peter piper picked a peck of pickled peppers'),
            ('Pronounce the sentence: I love to read books.', 'sentence', 'i love to read books'),
            ('Pronounce the sentence: The moon is bright tonight.', 'sentence', 'the moon is bright tonight'),
            ('Pronounce the word: adventure', 'word', 'adventure'),
            ('Pronounce the sentence: They are playing soccer.', 'sentence', 'they are playing soccer'),
        ],
        3: [
            ('Pronounce the word: cherry', 'word', 'cherry'),
            ('Pronounce the word: responsibility', 'word', 'responsibility'),
            ('Pronounce the word: symphony', 'word', 'symphony'),
            ('Pronounce the word: discovery', 'word', 'discovery'),
            ('Pronounce the sentence: The cat sleeps peacefully.', 'sentence', 'the cat sleeps peacefully'),
            ('Pronounce the sentence: How much wood would a woodchuck chuck?', 'sentence', 'how much wood would a woodchuck chuck'),
            ('Pronounce the sentence: We went to the zoo.', 'sentence', 'we went to the zoo'),
            ('Pronounce the sentence: The stars twinkle at night.', 'sentence', 'the stars twinkle at night'),
            ('Pronounce the word: excellent', 'word', 'excellent'),
            ('Pronounce the sentence: She is singing a song.', 'sentence', 'she is singing a song'),
        ],
        4: [
            ('Pronounce the word: dragon', 'word', 'dragon'),
            ('Pronounce the word: intelligence', 'word', 'intelligence'),
            ('Pronounce the word: melody', 'word', 'melody'),
            ('Pronounce the word: innovation', 'word', 'innovation'),
            ('Pronounce the sentence: The bird flies high.', 'sentence', 'the bird flies high'),
            ('Pronounce the sentence: Sally slipped on the slick slope.', 'sentence', 'sally slipped on the slick slope'),
            ('Pronounce the sentence: I have a big dog.', 'sentence', 'i have a big dog'),
            ('Pronounce the sentence: The rain falls gently.', 'sentence', 'the rain falls gently'),
            ('Pronounce the word: fantastic', 'word', 'fantastic'),
            ('Pronounce the sentence: He is reading a book.', 'sentence', 'he is reading a book'),
        ],
        5: [
            ('Pronounce the word: elephant', 'word', 'elephant'),
            ('Pronounce the word: determination', 'word', 'determination'),
            ('Pronounce the word: harmony', 'word', 'harmony'),
            ('Pronounce the word: creativity', 'word', 'creativity'),
            ('Pronounce the sentence: The horse runs fast.', 'sentence', 'the horse runs fast'),
            ('Pronounce the sentence: Betty bought a bit of butter.', 'sentence', 'betty bought a bit of butter'),
            ('Pronounce the sentence: We saw a movie.', 'sentence', 'we saw a movie'),
            ('Pronounce the sentence: The wind blows softly.', 'sentence', 'the wind blows softly'),
            ('Pronounce the word: glorious', 'word', 'glorious'),
            ('Pronounce the sentence: They are dancing happily.', 'sentence', 'they are dancing happily'),
        ],
        6: [
            ('Pronounce the word: flower', 'word', 'flower'),
            ('Pronounce the word: collaboration', 'word', 'collaboration'),
            ('Pronounce the word: orchestra', 'word', 'orchestra'),
            ('Pronounce the word: inspiration', 'word', 'inspiration'),
            ('Pronounce the sentence: The fish swims quickly.', 'sentence', 'the fish swims quickly'),
            ('Pronounce the sentence: Fred fled from danger.', 'sentence', 'fred fled from danger'),
            ('Pronounce the sentence: I like to draw pictures.', 'sentence', 'i like to draw pictures'),
            ('Pronounce the sentence: The clouds are fluffy.', 'sentence', 'the clouds are fluffy'),
            ('Pronounce the word: magnificent', 'word', 'magnificent'),
            ('Pronounce the sentence: She is writing a letter.', 'sentence', 'she is writing a letter'),
        ],
        7: [
            ('Pronounce the word: grape', 'word', 'grape'),
            ('Pronounce the word: achievement', 'word', 'achievement'),
            ('Pronounce the word: rhythm', 'word', 'rhythm'),
            ('Pronounce the word: motivation', 'word', 'motivation'),
            ('Pronounce the sentence: The lion roars loudly.', 'sentence', 'the lion roars loudly'),
            ('Pronounce the sentence: Tim tripped on the twig.', 'sentence', 'tim tripped on the twig'),
            ('Pronounce the sentence: We have a picnic.', 'sentence', 'we have a picnic'),
            ('Pronounce the sentence: The sky is clear today.', 'sentence', 'the sky is clear today'),
            ('Pronounce the word: splendid', 'word', 'splendid'),
            ('Pronounce the sentence: He is playing the guitar.', 'sentence', 'he is playing the guitar'),
        ],
        8: [
            ('Pronounce the word: house', 'word', 'house'),
            ('Pronounce the word: perseverance', 'word', 'perseverance'),
            ('Pronounce the word: tempo', 'word', 'tempo'),
            ('Pronounce the word: imagination', 'word', 'imagination'),
            ('Pronounce the sentence: The tiger prowls silently.', 'sentence', 'the tiger prowls silently'),
            ('Pronounce the sentence: Wendy whispered softly.', 'sentence', 'wendy whispered softly'),
            ('Pronounce the sentence: I enjoy hiking.', 'sentence', 'i enjoy hiking'),
            ('Pronounce the sentence: The ocean waves crash.', 'sentence', 'the ocean waves crash'),
            ('Pronounce the word: wonderful', 'word', 'wonderful'),
            ('Pronounce the sentence: They are building a house.', 'sentence', 'they are building a house'),
        ],
    }

    for challenge_id, questions in challenge_questions.items():
        c.executemany('INSERT OR IGNORE INTO challenge_questions (challenge_id, question_text, question_type, correct_answer) VALUES (?, ?, ?, ?)', 
                     [(challenge_id, q[0], q[1], q[2]) for q in questions])

    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()