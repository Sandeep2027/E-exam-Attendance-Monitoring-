document.addEventListener('DOMContentLoaded', () => {
  // Sidebar toggle
  const sidebar = document.querySelector('.sidebar');
  const toggleBtn = document.querySelector('#sidebar-toggle');
  if (toggleBtn && sidebar) {
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('collapsed');
      document.querySelector('.main-content').classList.toggle('md:ml-64');
      document.querySelector('.main-content').classList.toggle('md:ml-16');
    });
  }

  // Webcam initialization
  let video = document.querySelector('#webcam');
  let canvas = document.querySelector('#canvas');
  if (video && canvas) {
    async function initWebcam() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        video.srcObject = stream;
        video.play();
        adjustWebcam();
      } catch (err) {
        console.error('Webcam error:', err);
        alert('Failed to access webcam');
      }
    }

    function adjustWebcam() {
      const ctx = canvas.getContext('2d');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;
      let brightness = 0;
      for (let i = 0; i < data.length; i += 4) {
        brightness += (data[i] + data[i + 1] + data[i + 2]) / 3;
      }
      brightness /= (data.length / 4);
      if (brightness < 100) {
        video.style.filter = `brightness(${Math.min(1.5, 100 / brightness)}) contrast(1.2)`;
      }
    }

    document.querySelector('#capture')?.addEventListener('click', () => {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext('2d').drawImage(video, 0, 0);
      document.querySelector('#image_data').value = canvas.toDataURL('image/png');
    });

    document.querySelector('#recapture')?.addEventListener('click', () => {
      document.querySelector('#image_data').value = '';
      canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
    });

    initWebcam();
  }

  // Test/Challenge monitoring
  if (document.querySelector('#test-page') || document.querySelector('#challenge-page')) {
    let monitoringInterval;
    async function startMonitoring(attemptId, isChallenge) {
      monitoringInterval = setInterval(async () => {
        const formData = new FormData();
        formData.append('monitor', 'true');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        canvas.getContext('2d').drawImage(video, 0, 0);
        formData.append('monitor_image', canvas.toDataURL('image/png'));

        // Audio level check
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const analyser = audioContext.createAnalyser();
        const microphone = await navigator.mediaDevices.getUserMedia({ audio: true });
        const source = audioContext.createMediaStreamSource(microphone);
        source.connect(analyser);
        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        analyser.getByteFrequencyData(dataArray);
        const audioLevel = dataArray.reduce((a, b) => a + b, 0) / dataArray.length / 255;
        formData.append('audio_level', audioLevel);

        // Network check
        const networkStatus = navigator.onLine;
        formData.append('network_status', networkStatus);

        fetch(`/test/${attemptId}`, { method: 'POST', body: formData })
          .then(response => response.json())
          .then(data => {
            if (data.paused) {
              clearInterval(monitoringInterval);
              document.querySelector('#pause-screen').classList.remove('hidden');
              document.querySelector('#pause-reason').textContent = data.remarks;
            }
          });
      }, 30000);
    }

    document.querySelector('#start-monitoring')?.addEventListener('click', () => {
      const attemptId = document.querySelector('#attempt-id').value;
      const isChallenge = document.querySelector('#challenge-page') !== null;
      startMonitoring(attemptId, isChallenge);
    });

    // Full-screen and escape handling
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const formData = new FormData();
        formData.append('pause', 'true');
        fetch(window.location.pathname, { method: 'POST', body: formData })
          .then(() => {
            document.querySelector('#pause-screen').classList.remove('hidden');
            clearInterval(monitoringInterval);
          });
      }
    });

    document.querySelector('#continue-btn')?.addEventListener('click', () => {
      const formData = new FormData();
      formData.append('continue', 'true');
      fetch(window.location.pathname, { method: 'POST', body: formData })
        .then(() => {
          document.querySelector('#pause-screen').classList.add('hidden');
          startMonitoring(document.querySelector('#attempt-id').value, document.querySelector('#challenge-page') !== null);
        });
    });
  }

  // Chart.js for My Learning
  if (document.querySelector('#graph-canvas')) {
    const ctx = document.querySelector('#graph-canvas').getContext('2d');
    const graphData = JSON.parse(document.querySelector('#graph-data').value);
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Correct', 'Wrong', 'Score'],
        datasets: [{
          label: 'Performance',
          data: [graphData.correct, graphData.wrong, graphData.score],
          backgroundColor: ['#48bb78', '#f56565', '#4299e1'],
        }]
      },
      options: {
        scales: {
          y: { beginAtZero: true, max: 100 }
        }
      }
    });
  }

  // System checks for test/challenge step 2
  if (document.querySelector('#system-checks')) {
    async function runChecks() {
      const webcamOk = !!(await navigator.mediaDevices.getUserMedia({ video: true }).catch(() => null));
      const micOk = !!(await navigator.mediaDevices.getUserMedia({ audio: true }).catch(() => null));
      const networkOk = navigator.onLine;
      const browserOk = /Chrome|Firefox|Edge|Safari/.test(navigator.userAgent);
      const checksPassed = webcamOk && micOk && networkOk && browserOk;
      document.querySelector('#checks-passed').value = checksPassed;
      document.querySelector('#webcam-check').textContent = webcamOk ? '✓' : '✗';
      document.querySelector('#mic-check').textContent = micOk ? '✓' : '✗';
      document.querySelector('#network-check').textContent = networkOk ? '✓' : '✗';
      document.querySelector('#browser-check').textContent = browserOk ? '✓' : '✗';
      if (checksPassed) {
        document.querySelector('#next-btn').classList.remove('hidden');
      }
    }
    runChecks();
  }

  // Challenge recording
  if (document.querySelector('#record-btn')) {
    let mediaRecorder;
    let recordedBlobs = [];
    const recordBtn = document.querySelector('#record-btn');
    const stopBtn = document.querySelector('#stop-btn');
    recordBtn.addEventListener('click', async () => {
      recordedBlobs = [];
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorder = new MediaRecorder(stream);
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) recordedBlobs.push(event.data);
      };
      mediaRecorder.onstop = () => {
        const blob = new Blob(recordedBlobs, { type: 'audio/wav' });
        const file = new File([blob], `challenge_audio_${Date.now()}.wav`, { type: 'audio/wav' });
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        document.querySelector('#audio-input').files = dataTransfer.files;
      };
      setTimeout(() => mediaRecorder.start(), 5000);
      setTimeout(() => {
        mediaRecorder.stop();
        stopBtn.classList.add('hidden');
        recordBtn.classList.remove('hidden');
      }, 65000);
      recordBtn.classList.add('hidden');
      stopBtn.classList.remove('hidden');
    });

    stopBtn.addEventListener('click', () => {
      mediaRecorder.stop();
      stopBtn.classList.add('hidden');
      recordBtn.classList.remove('hidden');
    });
  }
});