from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_file
import sqlite3
import os
from werkzeug.utils import secure_filename
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
import random
import time
import cv2
import numpy as np
from deepface import DeepFace
from skimage import io as skio
from skimage.filters import laplace
import speech_recognition as sr
import re
import datetime
import base64
from Levenshtein import distance as levenshtein_distance
import uuid
from PIL import Image, ImageDraw, ImageFont
import tensorflow as tf
from tensorflow.keras.applications.efficientnet import EfficientNetB0, preprocess_input
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input as preprocess_input_mobilenet
from sklearn.metrics.pairwise import cosine_similarity
import io
import json
import librosa
import noisereduce as nr
from pydub import AudioSegment
import logging
import html
from datetime import datetime, timedelta

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

app = Flask(__name__)
app.secret_key = os.urandom(24).hex()
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['CAPTCHA_FOLDER'] = 'static/captchas'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'wav', 'mp3'}

# Email configuration (replace with your credentials)
EMAIL_ADDRESS = 'pittalasandeep124@gmail.com'
EMAIL_PASSWORD = 'gisy baks rkou vpey'

class ImageComparison:
    def __init__(self):
        self.efficientnet_model = EfficientNetB0(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
        self.efficientnet_model = tf.keras.models.Model(inputs=self.efficientnet_model.input, outputs=self.efficientnet_model.output)
        
        keras_cache_dir = os.path.join(os.path.expanduser('~'), '.keras')
        mobilenet_cache_path = os.path.join(keras_cache_dir, 'models', 'mobilenet_v2_weights_tf_dim_ordering_tf_kernels_1.0_224_no_top.h5')
        if os.path.exists(mobilenet_cache_path):
            try:
                os.remove(mobilenet_cache_path)
                logging.info(f"Removed corrupted MobileNetV2 weights file: {mobilenet_cache_path}")
            except Exception as e:
                logging.error(f"Failed to remove corrupted weights file: {e}")
        
        try:
            self.background_model = MobileNetV2(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
            self.background_model = tf.keras.models.Model(inputs=self.background_model.input, outputs=self.background_model.output)
            self.use_mobilenet = True
            logging.info("Successfully initialized MobileNetV2 for background analysis")
        except Exception as e:
            logging.error(f"Error loading MobileNetV2 weights: {e}")
            self.background_model = EfficientNetB0(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
            self.background_model = tf.keras.models.Model(inputs=self.background_model.input, outputs=self.background_model.output)
            self.use_mobilenet = False
            tf.keras.backend.clear_session()

    def preprocess_image(self, image_path, target_size=(224, 224), model_type='efficientnet'):
        try:
            img = Image.open(image_path).resize(target_size)
            img_array = np.array(img)
            img_array = np.expand_dims(img_array, axis=0)
            preprocessor = preprocess_input if model_type == 'efficientnet' or not self.use_mobilenet else preprocess_input_mobilenet
            img_array = preprocessor(img_array)
            return img_array
        except Exception as e:
            logging.error(f"Error preprocessing image: {e}")
            return None

    def get_efficientnet_features(self, image_path):
        img = self.preprocess_image(image_path, model_type='efficientnet')
        if img is None:
            return None
        features = self.efficientnet_model.predict(img)
        return features.flatten()

    def get_deepface_features(self, image_path):
        try:
            embedding = DeepFace.represent(img_path=image_path, model_name='Facenet', enforce_detection=True)
            return np.array(embedding[0]['embedding'])
        except Exception as e:
            logging.error(f"DeepFace error: {e}")
            return None

    def get_background_features(self, image_path):
        img = self.preprocess_image(image_path, model_type='mobilenet' if self.use_mobilenet else 'efficientnet')
        if img is None:
            return None
        features = self.background_model.predict(img)
        return features.flatten()

    def compare_images(self, image1_path, image2_path):
        eff_features1 = self.get_efficientnet_features(image1_path)
        eff_features2 = self.get_efficientnet_features(image2_path)
        deepface_features1 = self.get_deepface_features(image1_path)
        deepface_features2 = self.get_deepface_features(image2_path)
        if eff_features1 is None or eff_features2 is None:
            return False
        results = {}
        results['efficientnet_cosine'] = cosine_similarity([eff_features1], [eff_features2])[0][0]
        if deepface_features1 is not None and deepface_features2 is not None:
            results['deepface_cosine'] = cosine_similarity([deepface_features1], [deepface_features2])[0][0]
        else:
            results['deepface_cosine'] = None
        thresholds = {'efficientnet_cosine': 0.85, 'deepface_cosine': 0.7}
        weights = {'efficientnet_cosine': 0.6, 'deepface_cosine': 0.4}
        score = weights['efficientnet_cosine'] * results['efficientnet_cosine']
        if results['deepface_cosine'] is not None:
            score += weights['deepface_cosine'] * results['deepface_cosine']
        return score > 0.75

    def analyze_background(self, image_path):
        try:
            img = skio.imread(image_path)
            gray = skio.color.rgb2gray(img)
            edges = laplace(gray)
            edge_density = np.mean(np.abs(edges))
            if edge_density > 0.1:
                return False, "Background is too cluttered"
            features = self.get_background_features(image_path)
            if features is None:
                return False, "Background analysis failed"
            return True, ""
        except Exception as e:
            return False, f"Background analysis failed: {str(e)}"

image_comparator = ImageComparison()

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def validate_image(image_path, enforce_face=True):
    try:
        img = skio.imread(image_path)
        gray = skio.color.rgb2gray(img)
        brightness = np.mean(gray) * 255
        if brightness < 60:
            return False, "Image is too dark"
        laplacian_var = laplace(gray).var()
        if laplacian_var < 100:
            return False, "Image is too blurry"
        if enforce_face:
            faces = DeepFace.extract_faces(img_path=image_path, detector_backend='opencv', enforce_detection=False)
            face_count = len(faces)
            if face_count != 1:
                return False, f"Exactly one face must be detected, found {face_count}"
        valid_bg, bg_msg = image_comparator.analyze_background(image_path)
        if not valid_bg:
            return False, bg_msg
        return True, ""
    except Exception as e:
        logging.error(f"Image validation failed: {e}")
        return False, f"Image validation failed: {str(e)}"

def adjust_image_brightness_contrast(image_path):
    try:
        img = cv2.imread(image_path)
        img_yuv = cv2.cvtColor(img, cv2.COLOR_BGR2YUV)
        img_yuv[:,:,0] = cv2.equalizeHist(img_yuv[:,:,0])
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))
        l = clahe.apply(l)
        lab = cv2.merge((l,a,b))
        img_adjusted = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
        result = cv2.cvtColor(img_adjusted, cv2.COLOR_BGR2LAB)
        avg_a = np.average(result[:, :, 1])
        avg_b = np.average(result[:, :, 2])
        result[:, :, 1] = result[:, :, 1] - ((avg_a - 128) * (result[:, :, 0] / 255.0) * 1.1)
        result[:, :, 2] = result[:, :, 2] - ((avg_b - 128) * (result[:, :, 0] / 255.0) * 1.1)
        img_adjusted = cv2.cvtColor(result, cv2.COLOR_LAB2BGR)
        cv2.imwrite(image_path, img_adjusted)
    except Exception as e:
        logging.error(f"Image adjustment failed: {e}")

def enhance_audio(audio_path):
    try:
        audio = AudioSegment.from_file(audio_path)
        normalized_audio = audio.normalize()
        y, sr = librosa.load(audio_path)
        reduced_noise = nr.reduce_noise(y=y, sr=sr)
        enhanced_path = audio_path.replace('.wav', '_enhanced.wav')
        librosa.output.write_wav(enhanced_path, reduced_noise, sr)
        return enhanced_path
    except Exception as e:
        logging.error(f"Audio enhancement failed: {e}")
        return audio_path

def extract_text_from_audio(audio_path):
    try:
        enhanced_path = enhance_audio(audio_path)
        recognizer = sr.Recognizer()
        with sr.AudioFile(enhanced_path) as source:
            audio_data = recognizer.record(source)
            text = recognizer.recognize_google(audio_data, show_all=True)
            if isinstance(text, dict) and 'alternative' in text:
                return text['alternative'][0]['transcript'].lower(), text['alternative'][0]['confidence']
            return text.lower(), 0.0
    except Exception as e:
        logging.error(f"Audio transcription failed: {e}")
        return "", 0.0

def generate_badge(test_name, user_name, score, certificate_id, achievement_type):
    colors = [
        {'bg': '#e8f4f8', 'border': '#0288d1', 'text': '#01579b'},
        {'bg': '#f0f4c3', 'border': '#689f38', 'text': '#33691e'},
        {'bg': '#fce4ec', 'border': '#d81b60', 'text': '#880e4f'}
    ]
    color = random.choice(colors)
    img = Image.new('RGB', (800, 600), color=color['bg'])
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype('static/fonts/arial.ttf', 40)
        small_font = ImageFont.truetype('static/fonts/arial.ttf', 30)
        tiny_font = ImageFont.truetype('static/fonts/arial.ttf', 20)
    except:
        font = ImageFont.load_default()
        small_font = ImageFont.load_default()
        tiny_font = ImageFont.load_default()
    draw.rectangle([(50, 50), (750, 550)], outline=color['border'], width=5)
    draw.text((400, 100), f"Certificate of {achievement_type}", font=font, fill=color['text'], anchor='mm')
    draw.text((400, 200), f"{user_name}", font=small_font, fill=color['text'], anchor='mm')
    draw.text((400, 250), f"Successfully Completed", font=small_font, fill=color['text'], anchor='mm')
    draw.text((400, 300), f"{test_name}", font=small_font, fill=color['text'], anchor='mm')
    draw.text((400, 350), f"Score: {score}%", font=small_font, fill=color['text'], anchor='mm')
    draw.text((400, 400), f"Certificate ID: {certificate_id}", font=small_font, fill=color['text'], anchor='mm')
    draw.text((400, 500), "Issued by: E-Exam", font=tiny_font, fill=color['text'], anchor='mm')
    badge_path = os.path.join(app.config['UPLOAD_FOLDER'], f"badge_{certificate_id}.png")
    img.save(badge_path)
    return badge_path

def send_email(to_email, subject, body, html_body=None, attachment_path=None):
    msg = MIMEMultipart()
    msg['From'] = EMAIL_ADDRESS
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))
    if html_body:
        msg.attach(MIMEText(html_body, 'html'))
    if attachment_path:
        try:
            with open(attachment_path, 'rb') as f:
                img = MIMEImage(f.read())
                img.add_header('Content-Disposition', 'attachment', filename=os.path.basename(attachment_path))
                msg.attach(img)
        except Exception as e:
            logging.error(f"Failed to attach file to email: {e}")
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        server.sendmail(EMAIL_ADDRESS, to_email, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        logging.error(f"Email sending failed: {e}")
        return False

def validate_password(password):
    return (len(password) >= 6 and
            re.search(r"[A-Z]", password) and
            re.search(r"[a-z]", password) and
            re.search(r"\d", password) and
            re.search(r"[!@#$%^&*(),.?\":{}|<>]", password))

def validate_email(email):
    return bool(re.match(r'^[a-zA-Z0-9._%+-]+@gmail\.com$', email))

def validate_mobile(mobile):
    return len(mobile) == 10 and mobile.isdigit()

def sanitize_input(input_str):
    return html.escape(str(input_str).strip())

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

'''def generate_captcha():
    # Generate two random numbers and an operator
    num1 = random.randint(1, 20)
    num2 = random.randint(1, 20)
    operator = random.choice(['+', '-', '*', '%'])
    
    # Compute the result
    if operator == '+':
        result = num1 + num2
    elif operator == '-':
        result = num1 - num2
    elif operator == '*':
        result = num1 * num2
    elif operator == '%':
        # Ensure num2 is not zero for modulo
        num2 = num2 if num2 != 0 else 1
        result = num1 % num2
    
    # Create the CAPTCHA text (e.g., "5 + 3 = ?")
    captcha_text = f"{num1} {operator} {num2} = ?"
    captcha_result = str(result)
    captcha_filename = f"captcha_{uuid.uuid4()}.png"
    captcha_path = os.path.join(app.config['CAPTCHA_FOLDER'], captcha_filename)
    
    try:
        img = Image.new('RGB', (200, 60), color=(245, 245, 245))
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype('static/fonts/arial.ttf', 32)
        except:
            font = ImageFont.load_default()
        
        # Minimal noise for readability
        for _ in range(5):
            x1, y1 = random.randint(0, 200), random.randint(0, 60)
            x2, y2 = random.randint(0, 200), random.randint(0, 60)
            draw.line((x1, y1, x2, y2), fill=(200, 200, 200), width=1)
        for _ in range(20):
            x, y = random.randint(0, 200), random.randint(0, 60)
            draw.point((x, y), fill=(200, 200, 200))
        
        # Draw text with slight rotation
        for i, char in enumerate(captcha_text):
            x = 20 + i * 15
            y = 30
            angle = random.uniform(-5, 5)
            char_img = Image.new('RGBA', (30, 30), (0, 0, 0, 0))
            char_draw = ImageDraw.Draw(char_img)
            char_draw.text((5, 5), char, font=font, fill=(0, 0, 0, 255))
            char_img = char_img.rotate(angle, expand=1)
            img.paste(char_img, (x, y), char_img)
        
        img.save(captcha_path)
    except Exception as e:
        logging.error(f"Failed to generate CAPTCHA: {e}")
        raise RuntimeError("CAPTCHA generation failed")
    
    # Clean up old CAPTCHAs
    try:
        now = time.time()
        for f in os.listdir(app.config['CAPTCHA_FOLDER']):
            f_path = os.path.join(app.config['CAPTCHA_FOLDER'], f)
            if os.path.isfile(f_path) and now - os.path.getmtime(f_path) > 3600:
                os.remove(f_path)
                logging.info(f"Removed old CAPTCHA file: {f_path}")
    except Exception as e:
        logging.error(f"Failed to clean up CAPTCHA files: {e}")
    
    session['captcha_result'] = captcha_result
    session['captcha_time'] = time.time()
    return captcha_filename'''

@app.route('/')
def index():
    return render_template('index.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/about')
def about():
    return render_template('about.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        email = sanitize_input(request.form.get('email'))
        subject = sanitize_input(request.form.get('subject'))
        message = sanitize_input(request.form.get('message'))
        if not all([email, subject, message]):
            flash('All fields are required', 'danger')
            return render_template('contact.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
        if not validate_email(email):
            flash('Invalid Gmail address', 'danger')
            return render_template('contact.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
        try:
            with get_db_connection() as conn:
                conn.execute('INSERT INTO queries (email, subject, message) VALUES (?, ?, ?)', (email, subject, message))
                conn.commit()
            html_body = """
            <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                <h2 style="color: #2ecc71;">Query Received</h2>
                <p>Thank you for contacting us. We have received your query and will respond soon.</p>
            </div>
            """
            send_email(email, "Query Received", "Successfully sent your query. We will check it soon.", html_body)
            send_email('sandeeppittala2707@gmail.com', "New Query", f"Email: {email}\nSubject: {subject}\nMessage: {message}")
            flash('Query submitted successfully', 'success')
            return redirect(url_for('contact'))
        except Exception as e:
            logging.error(f"Failed to process contact form: {e}")
            flash('An error occurred. Please try again.', 'danger')
    return render_template('contact.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = sanitize_input(request.form.get('email'))
        password = request.form.get('password')
        role = request.form.get('role')
        if not all([email, password, role]):
            flash('All fields are required', 'danger')
            return render_template('login.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
        if not validate_email(email):
            flash('Invalid Gmail address', 'danger')
            return render_template('login.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
        try:
            with get_db_connection() as conn:
                if role == 'user':
                    user = conn.execute('SELECT * FROM users WHERE email = ? AND password = ?', (email, password)).fetchone()
                else:
                    user = conn.execute('SELECT * FROM admins WHERE email = ? AND password = ?', (email, password)).fetchone()
                if user:
                    session['user_id'] = user['id']
                    session['role'] = role
                    session['user'] = {
                        'profile_image': user['profile_image'] if role == 'user' else 'static/images/default_admin.png',
                        'username': user['username'],
                        'hall_ticket': user.get('hall_ticket', ''),
                        'name': user['name']
                    }
                    flash('Login successful', 'success')
                    return redirect(url_for('user_dashboard') if role == 'user' else url_for('admin_dashboard'))
                else:
                    flash('Invalid credentials', 'danger')
        except Exception as e:
            logging.error(f"Login error: {e}")
            flash('An error occurred. Please try again.', 'danger')
    return render_template('login.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    step = 1
    email = ''
    if request.method == 'POST':
        if 'email' in request.form:
            email = sanitize_input(request.form.get('email'))
            if not validate_email(email):
                flash('Invalid Gmail address', 'danger')
                return render_template('forgot_password.html', step=step, email=email, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            try:
                with get_db_connection() as conn:
                    user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
                    if user:
                        otp = str(random.randint(100000, 999999))
                        session['otp'] = otp
                        session['otp_email'] = email
                        session['otp_time'] = time.time()
                        html_body = f"""
                        <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                            <h2 style="color: #2ecc71;">Password Reset OTP</h2>
                            <p>Your OTP is <strong>{otp}</strong>. It is valid for 5 minutes.</p>
                        </div>
                        """
                        send_email(email, "Password Reset OTP", f"Your OTP is {otp}", html_body)
                        step = 2
                    else:
                        flash('Email not found', 'danger')
            except Exception as e:
                logging.error(f"Forgot password error: {e}")
                flash('An error occurred. Please try again.', 'danger')
        elif 'otp' in request.form:
            otp = request.form.get('otp').strip()
            if 'resend' in request.form:
                otp = str(random.randint(100000, 999999))
                session['otp'] = otp
                session['otp_time'] = time.time()
                html_body = f"""
                <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                    <h2 style="color: #2ecc71;">Password Reset OTP</h2>
                    <p>Your new OTP is <strong>{otp}</strong>. It is valid for 5 minutes.</p>
                </div>
                """
                send_email(session['otp_email'], "Password Reset OTP", f"Your OTP is {otp}", html_body)
                flash('OTP resent', 'success')
            elif otp == session.get('otp') and time.time() - session.get('otp_time') < 300:
                return redirect(url_for('reset_password'))
            else:
                flash('Invalid or expired OTP', 'danger')
    remaining_time = 300 - (time.time() - session.get('otp_time', time.time()))
    return render_template('forgot_password.html', step=step, email=email, remaining_time=remaining_time, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    if 'otp_email' not in session:
        flash('Session expired. Please start over.', 'danger')
        return redirect(url_for('forgot_password'))
    if request.method == 'POST':
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
        elif not validate_password(password):
            flash('Password must be at least 6 characters with uppercase, lowercase, digit, and special character', 'danger')
        else:
            try:
                with get_db_connection() as conn:
                    conn.execute('UPDATE users SET password = ? WHERE email = ?', (password, session['otp_email']))
                    conn.commit()
                flash('Password reset successfully', 'success')
                session.pop('otp_email', None)
                session.pop('otp', None)
                session.pop('otp_time', None)
                return redirect(url_for('login'))
            except Exception as e:
                logging.error(f"Reset password error: {e}")
                flash('An error occurred. Please try again.', 'danger')
    return render_template('reset_password.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/register', methods=['GET', 'POST'])
def register():
    step = session.get('register_step', 1)
    if request.method == 'POST':
        if step == 1:
            data = {
                'name': sanitize_input(request.form.get('name', '')),
                'email': sanitize_input(request.form.get('email', '')),
                'username': sanitize_input(request.form.get('username', '')),
                'mobile': sanitize_input(request.form.get('mobile', '')),
                'degree': sanitize_input(request.form.get('degree', '')),
                'course': sanitize_input(request.form.get('course', '')),
                'college': sanitize_input(request.form.get('college', '')),
                'branch': sanitize_input(request.form.get('branch', '')),
                'hall_ticket': sanitize_input(request.form.get('hall_ticket', '')),
                'semester': sanitize_input(request.form.get('semester', '')),
                'cgpa': sanitize_input(request.form.get('cgpa', '')),
                'location': sanitize_input(request.form.get('location', '')),
                'address': sanitize_input(request.form.get('address', '')),
                'state': sanitize_input(request.form.get('state', '')),
                'terms': request.form.get('terms', '')
            }
            if data['terms'] != 'on':
                flash('You must agree to the terms and conditions', 'danger')
                return render_template('register.html', data=data, step=1, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            if not all([data['name'], data['email'], data['username'], data['mobile'], data['degree'], data['course'], data['college'], data['branch'], data['hall_ticket'], data['semester'], data['cgpa'], data['location'], data['address'], data['state']]):
                flash('All fields are required', 'danger')
                return render_template('register.html', data=data, step=1, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            if not validate_email(data['email']):
                flash('Email must be a valid Gmail address', 'danger')
                return render_template('register.html', data=data, step=1, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            if not validate_mobile(data['mobile']):
                flash('Mobile number must be exactly 10 digits', 'danger')
                return render_template('register.html', data=data, step=1, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            try:
                with get_db_connection() as conn:
                    existing_user = conn.execute('SELECT * FROM users WHERE email = ? OR username = ?', (data['email'], data['username'])).fetchone()
                    if existing_user:
                        flash('Email or username already exists', 'danger')
                        return render_template('register.html', data=data, step=1, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
                session['register_data'] = data
                session['register_step'] = 2
                flash('Please upload or capture profile and ID card images', 'info')
                return render_template('register.html', data=data, step=2, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            except Exception as e:
                logging.error(f"Registration step 1 error: {e}")
                flash('An error occurred. Please try again.', 'danger')
        elif step == 2:
            profile_image_data = request.form.get('profile_image_data', '')
            id_card_image_data = request.form.get('id_card_image_data', '')
            profile_file = request.files.get('profile_image_file')
            id_card_file = request.files.get('id_card_image_file')
            profile_path = id_card_path = None
            session['profile_filename'] = session['id_card_filename'] = ''
            session['profile_preview'] = session['id_card_preview'] = ''
            
            # Handle profile image (file or capture)
            if profile_file and allowed_file(profile_file.filename):
                try:
                    profile_filename = f"profile_{session['register_data']['username']}_{uuid.uuid4()}.{profile_file.filename.rsplit('.', 1)[1].lower()}"
                    profile_path = os.path.join(app.config['UPLOAD_FOLDER'], profile_filename)
                    profile_file.save(profile_path)
                    adjust_image_brightness_contrast(profile_path)
                    valid, msg = validate_image(profile_path, enforce_face=True)
                    if not valid:
                        flash(f"Profile image: {msg}", 'danger')
                        return render_template('register.html', data=session['register_data'], captcha_image=captcha_filename, step=2, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
                    session['profile_filename'] = profile_filename
                except Exception as e:
                    logging.error(f"Profile file upload error: {e}")
                    flash('Failed to process profile image file', 'danger')
            elif profile_image_data:
                try:
                    profile_image_data = profile_image_data.split(',')[1]
                    profile_filename = f"profile_{session['register_data']['username']}_{uuid.uuid4()}.jpg"
                    profile_path = os.path.join(app.config['UPLOAD_FOLDER'], profile_filename)
                    with open(profile_path, 'wb') as f:
                        f.write(base64.b64decode(profile_image_data))
                    adjust_image_brightness_contrast(profile_path)
                    valid, msg = validate_image(profile_path, enforce_face=True)
                    if not valid:
                        flash(f"Profile image: {msg}", 'danger')
                        return render_template('register.html', data=session['register_data'], captcha_image=captcha_filename, step=2, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
                    session['profile_preview'] = profile_image_data
                except Exception as e:
                    logging.error(f"Profile image capture error: {e}")
                    flash('Failed to process profile image capture', 'danger')
            
            # Handle ID card image (file or capture)
            if id_card_file and allowed_file(id_card_file.filename):
                try:
                    id_card_filename = f"id_card_{session['register_data']['username']}_{uuid.uuid4()}.{id_card_file.filename.rsplit('.', 1)[1].lower()}"
                    id_card_path = os.path.join(app.config['UPLOAD_FOLDER'], id_card_filename)
                    id_card_file.save(id_card_path)
                    adjust_image_brightness_contrast(id_card_path)
                    valid, msg = validate_image(id_card_path, enforce_face=False)
                    if not valid:
                        flash(f"ID card image: {msg}", 'danger')
                        return render_template('register.html', data=session['register_data'], captcha_image=captcha_filename, step=2, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
                    session['id_card_filename'] = id_card_filename
                except Exception as e:
                    logging.error(f"ID card file upload error: {e}")
                    flash('Failed to process ID card image file', 'danger')
            elif id_card_image_data:
                try:
                    id_card_image_data = id_card_image_data.split(',')[1]
                    id_card_filename = f"id_card_{session['register_data']['username']}_{uuid.uuid4()}.jpg"
                    id_card_path = os.path.join(app.config['UPLOAD_FOLDER'], id_card_filename)
                    with open(id_card_path, 'wb') as f:
                        f.write(base64.b64decode(id_card_image_data))
                    adjust_image_brightness_contrast(id_card_path)
                    valid, msg = validate_image(id_card_path, enforce_face=False)
                    if not valid:
                        flash(f"ID card image: {msg}", 'danger')
                        return render_template('register.html', data=session['register_data'], captcha_image=captcha_filename, step=2, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
                    session['id_card_preview'] = id_card_image_data
                except Exception as e:
                    logging.error(f"ID card image capture error: {e}")
                    flash('Failed to process ID card image capture', 'danger')
            
            if not profile_path or not id_card_path:
                flash('Both profile and ID card images are required', 'danger')
                return render_template('register.html', data=session['register_data'], captcha_image=captcha_filename, step=2, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            session['profile_path'] = profile_path
            session['id_card_path'] = id_card_path
            otp = str(random.randint(100000, 999999))
            session['otp'] = otp
            session['otp_email'] = session['register_data']['email']
            session['otp_time'] = time.time()
            html_body = f"""
            <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                <h2 style="color: #2ecc71;">Registration OTP</h2>
                <p>Your OTP is <strong>{otp}</strong>. It is valid for 5 minutes.</p>
            </div>
            """
            if send_email(session['register_data']['email'], "Registration OTP", f"Your OTP is {otp}", html_body):
                session['register_step'] = 3
                flash('Please verify OTP', 'info')
                return redirect(url_for('verify_otp'))
            else:
                flash('Failed to send OTP. Please try again.', 'danger')
                return render_template('register.html', data=session['register_data'], step=2, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
    return render_template('register.html', data=session.get('register_data', {}), step=step, profile_filename=session.get('profile_filename', ''), id_card_filename=session.get('id_card_filename', ''), profile_preview=session.get('profile_preview', ''), id_card_preview=session.get('id_card_preview', ''), logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/verify_otp', methods=['GET', 'POST'])
def verify_otp():
    if 'otp_email' not in session:
        flash('Session expired. Please start over.', 'danger')
        return redirect(url_for('register'))
    if request.method == 'POST':
        otp = request.form.get('otp').strip()
        if 'resend' in request.form:
            otp = str(random.randint(100000, 999999))
            session['otp'] = otp
            session['otp_time'] = time.time()
            html_body = f"""
            <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                <h2 style="color: #2ecc71;">Registration OTP</h2>
                <p>Your new OTP is <strong>{otp}</strong>. It is valid for 5 minutes.</p>
            </div>
            """
            send_email(session['otp_email'], "Registration OTP", f"Your OTP is {otp}", html_body)
            flash('OTP resent', 'success')
        elif otp == session.get('otp') and time.time() - session.get('otp_time') < 300:
            session['register_step'] = 4
            return redirect(url_for('set_password'))
        else:
            flash('Invalid or expired OTP', 'danger')
    return render_template('verify_otp.html', remaining_time=300 - (time.time() - session.get('otp_time', time.time())), logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/set_password', methods=['GET', 'POST'])
def set_password():
    if 'otp_email' not in session or 'register_data' not in session:
        flash('Session expired. Please start over.', 'danger')
        return redirect(url_for('register'))
    if request.method == 'POST':
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
        elif not validate_password(password):
            flash('Password must be at least 6 characters with uppercase, lowercase, digit, and special character', 'danger')
        else:
            try:
                with get_db_connection() as conn:
                    data = session['register_data']
                    conn.execute('''
                        INSERT INTO users (name, email, username, mobile, degree, course, college, branch, hall_ticket, semester, cgpa, location, address, state, profile_image, id_card_image, password)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        data['name'], data['email'], data['username'], data['mobile'], data['degree'], data['course'],
                        data['college'], data['branch'], data['hall_ticket'], data['semester'], data['cgpa'],
                        data['location'], data['address'], data['state'], session['profile_path'], session['id_card_path'], password
                    ))
                    conn.commit()
                flash('Registration successful. Please login.', 'success')
                session.pop('register_data', None)
                session.pop('register_step', None)
                session.pop('otp', None)
                session.pop('otp_email', None)
                session.pop('otp_time', None)
                session.pop('profile_path', None)
                session.pop('id_card_path', None)
                session.pop('profile_filename', None)
                session.pop('id_card_filename', None)
                session.pop('profile_preview', None)
                session.pop('id_card_preview', None)
                return redirect(url_for('login'))
            except Exception as e:
                logging.error(f"Set password error: {e}")
                flash('An error occurred. Please try again.', 'danger')
    return render_template('set_password.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'success')
    return redirect(url_for('index'))

@app.route('/user_dashboard')
def user_dashboard():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            # Get enrolled tests not yet completed
            tests = conn.execute('''
                SELECT t.id, t.name, t.duration, t.description, te.date, te.start_time, te.end_time
                FROM test_enrollments te
                JOIN tests t ON te.test_id = t.id
                WHERE te.user_id = ? AND te.id NOT IN (
                    SELECT attempt.test_id FROM test_attempts attempt WHERE attempt.user_id = ?
                ) AND te.end_time > ?
            ''', (session['user_id'], session['user_id'], datetime.now().strftime('%Y-%m-%d %H:%M:%S'))).fetchall()
            
            # Get enrolled challenges not yet completed
            challenges = conn.execute('''
                SELECT c.id, c.name, c.duration, c.description, ce.date, ce.start_time, ce.end_time
                FROM challenge_enrollments ce
                JOIN challenges c ON ce.challenge_id = c.id
                WHERE ce.user_id = ? AND ce.id NOT IN (
                    SELECT attempt.challenge_id FROM challenge_attempts attempt WHERE attempt.user_id = ?
                ) AND ce.end_time > ?
            ''', (session['user_id'], session['user_id'], datetime.now().strftime('%Y-%m-%d %H:%M:%S'))).fetchall()
        return render_template('user_dashboard.html', tests=tests, challenges=challenges, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"User dashboard error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('index'))

@app.route('/my_learning')
def my_learning():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            # Get completed test attempts
            test_attempts = conn.execute('''
                SELECT t.id, t.name, ta.score, ta.date, ta.id as attempt_id
                FROM test_attempts ta
                JOIN tests t ON ta.test_id = t.id
                WHERE ta.user_id = ?
            ''', (session['user_id'],)).fetchall()
            
            # Get completed challenge attempts
            challenge_attempts = conn.execute('''
                SELECT c.id, c.name, ca.score, ca.date, ca.id as attempt_id
                FROM challenge_attempts ca
                JOIN challenges c ON ca.challenge_id = c.id
                WHERE ca.user_id = ?
            ''', (session['user_id'],)).fetchall()
            
            # Get achievements for badge download
            achievements = conn.execute('''
                SELECT certificate_id, test_name, score, type
                FROM achievements
                WHERE user_name = ? AND score >= 80
            ''', (session['user']['name'],)).fetchall()
        return render_template('my_learning.html', test_attempts=test_attempts, challenge_attempts=challenge_attempts, achievements=achievements, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"My learning error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('user_dashboard'))

@app.route('/attempt_details/<attempt_type>/<int:attempt_id>')
def attempt_details(attempt_type, attempt_id):
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            if attempt_type == 'test':
                attempt = conn.execute('''
                    SELECT t.name, ta.score, ta.date, ta.remarks
                    FROM test_attempts ta
                    JOIN tests t ON ta.test_id = t.id
                    WHERE ta.id = ? AND ta.user_id = ?
                ''', (attempt_id, session['user_id'])).fetchone()
                answers = conn.execute('''
                    SELECT tq.question_text, tq.option_1, tq.option_2, tq.option_3, tq.option_4, tq.correct_option, ta.answer
                    FROM test_answers ta
                    JOIN test_questions tq ON ta.question_id = tq.id
                    WHERE ta.attempt_id = ?
                ''', (attempt_id,)).fetchall()
                correct = sum(1 for ans in answers if ans['answer'] == ans['correct_option'])
                total = len(answers)
                wrong = total - correct
            else:
                attempt = conn.execute('''
                    SELECT c.name, ca.score, ca.date, ca.remarks
                    FROM challenge_attempts ca
                    JOIN challenges c ON ca.challenge_id = c.id
                    WHERE ca.id = ? AND ca.user_id = ?
                ''', (attempt_id, session['user_id'])).fetchone()
                answers = conn.execute('''
                    SELECT cq.question_text, cq.correct_answer, ca.answer, ca.score as answer_score
                    FROM challenge_answers ca
                    JOIN challenge_questions cq ON ca.question_id = cq.id
                    WHERE ca.attempt_id = ?
                ''', (attempt_id,)).fetchall()
                correct = sum(1 for ans in answers if ans['answer_score'] >= 80)
                total = len(answers)
                wrong = total - correct
            if not attempt:
                flash('Attempt not found', 'danger')
                return redirect(url_for('my_learning'))
            chart_data = {
                'correct': correct / total * 100 if total > 0 else 0,
                'wrong': wrong / total * 100 if total > 0 else 0,
                'score': attempt['score']
            }
        return render_template('attempt_details.html', attempt=attempt, answers=answers, chart_data=chart_data, attempt_type=attempt_type, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"Attempt details error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('my_learning'))

@app.route('/download_badge/<certificate_id>')
def download_badge(certificate_id):
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user', 'danger')
        return redirect(url_for('login'))
    badge_path = os.path.join(app.config['UPLOAD_FOLDER'], f"badge_{certificate_id}.png")
    if os.path.exists(badge_path):
        return send_file(badge_path, as_attachment=True)
    flash('Badge not found', 'danger')
    return redirect(url_for('my_learning'))

@app.route('/attendance')
def attendance():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            tests = conn.execute('''
                SELECT t.name, ta.date, t.duration, ta.score, ta.time
                FROM test_attempts ta
                JOIN tests t ON ta.test_id = t.id
                WHERE ta.user_id = ?
            ''', (session['user_id'],)).fetchall()
            challenges = conn.execute('''
                SELECT c.name, ca.date, c.duration, ca.score, ca.time
                FROM challenge_attempts ca
                JOIN challenges c ON ca.challenge_id = c.id
                WHERE ca.user_id = ?
            ''', (session['user_id'],)).fetchall()
        return render_template('attendance.html', tests=tests, challenges=challenges, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"Attendance error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('user_dashboard'))

@app.route('/material')
def material():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user', 'danger')
        return redirect(url_for('login'))
    # Placeholder course data
    courses = [
        {'name': 'Python Basics', 'notes': 'python_notes.pdf', 'recording': 'python_session.mp4'},
        {'name': 'Java Fundamentals', 'notes': 'java_notes.pdf', 'recording': 'java_session.mp4'},
    ]
    return render_template('material.html', courses=courses, logged_in=True, user_role=session['role'], user=session['user'])

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
            if not user:
                flash('User not found', 'danger')
                return redirect(url_for('logout'))
            if request.method == 'POST':
                if 'update_info' in request.form:
                    data = {
                        'name': sanitize_input(request.form.get('name')),
                        'mobile': sanitize_input(request.form.get('mobile')),
                        'degree': sanitize_input(request.form.get('degree')),
                        'course': sanitize_input(request.form.get('course')),
                        'college': sanitize_input(request.form.get('college')),
                        'branch': sanitize_input(request.form.get('branch')),
                        'hall_ticket': sanitize_input(request.form.get('hall_ticket')),
                        'semester': sanitize_input(request.form.get('semester')),
                        'cgpa': sanitize_input(request.form.get('cgpa')),
                        'location': sanitize_input(request.form.get('location')),
                        'address': sanitize_input(request.form.get('address')),
                        'state': sanitize_input(request.form.get('state')),
                    }
                    if not all(data.values()):
                        flash('All fields are required', 'danger')
                        return render_template('profile.html', db_user=user, logged_in=True, user_role=session['role'], session_user=session['user'])
                    if not validate_mobile(data['mobile']):
                        flash('Mobile number must be exactly 10 digits', 'danger')
                        return render_template('profile.html', db_user=user, logged_in=True, user_role=session['role'], session_user=session['user'])
                    conn.execute('''
                        UPDATE users SET name = ?, mobile = ?, degree = ?, course = ?, college = ?, branch = ?,
                        hall_ticket = ?, semester = ?, cgpa = ?, location = ?, address = ?, state = ?
                        WHERE id = ?
                    ''', (*data.values(), session['user_id']))
                    conn.commit()
                    session['user']['name'] = data['name']
                    session['user']['hall_ticket'] = data['hall_ticket']
                    flash('Profile updated successfully', 'success')
                elif 'update_password' in request.form:
                    current_password = request.form.get('current_password')
                    new_password = request.form.get('new_password')
                    confirm_password = request.form.get('confirm_password')
                    if current_password != user['password']:
                        flash('Current password is incorrect', 'danger')
                    elif new_password != confirm_password:
                        flash('New passwords do not match', 'danger')
                    elif not validate_password(new_password):
                        flash('New password must be at least 6 characters with uppercase, lowercase, digit, and special character', 'danger')
                    else:
                        conn.execute('UPDATE users SET password = ? WHERE id = ?', (new_password, session['user_id']))
                        conn.commit()
                        flash('Password updated successfully', 'success')
            user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
        return render_template('profile.html', db_user=user, logged_in=True, user_role=session['role'], session_user=session['user'])
    except Exception as e:
        logging.error(f"Profile error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('user_dashboard'))

@app.route('/admin_dashboard')
def admin_dashboard():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin', 'danger')
        return redirect(url_for('login'))
    return render_template('admin_dashboard.html', logged_in=True, user_role=session['role'], user=session['user'])

@app.route('/add_test', methods=['GET', 'POST'])
def add_test():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        name = sanitize_input(request.form.get('name'))
        questions = []
        i = 0
        while f'question_{i}' in request.form:
            question_text = sanitize_input(request.form.get(f'question_{i}'))
            option_1 = sanitize_input(request.form.get(f'option_1_{i}'))
            option_2 = sanitize_input(request.form.get(f'option_2_{i}'))
            option_3 = sanitize_input(request.form.get(f'option_3_{i}'))
            option_4 = sanitize_input(request.form.get(f'option_4_{i}'))
            correct_option = int(request.form.get(f'correct_option_{i}', 0))
            if question_text and all([option_1, option_2, option_3, option_4]) and correct_option in [1, 2, 3, 4]:
                questions.append((question_text, option_1, option_2, option_3, option_4, correct_option))
            i += 1
        if not name or not questions:
            flash('Test name and at least one valid question are required', 'danger')
            return render_template('add_test.html', logged_in=True, user_role=session['role'], user=session['user'])
        try:
            with get_db_connection() as conn:
                duration = len(questions) * 60  # 1 minute per question
                cursor = conn.execute('INSERT INTO tests (name, duration, description) VALUES (?, ?, ?)', (name, duration, f'Test on {name}'))
                test_id = cursor.lastrowid
                conn.executemany('''
                    INSERT INTO test_questions (test_id, question_text, option_1, option_2, option_3, option_4, correct_option)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', [(test_id, *q) for q in questions])
                conn.commit()
            flash('Test added successfully', 'success')
            return redirect(url_for('admin_dashboard'))
        except Exception as e:
            logging.error(f"Add test error: {e}")
            flash('An error occurred. Please try again.', 'danger')
    return render_template('add_test.html', logged_in=True, user_role=session['role'], user=session['user'])

@app.route('/enrolled_tests', methods=['GET', 'POST'])
def enrolled_tests():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            tests = conn.execute('SELECT id, name FROM tests').fetchall()
            if request.method == 'POST':
                test_id = request.form.get('test_id')
                date = request.form.get('date')
                start_time = request.form.get('start_time')
                end_time = request.form.get('end_time')
                if not all([test_id, date, start_time, end_time]):
                    flash('All fields are required', 'danger')
                    return render_template('enrolled_tests.html', tests=tests, logged_in=True, user_role=session['role'], user=session['user'])
                test = conn.execute('SELECT name FROM tests WHERE id = ?', (test_id,)).fetchone()
                if not test:
                    flash('Invalid test', 'danger')
                    return render_template('enrolled_tests.html', tests=tests, logged_in=True, user_role=session['role'], user=session['user'])
                # Check if test is already enrolled and not expired
                existing = conn.execute('''
                    SELECT id FROM test_enrollments
                    WHERE test_id = ? AND end_time > ?
                ''', (test_id, datetime.now().strftime('%Y-%m-%d %H:%M:%S'))).fetchone()
                if existing:
                    flash('Test is already enrolled and not expired', 'danger')
                    return render_template('enrolled_tests.html', tests=tests, logged_in=True, user_role=session['role'], user=session['user'])
                conn.execute('''
                    INSERT INTO test_enrollments (test_id, date, start_time, end_time)
                    VALUES (?, ?, ?, ?)
                ''', (test_id, date, start_time, end_time))
                conn.commit()
                # Notify users
                users = conn.execute('SELECT email FROM users').fetchall()
                html_body = f"""
                <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                    <h2 style="color: #2ecc71;">New Test Enrollment</h2>
                    <p>Test: {test['name']}</p>
                    <p>Date: {date}</p>
                    <p>Start Time: {start_time}</p>
                    <p>End Time: {end_time}</p>
                </div>
                """
                for user in users:
                    send_email(user['email'], "New Test Enrollment", f"New test enrolled: {test['name']}", html_body)
                flash('Test enrolled successfully', 'success')
                return redirect(url_for('admin_dashboard'))
        return render_template('enrolled_tests.html', tests=tests, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"Enroll test error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/add_challenge', methods=['GET', 'POST'])
def add_challenge():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        name = sanitize_input(request.form.get('name'))
        questions = []
        i = 0
        while f'question_{i}' in request.form:
            question_text = sanitize_input(request.form.get(f'question_{i}'))
            question_type = request.form.get(f'question_type_{i}')
            correct_answer = sanitize_input(request.form.get(f'correct_answer_{i}'))
            if question_text and question_type in ['word', 'sentence'] and correct_answer:
                questions.append((question_text, question_type, correct_answer))
            i += 1
        if not name or not questions:
            flash('Challenge name and at least one valid question are required', 'danger')
            return render_template('add_challenge.html', logged_in=True, user_role=session['role'], user=session['user'])
        try:
            with get_db_connection() as conn:
                duration = len(questions) * 60  # 1 minute per question
                cursor = conn.execute('INSERT INTO challenges (name, duration, description) VALUES (?, ?, ?)', (name, duration, f'Challenge on {name}'))
                challenge_id = cursor.lastrowid
                conn.executemany('''
                    INSERT INTO challenge_questions (challenge_id, question_text, question_type, correct_answer)
                    VALUES (?, ?, ?, ?)
                ''', [(challenge_id, q[0], q[1], q[2]) for q in questions])
                conn.commit()
            flash('Challenge added successfully', 'success')
            return redirect(url_for('admin_dashboard'))
        except Exception as e:
            logging.error(f"Add challenge error: {e}")
            flash('An error occurred. Please try again.', 'danger')
    return render_template('add_challenge.html', logged_in=True, user_role=session['role'], user=session['user'])

@app.route('/enrolled_challenges', methods=['GET', 'POST'])
def enrolled_challenges():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            challenges = conn.execute('SELECT id, name FROM challenges').fetchall()
            if request.method == 'POST':
                challenge_id = request.form.get('challenge_id')
                date = request.form.get('date')
                start_time = request.form.get('start_time')
                end_time = request.form.get('end_time')
                if not all([challenge_id, date, start_time, end_time]):
                    flash('All fields are required', 'danger')
                    return render_template('enrolled_challenges.html', challenges=challenges, logged_in=True, user_role=session['role'], user=session['user'])
                challenge = conn.execute('SELECT name FROM challenges WHERE id = ?', (challenge_id,)).fetchone()
                if not challenge:
                    flash('Invalid challenge', 'danger')
                    return render_template('enrolled_challenges.html', challenges=challenges, logged_in=True, user_role=session['role'], user=session['user'])
                # Check if challenge is already enrolled and not expired
                existing = conn.execute('''
                    SELECT id FROM challenge_enrollments
                    WHERE challenge_id = ? AND end_time > ?
                ''', (challenge_id, datetime.now().strftime('%Y-%m-%d %H:%M:%S'))).fetchone()
                if existing:
                    flash('Challenge is already enrolled and not expired', 'danger')
                    return render_template('enrolled_challenges.html', challenges=challenges, logged_in=True, user_role=session['role'], user=session['user'])
                conn.execute('''
                    INSERT INTO challenge_enrollments (challenge_id, date, start_time, end_time)
                    VALUES (?, ?, ?, ?)
                ''', (challenge_id, date, start_time, end_time))
                conn.commit()
                # Notify users
                users = conn.execute('SELECT email FROM users').fetchall()
                html_body = f"""
                <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                    <h2 style="color: #2ecc71;">New Challenge Enrollment</h2>
                    <p>Challenge: {challenge['name']}</p>
                    <p>Date: {date}</p>
                    <p>Start Time: {start_time}</p>
                    <p>End Time: {end_time}</p>
                </div>
                """
                for user in users:
                    send_email(user['email'], "New Challenge Enrollment", f"New challenge enrolled: {challenge['name']}", html_body)
                flash('Challenge enrolled successfully', 'success')
                return redirect(url_for('admin_dashboard'))
        return render_template('enrolled_challenges.html', challenges=challenges, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"Enroll challenge error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/manage_admins', methods=['GET', 'POST'])
def manage_admins():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        email = sanitize_input(request.form.get('email'))
        password = request.form.get('password')
        if not all([email, password]):
            flash('All fields are required', 'danger')
            return render_template('manage_admins.html', logged_in=True, user_role=session['role'], user=session['user'])
        if not validate_email(email):
            flash('Invalid Gmail address', 'danger')
            return render_template('manage_admins.html', logged_in=True, user_role=session['role'], user=session['user'])
        if not validate_password(password):
            flash('Password must be at least 6 characters with uppercase, lowercase, digit, and special character', 'danger')
            return render_template('manage_admins.html', logged_in=True, user_role=session['role'], user=session['user'])
        try:
            with get_db_connection() as conn:
                existing_admin = conn.execute('SELECT * FROM admins WHERE email = ?', (email,)).fetchone()
                if existing_admin:
                    flash('Admin already exists', 'danger')
                    return render_template('manage_admins.html', logged_in=True, user_role=session['role'], user=session['user'])
                conn.execute('INSERT INTO admins (email, password, name, username) VALUES (?, ?, ?, ?)', 
                            (email, password, 'Admin', email.split('@')[0]))
                conn.commit()
            html_body = f"""
            <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                <h2 style="color: #2ecc71;">New Admin Account</h2>
                <p>Your admin account has been created.</p>
                <p>Email: {email}</p>
                <p>Password: {password}</p>
                <p>Please login at {url_for('login', _external=True)}.</p>
            </div>
            """
            send_email(email, "Admin Account Created", "Your admin account has been created.", html_body)
            flash('Admin added successfully', 'success')
            return redirect(url_for('admin_dashboard'))
        except Exception as e:
            logging.error(f"Add admin error: {e}")
            flash('An error occurred. Please try again.', 'danger')
    return render_template('manage_admins.html', logged_in=True, user_role=session['role'], user=session['user'])

@app.route('/view_users')
def view_users():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            users = conn.execute('SELECT id, name, email, username, profile_image, id_card_image FROM users').fetchall()
        return render_template('view_users.html', users=users, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"View users error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/delete_user/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            user = conn.execute('SELECT profile_image, id_card_image FROM users WHERE id = ?', (user_id,)).fetchone()
            if user:
                for img in [user['profile_image'], user['id_card_image']]:
                    if img and os.path.exists(img):
                        os.remove(img)
                conn.execute('DELETE FROM users WHERE id = ?', (user_id,))
                conn.commit()
                flash('User deleted successfully', 'success')
            else:
                flash('User not found', 'danger')
        return redirect(url_for('view_users'))
    except Exception as e:
        logging.error(f"Delete user error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('view_users'))

@app.route('/attempts')
def view_attempts():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            test_attempts = conn.execute('''
                SELECT ta.id, t.name as test_name, ta.date, u.name as user_name, u.college, u.hall_ticket, ta.score, ta.remarks
                FROM test_attempts ta
                JOIN tests t ON ta.test_id = t.id
                JOIN users u ON ta.user_id = u.id
            ''').fetchall()
            challenge_attempts = conn.execute('''
                SELECT ca.id, c.name as challenge_name, ca.date, u.name as user_name, u.college, u.hall_ticket, ca.score, ca.remarks
                FROM challenge_attempts ca
                JOIN challenges c ON ca.challenge_id = c.id
                JOIN users u ON ca.user_id = u.id
            ''').fetchall()
        return render_template('attempts.html', test_attempts=test_attempts, challenge_attempts=challenge_attempts, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"View attempts error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/view_tests')
def view_tests():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            tests = conn.execute('SELECT id, name, duration, description FROM tests').fetchall()
        return render_template('view_tests.html', tests=tests, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"View tests error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/view_challenges')
def view_challenges():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            challenges = conn.execute('SELECT id, name, duration, description FROM challenges').fetchall()
        return render_template('view_challenges.html', challenges=challenges, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"View challenges error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/test_page/<int:test_id>', methods=['GET', 'POST'])
def test_page(test_id):
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            test = conn.execute('SELECT id, name, duration FROM tests WHERE id = ?', (test_id,)).fetchone()
            if not test:
                flash('Test not found', 'danger')
                return redirect(url_for('user_dashboard'))
            enrollment = conn.execute('''
                SELECT id FROM test_enrollments
                WHERE test_id = ? AND user_id = ? AND end_time > ?
            ''', (test_id, session['user_id'], datetime.now().strftime('%Y-%m-%d %H:%M:%S'))).fetchone()
            if not enrollment:
                flash('Test not enrolled or expired', 'danger')
                return redirect(url_for('user_dashboard'))
            attempt = conn.execute('SELECT id FROM test_attempts WHERE test_id = ? AND user_id = ?', 
                                 (test_id, session['user_id'])).fetchone()
            if attempt:
                flash('Test already attempted', 'danger')
                return redirect(url_for('user_dashboard'))
            step = session.get('test_step', 1)
            if request.method == 'POST':
                if step == 1:
                    image_data = request.form.get('image_data')
                    if not image_data:
                        flash('Image capture required', 'danger')
                        return render_template('test_page.html', test=test, step=1, logged_in=True, user_role=session['role'], user=session['user'])
                    image_data = image_data.split(',')[1]
                    image_path = os.path.join(app.config['UPLOAD_FOLDER'], f"test_{test_id}_{session['user_id']}_{uuid.uuid4()}.jpg")
                    with open(image_path, 'wb') as f:
                        f.write(base64.b64decode(image_data))
                    adjust_image_brightness_contrast(image_path)
                    valid, msg = validate_image(image_path, enforce_face=True)
                    if not valid:
                        flash(f"Image validation failed: {msg}", 'danger')
                        os.remove(image_path)
                        return render_template('test_page.html', test=test, step=1, logged_in=True, user_role=session['role'], user=session['user'])
                    if not image_comparator.compare_images(image_path, session['user']['profile_image']):
                        flash('Face verification failed', 'danger')
                        os.remove(image_path)
                        return render_template('test_page.html', test=test, step=1, logged_in=True, user_role=session['role'], user=session['user'])
                    session['test_image'] = image_path
                    session['test_step'] = 2
                    return render_template('test_page.html', test=test, step=2, logged_in=True, user_role=session['role'], user=session['user'])
                elif step == 2:
                    # System checks are handled client-side (JS)
                    session['test_step'] = 3
                    return render_template('test_page.html', test=test, step=3, logged_in=True, user_role=session['role'], user=session['user'])
                elif step == 3:
                    session['test_step'] = 4
                    questions = conn.execute('SELECT id, question_text, option_1, option_2, option_3, option_4 FROM test_questions WHERE test_id = ?', 
                                           (test_id,)).fetchall()
                    session['test_questions'] = [(q['id'], q['question_text'], q['option_1'], q['option_2'], q['option_3'], q['option_4']) for q in questions]
                    session['test_start_time'] = time.time()
                    session['current_question'] = 0
                    return render_template('test_page.html', test=test, step=4, question=session['test_questions'][0], 
                                        question_index=0, total_questions=len(session['test_questions']), 
                                        time_per_question=60, logged_in=True, user_role=session['role'], user=session['user'])
                elif step == 4:
                    if 'error' in request.form:
                        session['test_paused'] = True
                        session['test_pause_time'] = time.time()
                        return jsonify({'status': 'paused'})
                    elif 'continue' in request.form:
                        session.pop('test_paused', None)
                        return jsonify({'status': 'continued'})
                    elif 'monitor' in request.form:
                        image_data = request.form.get('image_data')
                        if not image_data:
                            return jsonify({'error': 'No face detected'})
                        image_data = image_data.split(',')[1]
                        image_path = os.path.join(app.config['UPLOAD_FOLDER'], f"monitor_{test_id}_{session['user_id']}_{uuid.uuid4()}.jpg")
                        with open(image_path, 'wb') as f:
                            f.write(base64.b64decode(image_data))
                        adjust_image_brightness_contrast(image_path)
                        valid, msg = validate_image(image_path, enforce_face=True)
                        if not valid:
                            os.remove(image_path)
                            return jsonify({'error': msg})
                        if not image_comparator.compare_images(image_path, session['test_image']):
                            os.remove(image_path)
                            return jsonify({'error': 'Face verification failed'})
                        os.remove(image_path)
                        return jsonify({'status': 'ok'})
                    else:
                        answer = request.form.get('answer')
                        question_id = session['test_questions'][session['current_question']][0]
                        if answer:
                            conn.execute('INSERT INTO test_answers (attempt_id, question_id, answer) VALUES (?, ?, ?)', 
                                       (session.get('attempt_id'), question_id, int(answer)))
                            conn.commit()
                        session['current_question'] += 1
                        if session['current_question'] >= len(session['test_questions']):
                            # Evaluate test
                            attempt_id = session.get('attempt_id')
                            if not attempt_id:
                                cursor = conn.execute('INSERT INTO test_attempts (test_id, user_id, date, time) VALUES (?, ?, ?, ?)', 
                                                    (test_id, session['user_id'], datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 
                                                     int(time.time() - session['test_start_time'])))
                                attempt_id = cursor.lastrowid
                                session['attempt_id'] = attempt_id
                            answers = conn.execute('''
                                SELECT ta.answer, tq.correct_option
                                FROM test_answers ta
                                JOIN test_questions tq ON ta.question_id = tq.id
                                WHERE ta.attempt_id = ?
                            ''', (attempt_id,)).fetchall()
                            correct = sum(1 for ans in answers if ans['answer'] == ans['correct_option'])
                            total = len(answers)
                            score = (correct / total * 100) if total > 0 else 0
                            remarks = 'Pass' if score >= 60 else 'Fail'
                            conn.execute('UPDATE test_attempts SET score = ?, remarks = ? WHERE id = ?', 
                                       (score, remarks, attempt_id))
                            conn.commit()
                            # Generate badge if score >= 80
                            if score >= 80:
                                certificate_id = str(uuid.uuid4())
                                badge_path = generate_badge(test['name'], session['user']['name'], score, certificate_id, 'Achievement')
                                conn.execute('INSERT INTO achievements (certificate_id, user_name, test_name, score, type) VALUES (?, ?, ?, ?, ?)',
                                           (certificate_id, session['user']['name'], test['name'], score, 'Test'))
                                conn.commit()
                                send_email(session['user']['email'], "Achievement Badge", 
                                         f"Congratulations on scoring {score}% in {test['name']}!", 
                                         attachment_path=badge_path)
                            # Cleanup
                            if os.path.exists(session['test_image']):
                                os.remove(session['test_image'])
                            session.pop('test_step', None)
                            session.pop('test_image', None)
                            session.pop('test_questions', None)
                            session.pop('test_start_time', None)
                            session.pop('current_question', None)
                            session.pop('attempt_id', None)
                            flash('Test submitted successfully', 'success')
                            return redirect(url_for('my_learning'))
                        return render_template('test_page.html', test=test, step=4, 
                                            question=session['test_questions'][session['current_question']], 
                                            question_index=session['current_question'], 
                                            total_questions=len(session['test_questions']), 
                                            time_per_question=60, logged_in=True, user_role=session['role'], user=session['user'])
            if step == 1 and not session.get('attempt_id'):
                cursor = conn.execute('INSERT INTO test_attempts (test_id, user_id, date, time) VALUES (?, ?, ?, ?)', 
                                    (test_id, session['user_id'], datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 0))
                session['attempt_id'] = cursor.lastrowid
                conn.commit()
            return render_template('test_page.html', test=test, step=step, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"Test page error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('user_dashboard'))

@app.route('/challenge_page/<int:challenge_id>', methods=['GET', 'POST'])
def challenge_page(challenge_id):
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            challenge = conn.execute('SELECT id, name, duration FROM challenges WHERE id = ?', (challenge_id,)).fetchone()
            if not challenge:
                flash('Challenge not found', 'danger')
                return redirect(url_for('user_dashboard'))
            enrollment = conn.execute('''
                SELECT id FROM challenge_enrollments
                WHERE challenge_id = ? AND user_id = ? AND end_time > ?
            ''', (challenge_id, session['user_id'], datetime.now().strftime('%Y-%m-%d %H:%M:%S'))).fetchone()
            if not enrollment:
                flash('Challenge not enrolled or expired', 'danger')
                return redirect(url_for('user_dashboard'))
            attempt = conn.execute('SELECT id FROM challenge_attempts WHERE challenge_id = ? AND user_id = ?', 
                                 (challenge_id, session['user_id'])).fetchone()
            if attempt:
                flash('Challenge already attempted', 'danger')
                return redirect(url_for('user_dashboard'))
            step = session.get('challenge_step', 1)
            if request.method == 'POST':
                if step == 1:
                    image_data = request.form.get('image_data')
                    if not image_data:
                        flash('Image capture required', 'danger')
                        return render_template('challenge_page.html', challenge=challenge, step=1, logged_in=True, user_role=session['role'], user=session['user'])
                    image_data = image_data.split(',')[1]
                    image_path = os.path.join(app.config['UPLOAD_FOLDER'], f"challenge_{challenge_id}_{session['user_id']}_{uuid.uuid4()}.jpg")
                    with open(image_path, 'wb') as f:
                        f.write(base64.b64decode(image_data))
                    adjust_image_brightness_contrast(image_path)
                    valid, msg = validate_image(image_path, enforce_face=True)
                    if not valid:
                        flash(f"Image validation failed: {msg}", 'danger')
                        os.remove(image_path)
                        return render_template('challenge_page.html', challenge=challenge, step=1, logged_in=True, user_role=session['role'], user=session['user'])
                    if not image_comparator.compare_images(image_path, session['user']['profile_image']):
                        flash('Face verification failed', 'danger')
                        os.remove(image_path)
                        return render_template('challenge_page.html', challenge=challenge, step=1, logged_in=True, user_role=session['role'], user=session['user'])
                    session['challenge_image'] = image_path
                    session['challenge_step'] = 2
                    return render_template('challenge_page.html', challenge=challenge, step=2, logged_in=True, user_role=session['role'], user=session['user'])
                elif step == 2:
                    session['challenge_step'] = 3
                    return render_template('challenge_page.html', challenge=challenge, step=3, logged_in=True, user_role=session['role'], user=session['user'])
                elif step == 3:
                    session['challenge_step'] = 4
                    questions = conn.execute('SELECT id, question_text, question_type, correct_answer FROM challenge_questions WHERE challenge_id = ?', 
                                           (challenge_id,)).fetchall()
                    session['challenge_questions'] = [(q['id'], q['question_text'], q['question_type'], q['correct_answer']) for q in questions]
                    session['challenge_start_time'] = time.time()
                    session['current_question'] = 0
                    return render_template('challenge_page.html', challenge=challenge, step=4, 
                                        question=session['challenge_questions'][0], 
                                        question_index=0, total_questions=len(session['challenge_questions']), 
                                        time_per_question=60, logged_in=True, user_role=session['role'], user=session['user'])
                elif step == 4:
                    if 'error' in request.form:
                        session['challenge_paused'] = True
                        session['challenge_pause_time'] = time.time()
                        return jsonify({'status': 'paused'})
                    elif 'continue' in request.form:
                        session.pop('challenge_paused', None)
                        return jsonify({'status': 'continued'})
                    elif 'monitor' in request.form:
                        image_data = request.form.get('image_data')
                        if not image_data:
                            return jsonify({'error': 'No face detected'})
                        image_data = image_data.split(',')[1]
                        image_path = os.path.join(app.config['UPLOAD_FOLDER'], f"monitor_{challenge_id}_{session['user_id']}_{uuid.uuid4()}.jpg")
                        with open(image_path, 'wb') as f:
                            f.write(base64.b64decode(image_data))
                        adjust_image_brightness_contrast(image_path)
                        valid, msg = validate_image(image_path, enforce_face=True)
                        if not valid:
                            os.remove(image_path)
                            return jsonify({'error': msg})
                        if not image_comparator.compare_images(image_path, session['challenge_image']):
                            os.remove(image_path)
                            return jsonify({'error': 'Face verification failed'})
                        os.remove(image_path)
                        return jsonify({'status': 'ok'})
                    else:
                        audio_data = request.form.get('audio_data')
                        if audio_data:
                            audio_data = audio_data.split(',')[1]
                            audio_path = os.path.join(app.config['UPLOAD_FOLDER'], f"challenge_{challenge_id}_{session['user_id']}_{uuid.uuid4()}.wav")
                            with open(audio_path, 'wb') as f:
                                f.write(base64.b64decode(audio_data))
                            text, confidence = extract_text_from_audio(audio_path)
                            question_id = session['challenge_questions'][session['current_question']][0]
                            correct_answer = session['challenge_questions'][session['current_question']][3]
                            similarity = 1 - (levenshtein_distance(text.lower(), correct_answer.lower()) / max(len(text), len(correct_answer)))
                            score = similarity * 100
                            conn.execute('INSERT INTO challenge_answers (attempt_id, question_id, answer, score) VALUES (?, ?, ?, ?)', 
                                       (session.get('attempt_id'), question_id, text, score))
                            conn.commit()
                            if os.path.exists(audio_path):
                                os.remove(audio_path)
                        session['current_question'] += 1
                        if session['current_question'] >= len(session['challenge_questions']):
                            # Evaluate challenge
                            attempt_id = session.get('attempt_id')
                            if not attempt_id:
                                cursor = conn.execute('INSERT INTO challenge_attempts (challenge_id, user_id, date, time) VALUES (?, ?, ?, ?)', 
                                                    (challenge_id, session['user_id'], datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 
                                                     int(time.time() - session['challenge_start_time'])))
                                attempt_id = cursor.lastrowid
                                session['attempt_id'] = attempt_id
                            answers = conn.execute('SELECT score FROM challenge_answers WHERE attempt_id = ?', 
                                                 (attempt_id,)).fetchall()
                            total_score = sum(ans['score'] for ans in answers) / len(answers) if answers else 0
                            remarks = 'Pass' if total_score >= 60 else 'Fail'
                            conn.execute('UPDATE challenge_attempts SET score = ?, remarks = ? WHERE id = ?', 
                                       (total_score, remarks, attempt_id))
                            conn.commit()
                            # Generate badge if score >= 80
                            if total_score >= 80:
                                certificate_id = str(uuid.uuid4())
                                badge_path = generate_badge(challenge['name'], session['user']['name'], total_score, certificate_id, 'Achievement')
                                conn.execute('INSERT INTO achievements (certificate_id, user_name, test_name, score, type) VALUES (?, ?, ?, ?, ?)',
                                           (certificate_id, session['user']['name'], challenge['name'], total_score, 'Challenge'))
                                conn.commit()
                                send_email(session['user']['email'], "Achievement Badge", 
                                         f"Congratulations on scoring {total_score}% in {challenge['name']}!", 
                                         attachment_path=badge_path)
                            # Cleanup
                            if os.path.exists(session['challenge_image']):
                                os.remove(session['challenge_image'])
                            session.pop('challenge_step', None)
                            session.pop('challenge_image', None)
                            session.pop('challenge_questions', None)
                            session.pop('challenge_start_time', None)
                            session.pop('current_question', None)
                            session.pop('attempt_id', None)
                            flash('Challenge submitted successfully', 'success')
                            return redirect(url_for('my_learning'))
                        return render_template('challenge_page.html', challenge=challenge, step=4, 
                                            question=session['challenge_questions'][session['current_question']], 
                                            question_index=session['current_question'], 
                                            total_questions=len(session['challenge_questions']), 
                                            time_per_question=60, logged_in=True, user_role=session['role'], user=session['user'])
            if step == 1 and not session.get('attempt_id'):
                cursor = conn.execute('INSERT INTO challenge_attempts (challenge_id, user_id, date, time) VALUES (?, ?, ?, ?)', 
                                    (challenge_id, session['user_id'], datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 0))
                session['attempt_id'] = cursor.lastrowid
                conn.commit()
            return render_template('challenge_page.html', challenge=challenge, step=step, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"Challenge page error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('user_dashboard'))

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(app.config['CAPTCHA_FOLDER'], exist_ok=True)
    app.run(debug=True)


from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_file
import sqlite3
import os
from werkzeug.utils import secure_filename
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
import random
import time
import cv2
import numpy as np
from deepface import DeepFace
from skimage import io as skio
from skimage.filters import laplace
import speech_recognition as sr
import re
import datetime
import base64
from Levenshtein import distance as levenshtein_distance
import uuid
from PIL import Image, ImageDraw, ImageFont
import tensorflow as tf
from tensorflow.keras.applications.efficientnet import EfficientNetB0, preprocess_input
from sklearn.metrics.pairwise import cosine_similarity
import io
import json
import librosa
import noisereduce as nr
from pydub import AudioSegment
import logging
import html

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

app = Flask(__name__)
app.secret_key = os.urandom(24).hex()
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['CAPTCHA_FOLDER'] = 'static/captchas'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'wav', 'mp3'}

# Ensure directories exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['CAPTCHA_FOLDER'], exist_ok=True)

# Email configuration (replace with your credentials)
EMAIL_ADDRESS = 'your_email@gmail.com'
EMAIL_PASSWORD = 'your_app_password'

# Image comparison class with EfficientNetB0 and DeepFace
class ImageComparison:
    def __init__(self):
        try:
            self.efficientnet_model = EfficientNetB0(weights='imagenet', include_top=False, input_shape=(224, 224, 3))
            self.efficientnet_model = tf.keras.models.Model(inputs=self.efficientnet_model.input, outputs=self.efficientnet_model.output)
            logging.info("Successfully initialized EfficientNetB0")
        except Exception as e:
            logging.error(f"Error initializing EfficientNetB0: {e}")
            raise RuntimeError("Failed to initialize image comparison model")

    def preprocess_image(self, image_path, target_size=(224, 224)):
        try:
            img = Image.open(image_path).resize(target_size)
            img_array = np.array(img)
            img_array = np.expand_dims(img_array, axis=0)
            img_array = preprocess_input(img_array)
            return img_array
        except Exception as e:
            logging.error(f"Error preprocessing image: {e}")
            return None

    def get_efficientnet_features(self, image_path):
        img = self.preprocess_image(image_path)
        if img is None:
            return None
        features = self.efficientnet_model.predict(img, verbose=0)
        return features.flatten()

    def get_deepface_features(self, image_path):
        try:
            embedding = DeepFace.represent(img_path=image_path, model_name='Facenet', enforce_detection=True)
            return np.array(embedding[0]['embedding'])
        except Exception as e:
            logging.error(f"DeepFace error: {e}")
            return None

    def compare_images(self, image1_path, image2_path):
        eff_features1 = self.get_efficientnet_features(image1_path)
        eff_features2 = self.get_efficientnet_features(image2_path)
        deepface_features1 = self.get_deepface_features(image1_path)
        deepface_features2 = self.get_deepface_features(image2_path)
        if eff_features1 is None or eff_features2 is None:
            return False
        results = {}
        results['efficientnet_cosine'] = cosine_similarity([eff_features1], [eff_features2])[0][0]
        if deepface_features1 is not None and deepface_features2 is not None:
            results['deepface_cosine'] = cosine_similarity([deepface_features1], [deepface_features2])[0][0]
        else:
            results['deepface_cosine'] = None
        thresholds = {'efficientnet_cosine': 0.85, 'deepface_cosine': 0.7}
        weights = {'efficientnet_cosine': 0.6, 'deepface_cosine': 0.4}
        score = weights['efficientnet_cosine'] * results['efficientnet_cosine']
        if results['deepface_cosine'] is not None:
            score += weights['deepface_cosine'] * results['deepface_cosine']
        return score > 0.75

    def analyze_background(self, image_path):
        try:
            img = skio.imread(image_path)
            gray = skio.color.rgb2gray(img)
            edges = laplace(gray)
            edge_density = np.mean(np.abs(edges))
            if edge_density > 0.1:
                return False, "Background is too cluttered"
            return True, ""
        except Exception as e:
            return False, f"Background analysis failed: {str(e)}"

image_comparator = ImageComparison()

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def validate_image(image_path, enforce_face=True):
    try:
        img = skio.imread(image_path)
        gray = skio.color.rgb2gray(img)
        brightness = np.mean(gray) * 255
        if brightness < 60:
            return False, "Image is too dark"
        laplacian_var = laplace(gray).var()
        if laplacian_var < 100:
            return False, "Image is too blurry"
        if enforce_face:
            faces = DeepFace.extract_faces(img_path=image_path, detector_backend='opencv', enforce_detection=False)
            face_count = len(faces)
            if face_count != 1:
                return False, f"Exactly one face must be detected, found {face_count}"
        valid_bg, bg_msg = image_comparator.analyze_background(image_path)
        if not valid_bg:
            return False, bg_msg
        return True, ""
    except Exception as e:
        logging.error(f"Image validation failed: {e}")
        return False, f"Image validation failed: {str(e)}"

def adjust_image_brightness_contrast(image_path):
    try:
        img = cv2.imread(image_path)
        img_yuv = cv2.cvtColor(img, cv2.COLOR_BGR2YUV)
        img_yuv[:,:,0] = cv2.equalizeHist(img_yuv[:,:,0])
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))
        l = clahe.apply(l)
        lab = cv2.merge((l,a,b))
        img_adjusted = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)
        result = cv2.cvtColor(img_adjusted, cv2.COLOR_BGR2LAB)
        avg_a = np.average(result[:, :, 1])
        avg_b = np.average(result[:, :, 2])
        result[:, :, 1] = result[:, :, 1] - ((avg_a - 128) * (result[:, :, 0] / 255.0) * 1.1)
        result[:, :, 2] = result[:, :, 2] - ((avg_b - 128) * (result[:, :, 0] / 255.0) * 1.1)
        img_adjusted = cv2.cvtColor(result, cv2.COLOR_LAB2BGR)
        cv2.imwrite(image_path, img_adjusted)
    except Exception as e:
        logging.error(f"Image adjustment failed: {e}")

def enhance_audio(audio_path):
    try:
        audio = AudioSegment.from_file(audio_path)
        normalized_audio = audio.normalize()
        y, sr = librosa.load(audio_path)
        reduced_noise = nr.reduce_noise(y=y, sr=sr)
        enhanced_path = audio_path.replace('.wav', '_enhanced.wav')
        librosa.output.write_wav(enhanced_path, reduced_noise, sr)
        return enhanced_path
    except Exception as e:
        logging.error(f"Audio enhancement failed: {e}")
        return audio_path

def extract_text_from_audio(audio_path):
    try:
        enhanced_path = enhance_audio(audio_path)
        recognizer = sr.Recognizer()
        with sr.AudioFile(enhanced_path) as source:
            audio_data = recognizer.record(source)
            text = recognizer.recognize_google(audio_data, show_all=True)
            if isinstance(text, dict) and 'alternative' in text:
                return text['alternative'][0]['transcript'].lower(), text['alternative'][0]['confidence']
            return text.lower(), 0.0
    except Exception as e:
        logging.error(f"Audio transcription failed: {e}")
        return "", 0.0

def generate_badge(test_name, user_name, score, certificate_id, achievement_type):
    colors = [
        {'bg': '#e8f4f8', 'border': '#0288d1', 'text': '#01579b'},
        {'bg': '#f0f4c3', 'border': '#689f38', 'text': '#33691e'},
        {'bg': '#fce4ec', 'border': '#d81b60', 'text': '#880e4f'}
    ]
    color = random.choice(colors)
    img = Image.new('RGB', (800, 600), color=color['bg'])
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype('static/fonts/arial.ttf', 40)
        small_font = ImageFont.truetype('static/fonts/arial.ttf', 30)
        tiny_font = ImageFont.truetype('static/fonts/arial.ttf', 20)
    except:
        font = ImageFont.load_default()
        small_font = ImageFont.load_default()
        tiny_font = ImageFont.load_default()
    draw.rectangle([(50, 50), (750, 550)], outline=color['border'], width=5)
    draw.text((400, 100), f"Certificate of {achievement_type}", font=font, fill=color['text'], anchor='mm')
    draw.text((400, 200), f"{user_name}", font=small_font, fill=color['text'], anchor='mm')
    draw.text((400, 250), f"Successfully Completed", font=small_font, fill=color['text'], anchor='mm')
    draw.text((400, 300), f"{test_name}", font=small_font, fill=color['text'], anchor='mm')
    draw.text((400, 350), f"Score: {score}%", font=small_font, fill=color['text'], anchor='mm')
    draw.text((400, 400), f"Certificate ID: {certificate_id}", font=small_font, fill=color['text'], anchor='mm')
    draw.text((400, 500), "Issued by: E-Exam", font=tiny_font, fill=color['text'], anchor='mm')
    badge_path = os.path.join(app.config['UPLOAD_FOLDER'], f"badge_{certificate_id}.png")
    img.save(badge_path)
    return badge_path

def send_email(to_email, subject, body, html_body=None, attachment_path=None):
    msg = MIMEMultipart()
    msg['From'] = EMAIL_ADDRESS
    msg['To'] = to_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))
    if html_body:
        msg.attach(MIMEText(html_body, 'html'))
    if attachment_path:
        try:
            with open(attachment_path, 'rb') as f:
                img = MIMEImage(f.read())
                img.add_header('Content-Disposition', 'attachment', filename=os.path.basename(attachment_path))
                msg.attach(img)
        except Exception as e:
            logging.error(f"Failed to attach file to email: {e}")
    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        server.sendmail(EMAIL_ADDRESS, to_email, msg.as_string())
        server.quit()
        return True
    except Exception as e:
        logging.error(f"Email sending failed: {e}")
        return False

def validate_password(password):
    return (len(password) >= 6 and
            re.search(r"[A-Z]", password) and
            re.search(r"[a-z]", password) and
            re.search(r"\d", password) and
            re.search(r"[!@#$%^&*(),.?\":{}|<>]", password))

def validate_email(email):
    return bool(re.match(r'^[a-zA-Z0-9._%+-]+@gmail\.com$', email))

def validate_mobile(mobile):
    return len(mobile) == 10 and mobile.isdigit()

def sanitize_input(input_str):
    return html.escape(str(input_str).strip())

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

def generate_captcha():
    captcha_text = str(random.randint(10000, 99999))
    captcha_filename = f"captcha_{uuid.uuid4()}.png"
    captcha_path = os.path.join(app.config['CAPTCHA_FOLDER'], captcha_filename)
    
    try:
        img = Image.new('RGB', (250, 80), color=(255, 255, 255))
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype('static/fonts/arial.ttf', 40)
        except:
            font = ImageFont.load_default()
        
        # Add noise and lines
        for _ in range(15):
            x1, y1 = random.randint(0, 250), random.randint(0, 80)
            x2, y2 = random.randint(0, 250), random.randint(0, 80)
            color = (random.randint(100, 200), random.randint(100, 200), random.randint(100, 200))
            draw.line((x1, y1, x2, y2), fill=color, width=2)
        for _ in range(100):
            x, y = random.randint(0, 250), random.randint(0, 80)
            color = (random.randint(100, 200), random.randint(100, 200), random.randint(100, 200))
            draw.point((x, y), fill=color)
        
        # Draw text with random colors and rotations
        colors = [(0, 51, 102), (102, 0, 51), (0, 102, 51), (102, 51, 0)]
        for i, char in enumerate(captcha_text):
            x = 30 + i * 40
            y = 40
            angle = random.uniform(-15, 15)
            offset_x = random.uniform(-5, 5)
            offset_y = random.uniform(-5, 5)
            char_color = random.choice(colors)
            char_img = Image.new('RGBA', (40, 40), (0, 0, 0, 0))
            char_draw = ImageDraw.Draw(char_img)
            char_draw.text((10, 10), char, font=font, fill=char_color + (255,))
            char_img = char_img.rotate(angle, expand=1)
            img.paste(char_img, (int(x + offset_x), int(y + offset_y)), char_img)
        
        img.save(captcha_path)
    except Exception as e:
        logging.error(f"Failed to generate CAPTCHA: {e}")
        raise RuntimeError("CAPTCHA generation failed")
    
    # Clean up old CAPTCHA files
    try:
        now = time.time()
        for f in os.listdir(app.config['CAPTCHA_FOLDER']):
            f_path = os.path.join(app.config['CAPTCHA_FOLDER'], f)
            if os.path.isfile(f_path) and now - os.path.getmtime(f_path) > 3600:
                os.remove(f_path)
                logging.info(f"Removed old CAPTCHA file: {f_path}")
    except Exception as e:
        logging.error(f"Failed to clean up CAPTCHA files: {e}")
    
    return captcha_text, captcha_filename

@app.route('/')
def index():
    return render_template('index.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/about')
def about():
    return render_template('about.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        email = sanitize_input(request.form.get('email'))
        subject = sanitize_input(request.form.get('subject'))
        message = sanitize_input(request.form.get('message'))
        if not all([email, subject, message]):
            flash('All fields are required', 'danger')
            return render_template('contact.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
        if not validate_email(email):
            flash('Invalid Gmail address', 'danger')
            return render_template('contact.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
        try:
            with get_db_connection() as conn:
                conn.execute('INSERT INTO queries (email, subject, message) VALUES (?, ?, ?)', (email, subject, message))
                conn.commit()
            html_body = """
            <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                <h2 style="color: #2ecc71;">Query Received</h2>
                <p>Thank you for contacting us. We have received your query and will respond soon.</p>
            </div>
            """
            send_email(email, "Query Received", "Successfully sent your query. We will check it soon.", html_body)
            send_email('admin@gmail.com', "New Query", f"Email: {email}\nSubject: {subject}\nMessage: {message}")
            flash('Query submitted successfully', 'success')
            return redirect(url_for('contact'))
        except Exception as e:
            logging.error(f"Failed to process contact form: {e}")
            flash('An error occurred. Please try again.', 'danger')
    return render_template('contact.html', logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/login', methods=['GET', 'POST'])
def login():
    captcha_text, captcha_filename = generate_captcha()
    session['captcha_text'] = captcha_text
    if request.method == 'POST':
        captcha_answer = request.form.get('captcha_answer', '').strip()
        if captcha_answer != session.get('captcha_text'):
            flash('Invalid CAPTCHA', 'danger')
            return render_template('login.html', captcha_image=captcha_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
        email = sanitize_input(request.form.get('email'))
        password = request.form.get('password')
        role = request.form.get('role')
        if not all([email, password, role]):
            flash('All fields are required', 'danger')
            return render_template('login.html', captcha_image=captcha_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
        if not validate_email(email):
            flash('Invalid Gmail address', 'danger')
            return render_template('login.html', captcha_image=captcha_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
        try:
            with get_db_connection() as conn:
                if role == 'user':
                    user = conn.execute('SELECT * FROM users WHERE email = ? AND password = ?', (email, password)).fetchone()
                else:
                    user = conn.execute('SELECT * FROM admins WHERE email = ? AND password = ?', (email, password)).fetchone()
                if user:
                    session['user_id'] = user['id']
                    session['role'] = role
                    session['user'] = {
                        'profile_image': user['profile_image'] if role == 'user' else 'static/images/default_admin.png',
                        'username': user['username'],
                        'hall_ticket': user.get('hall_ticket', ''),
                        'name': user['name']
                    }
                    flash('Login successful', 'success')
                    return redirect(url_for('user_dashboard') if role == 'user' else url_for('admin_dashboard'))
                else:
                    flash('Invalid email or password', 'danger')
        except Exception as e:
            logging.error(f"Login error: {e}")
            flash('An error occurred. Please try again.', 'danger')
    return render_template('login.html', captcha_image=captcha_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    step = 1
    email = ''
    captcha_text, captcha_filename = generate_captcha()
    session['captcha_text'] = captcha_text
    if request.method == 'POST':
        captcha_answer = request.form.get('captcha_answer', '').strip()
        if captcha_answer != session.get('captcha_text'):
            flash('Invalid CAPTCHA', 'danger')
            return render_template('forgot_password.html', step=step, email=email, captcha_image=captcha_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
        if 'email' in request.form:
            email = sanitize_input(request.form.get('email'))
            if not validate_email(email):
                flash('Invalid Gmail address', 'danger')
                return render_template('forgot_password.html', step=step, email=email, captcha_image=captcha_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            try:
                with get_db_connection() as conn:
                    user = conn.execute('SELECT * FROM users WHERE email = ?', (email,)).fetchone()
                    if user:
                        otp = str(random.randint(100000, 999999))
                        session['otp'] = otp
                        session['otp_email'] = email
                        session['otp_time'] = time.time()
                        html_body = f"""
                        <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                            <h2 style="color: #2ecc71;">Password Reset OTP</h2>
                            <p>Your OTP is <strong>{otp}</strong>. It is valid for 5 minutes.</p>
                        </div>
                        """
                        send_email(email, "Password Reset OTP", f"Your OTP is {otp}", html_body)
                        step = 2
                    else:
                        flash('Email not found', 'danger')
            except Exception as e:
                logging.error(f"Forgot password error: {e}")
                flash('An error occurred. Please try again.', 'danger')
        elif 'otp' in request.form:
            otp = request.form.get('otp').strip()
            if 'resend' in request.form:
                otp = str(random.randint(100000, 999999))
                session['otp'] = otp
                session['otp_time'] = time.time()
                html_body = f"""
                <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                    <h2 style="color: #2ecc71;">Password Reset OTP</h2>
                    <p>Your new OTP is <strong>{otp}</strong>. It is valid for 5 minutes.</p>
                </div>
                """
                send_email(session['otp_email'], "Password Reset OTP", f"Your OTP is {otp}", html_body)
                flash('OTP resent', 'success')
            elif otp == session.get('otp') and time.time() - session.get('otp_time') < 300:
                return redirect(url_for('reset_password'))
            else:
                flash('Invalid or expired OTP', 'danger')
    remaining_time = 300 - (time.time() - session.get('otp_time', time.time()))
    return render_template('forgot_password.html', step=step, email=email, captcha_image=captcha_filename, remaining_time=remaining_time, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    if 'otp_email' not in session:
        flash('Session expired. Please start over.', 'danger')
        return redirect(url_for('forgot_password'))
    captcha_text, captcha_filename = generate_captcha()
    session['captcha_text'] = captcha_text
    if request.method == 'POST':
        captcha_answer = request.form.get('captcha_answer', '').strip()
        if captcha_answer != session.get('captcha_text'):
            flash('Invalid CAPTCHA', 'danger')
            return render_template('reset_password.html', captcha_image=captcha_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
        elif not validate_password(password):
            flash('Password must be at least 6 characters with uppercase, lowercase, digit, and special character', 'danger')
        else:
            try:
                with get_db_connection() as conn:
                    conn.execute('UPDATE users SET password = ? WHERE email = ?', (password, session['otp_email']))
                    conn.commit()
                flash('Password reset successfully', 'success')
                session.clear()  # Clear all session data to prevent profile logo
                return redirect(url_for('login'))
            except Exception as e:
                logging.error(f"Reset password error: {e}")
                flash('An error occurred. Please try again.', 'danger')
    return render_template('reset_password.html', captcha_image=captcha_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/register', methods=['GET', 'POST'])
def register():
    captcha_text, captcha_filename = generate_captcha()
    session['captcha_text'] = captcha_text
    step = session.get('register_step', 1)
    if request.method == 'POST':
        captcha_answer = request.form.get('captcha_answer', '').strip()
        if captcha_answer != session.get('captcha_text'):
            flash('Invalid CAPTCHA', 'danger')
            return render_template('register.html', data=session.get('register_data', {}), captcha_image=captcha_filename, step=step, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
        if step == 1:
            data = {
                'name': sanitize_input(request.form.get('name', '')),
                'email': sanitize_input(request.form.get('email', '')),
                'username': sanitize_input(request.form.get('username', '')),
                'mobile': sanitize_input(request.form.get('mobile', '')),
                'degree': sanitize_input(request.form.get('degree', '')),
                'course': sanitize_input(request.form.get('course', '')),
                'college': sanitize_input(request.form.get('college', '')),
                'branch': sanitize_input(request.form.get('branch', '')),
                'hall_ticket': sanitize_input(request.form.get('hall_ticket', '')),
                'semester': sanitize_input(request.form.get('semester', '')),
                'cgpa': sanitize_input(request.form.get('cgpa', '')),
                'location': sanitize_input(request.form.get('location', '')),
                'address': sanitize_input(request.form.get('address', '')),
                'state': sanitize_input(request.form.get('state', '')),
                'terms': request.form.get('terms', '')
            }
            if data['terms'] != 'on':
                flash('You must agree to the terms and conditions', 'danger')
                return render_template('register.html', data=data, captcha_image=captcha_filename, step=1, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            if not all([data['name'], data['email'], data['username'], data['mobile'], data['degree'], data['course'], data['college'], data['branch'], data['hall_ticket'], data['semester'], data['cgpa'], data['location'], data['address'], data['state']]):
                flash('All fields are required', 'danger')
                return render_template('register.html', data=data, captcha_image=captcha_filename, step=1, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            if not validate_email(data['email']):
                flash('Email must be a valid Gmail address', 'danger')
                return render_template('register.html', data=data, captcha_image=captcha_filename, step=1, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            if not validate_mobile(data['mobile']):
                flash('Mobile number must be exactly 10 digits', 'danger')
                return render_template('register.html', data=data, captcha_image=captcha_filename, step=1, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            try:
                with get_db_connection() as conn:
                    existing_user = conn.execute('SELECT * FROM users WHERE email = ? OR username = ?', (data['email'], data['username'])).fetchone()
                    if existing_user:
                        flash('Email or username already exists', 'danger')
                        return render_template('register.html', data=data, captcha_image=captcha_filename, step=1, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
                session['register_data'] = data
                session['register_step'] = 2
                flash('Please capture or upload profile and ID card images', 'info')
                return render_template('register.html', data=data, captcha_image=captcha_filename, step=2, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            except Exception as e:
                logging.error(f"Registration step 1 error: {e}")
                flash('An error occurred. Please try again.', 'danger')
        elif step == 2:
            profile_image_data = request.form.get('profile_image_data', '')
            id_card_image_data = request.form.get('id_card_image_data', '')
            profile_file = request.files.get('profile_image')
            id_card_file = request.files.get('id_card_image')
            profile_path = id_card_path = profile_filename = id_card_filename = None
            if profile_file and allowed_file(profile_file.filename):
                profile_filename = secure_filename(profile_file.filename)
                profile_path = os.path.join(app.config['UPLOAD_FOLDER'], f"profile_{session['register_data']['username']}_{uuid.uuid4()}_{profile_filename}")
                profile_file.save(profile_path)
                adjust_image_brightness_contrast(profile_path)
                valid, msg = validate_image(profile_path, enforce_face=True)
                if not valid:
                    flash(f"Profile image: {msg}", 'danger')
                    return render_template('register.html', data=session['register_data'], captcha_image=captcha_filename, step=2, profile_filename=profile_filename, id_card_filename=id_card_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            elif profile_image_data:
                try:
                    profile_image_data = profile_image_data.split(',')[1]
                    profile_filename = f"profile_{session['register_data']['username']}_{uuid.uuid4()}.jpg"
                    profile_path = os.path.join(app.config['UPLOAD_FOLDER'], profile_filename)
                    with open(profile_path, 'wb') as f:
                        f.write(base64.b64decode(profile_image_data))
                    adjust_image_brightness_contrast(profile_path)
                    valid, msg = validate_image(profile_path, enforce_face=True)
                    if not valid:
                        flash(f"Profile image: {msg}", 'danger')
                        return render_template('register.html', data=session['register_data'], captcha_image=captcha_filename, step=2, profile_filename=profile_filename, id_card_filename=id_card_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
                except Exception as e:
                    logging.error(f"Profile image processing error: {e}")
                    flash('Failed to process profile image', 'danger')
                    return render_template('register.html', data=session['register_data'], captcha_image=captcha_filename, step=2, profile_filename=profile_filename, id_card_filename=id_card_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            if id_card_file and allowed_file(id_card_file.filename):
                id_card_filename = secure_filename(id_card_file.filename)
                id_card_path = os.path.join(app.config['UPLOAD_FOLDER'], f"id_card_{session['register_data']['username']}_{uuid.uuid4()}_{id_card_filename}")
                id_card_file.save(id_card_path)
                adjust_image_brightness_contrast(id_card_path)
                valid, msg = validate_image(id_card_path, enforce_face=False)
                if not valid:
                    flash(f"ID card image: {msg}", 'danger')
                    return render_template('register.html', data=session['register_data'], captcha_image=captcha_filename, step=2, profile_filename=profile_filename, id_card_filename=id_card_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            elif id_card_image_data:
                try:
                    id_card_image_data = id_card_image_data.split(',')[1]
                    id_card_filename = f"id_card_{session['register_data']['username']}_{uuid.uuid4()}.jpg"
                    id_card_path = os.path.join(app.config['UPLOAD_FOLDER'], id_card_filename)
                    with open(id_card_path, 'wb') as f:
                        f.write(base64.b64decode(id_card_image_data))
                    adjust_image_brightness_contrast(id_card_path)
                    valid, msg = validate_image(id_card_path, enforce_face=False)
                    if not valid:
                        flash(f"ID card image: {msg}", 'danger')
                        return render_template('register.html', data=session['register_data'], captcha_image=captcha_filename, step=2, profile_filename=profile_filename, id_card_filename=id_card_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
                except Exception as e:
                    logging.error(f"ID card image processing error: {e}")
                    flash('Failed to process ID card image', 'danger')
                    return render_template('register.html', data=session['register_data'], captcha_image=captcha_filename, step=2, profile_filename=profile_filename, id_card_filename=id_card_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            if not profile_path or not id_card_path:
                flash('Both profile and ID card images are required', 'danger')
                return render_template('register.html', data=session['register_data'], captcha_image=captcha_filename, step=2, profile_filename=profile_filename, id_card_filename=id_card_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
            session['profile_path'] = profile_path
            session['id_card_path'] = id_card_path
            otp = str(random.randint(100000, 999999))
            session['otp'] = otp
            session['otp_email'] = session['register_data']['email']
            session['otp_time'] = time.time()
            html_body = f"""
            <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                <h2 style="color: #2ecc71;">Registration OTP</h2>
                <p>Your OTP is <strong>{otp}</strong>. It is valid for 5 minutes.</p>
            </div>
            """
            if send_email(session['register_data']['email'], "Registration OTP", f"Your OTP is {otp}", html_body):
                session['register_step'] = 3
                flash('Please verify OTP', 'info')
                return redirect(url_for('verify_otp'))
            else:
                flash('Failed to send OTP. Please try again.', 'danger')
                return render_template('register.html', data=session['register_data'], captcha_image=captcha_filename, step=2, profile_filename=profile_filename, id_card_filename=id_card_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
    return render_template('register.html', data=session.get('register_data', {}), captcha_image=captcha_filename, step=step, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/verify_otp', methods=['GET', 'POST'])
def verify_otp():
    captcha_text, captcha_filename = generate_captcha()
    session['captcha_text'] = captcha_text
    if 'otp_email' not in session:
        flash('Session expired. Please start over.', 'danger')
        return redirect(url_for('register'))
    if request.method == 'POST':
        captcha_answer = request.form.get('captcha_answer', '').strip()
        if captcha_answer != session.get('captcha_text'):
            flash('Invalid CAPTCHA', 'danger')
            return render_template('verify_otp.html', captcha_image=captcha_filename, remaining_time=300 - (time.time() - session.get('otp_time', time.time())), logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
        otp = request.form.get('otp').strip()
        if 'resend' in request.form:
            otp = str(random.randint(100000, 999999))
            session['otp'] = otp
            session['otp_time'] = time.time()
            html_body = f"""
            <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                <h2 style="color: #2ecc71;">Registration OTP</h2>
                <p>Your new OTP is <strong>{otp}</strong>. It is valid for 5 minutes.</p>
            </div>
            """
            send_email(session['otp_email'], "Registration OTP", f"Your OTP is {otp}", html_body)
            flash('OTP resent', 'success')
        elif otp == session.get('otp') and time.time() - session.get('otp_time') < 300:
            session['register_step'] = 4
            return redirect(url_for('set_password'))
        else:
            flash('Invalid or expired OTP', 'danger')
    return render_template('verify_otp.html', captcha_image=captcha_filename, remaining_time=300 - (time.time() - session.get('otp_time', time.time())), logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/set_password', methods=['GET', 'POST'])
def set_password():
    captcha_text, captcha_filename = generate_captcha()
    session['captcha_text'] = captcha_text
    if 'otp_email' not in session or 'register_data' not in session:
        flash('Session expired. Please start over.', 'danger')
        return redirect(url_for('register'))
    if request.method == 'POST':
        captcha_answer = request.form.get('captcha_answer', '').strip()
        if captcha_answer != session.get('captcha_text'):
            flash('Invalid CAPTCHA', 'danger')
            return render_template('set_password.html', captcha_image=captcha_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
        elif not validate_password(password):
            flash('Password must be at least 6 characters with uppercase, lowercase, digit, and special character', 'danger')
        else:
            try:
                with get_db_connection() as conn:
                    data = session['register_data']
                    conn.execute('''INSERT INTO users (name, email, username, mobile, degree, course, college, branch, hall_ticket, semester, cgpa, location, address, state, profile_image, id_card_image, password)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                                    (data['name'], data['email'], data['username'], data['mobile'], data['degree'], data['course'], data['college'], data['branch'], data['hall_ticket'], data['semester'], data['cgpa'], data['location'], data['address'], data['state'], session['profile_path'], session['id_card_path'], password))
                    conn.commit()
                flash('Registration successful. Please login.', 'success')
                session.clear()  # Clear all session data to prevent profile logo
                return redirect(url_for('login'))
            except Exception as e:
                logging.error(f"Set password error: {e}")
                flash('An error occurred. Please try again.', 'danger')
    return render_template('set_password.html', captcha_image=captcha_filename, logged_in='user_id' in session, user_role=session.get('role'), user=session.get('user', {}))

@app.route('/user_dashboard')
def user_dashboard():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            tests = conn.execute('''
                SELECT t.id, t.name, t.duration, t.description, te.date, te.start_time, te.end_time
                FROM tests t
                JOIN test_enrollments te ON t.id = te.test_id
                LEFT JOIN test_attempts ta ON t.id = ta.test_id AND ta.user_id = ?
                WHERE te.user_id = ? AND ta.id IS NULL AND te.end_time > ?
            ''', (session['user_id'], session['user_id'], datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))).fetchall()
            challenges = conn.execute('''
                SELECT c.id, c.name, c.duration, c.description, ce.date, ce.start_time, ce.end_time
                FROM challenges c
                JOIN challenge_enrollments ce ON c.id = ce.challenge_id
                LEFT JOIN challenge_attempts ca ON c.id = ca.challenge_id AND ca.user_id = ?
                WHERE ce.user_id = ? AND ca.id IS NULL AND ce.end_time > ?
            ''', (session['user_id'], session['user_id'], datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))).fetchall()
        return render_template('user_dashboard.html', tests=tests, challenges=challenges, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"User dashboard error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('login'))

@app.route('/my_learning')
def my_learning():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            test_attempts = conn.execute('''
                SELECT ta.id, t.name, ta.score, ta.date, ta.remarks, 'Test' as type
                FROM test_attempts ta
                JOIN tests t ON ta.test_id = t.id
                WHERE ta.user_id = ?
            ''', (session['user_id'],)).fetchall()
            challenge_attempts = conn.execute('''
                SELECT ca.id, c.name, ca.score, ca.date, ca.remarks, 'Challenge' as type
                FROM challenge_attempts ca
                JOIN challenges c ON ca.challenge_id = c.id
                WHERE ca.user_id = ?
            ''', (session['user_id'],)).fetchall()
            attempts = test_attempts + challenge_attempts
            achievements = conn.execute('SELECT * FROM achievements WHERE user_name = ?', (session['user']['name'],)).fetchall()
        return render_template('my_learning.html', attempts=attempts, achievements=achievements, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"My learning error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('login'))

@app.route('/attempt_details/<string:type>/<int:attempt_id>')
def attempt_details(attempt_id, type):
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            if type == 'Test':
                attempt = conn.execute('''
                    SELECT ta.id, t.name, ta.score, ta.date, ta.remarks
                    FROM test_attempts ta
                    JOIN tests t ON ta.test_id = t.id
                    WHERE ta.id = ? AND ta.user_id = ?
                ''', (attempt_id, session['user_id'])).fetchone()
                answers = conn.execute('''
                    SELECT tq.question_text, tq.option_1, tq.option_2, tq.option_3, tq.option_4, tq.correct_option, ta.answer
                    FROM test_answers ta
                    JOIN test_questions tq ON ta.question_id = tq.id
                    WHERE ta.attempt_id = ?
                ''', (attempt_id,)).fetchall()
                correct = sum(1 for ans in answers if ans['answer'] == ans['correct_option'])
                total = len(answers)
                wrong = total - correct
            else:
                attempt = conn.execute('''
                    SELECT ca.id, c.name, ca.score, ca.date, ca.remarks
                    FROM challenge_attempts ca
                    JOIN challenges c ON ca.challenge_id = c.id
                    WHERE ca.id = ? AND ca.user_id = ?
                ''', (attempt_id, session['user_id'])).fetchone()
                answers = conn.execute('''
                    SELECT cq.question_text, cq.correct_answer, ca.answer, ca.score
                    FROM challenge_answers ca
                    JOIN challenge_questions cq ON ca.question_id = cq.id
                    WHERE ca.attempt_id = ?
                ''', (attempt_id,)).fetchall()
                correct = sum(1 for ans in answers if ans['score'] > 80)
                total = len(answers)
                wrong = total - correct
            if not attempt:
                flash('Attempt not found', 'danger')
                return redirect(url_for('my_learning'))
            stats = {
                'correct_percentage': (correct / total * 100) if total > 0 else 0,
                'wrong_percentage': (wrong / total * 100) if total > 0 else 0,
                'score': attempt['score']
            }
        return render_template('attempt_details.html', attempt=attempt, answers=answers, stats=stats, type=type, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"Attempt details error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('my_learning'))

@app.route('/download_badge/<string:certificate_id>')
def download_badge(certificate_id):
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        badge_path = os.path.join(app.config['UPLOAD_FOLDER'], f"badge_{certificate_id}.png")
        if os.path.exists(badge_path):
            return send_file(badge_path, as_attachment=True, download_name=f"badge_{certificate_id}.png")
        flash('Badge not found', 'danger')
        return redirect(url_for('my_learning'))
    except Exception as e:
        logging.error(f"Download badge error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('my_learning'))

@app.route('/attendance')
def attendance():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            test_attempts = conn.execute('''
                SELECT t.name, ta.date, t.duration, ta.score, ta.time, 'Test' as type
                FROM test_attempts ta
                JOIN tests t ON ta.test_id = t.id
                WHERE ta.user_id = ?
            ''', (session['user_id'],)).fetchall()
            challenge_attempts = conn.execute('''
                SELECT c.name, ca.date, c.duration, ca.score, ca.time, 'Challenge' as type
                FROM challenge_attempts ca
                JOIN challenges c ON ca.challenge_id = c.id
                WHERE ca.user_id = ?
            ''', (session['user_id'],)).fetchall()
            attempts = test_attempts + challenge_attempts
        return render_template('attendance.html', attempts=attempts, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"Attendance error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('login'))

@app.route('/material')
def material():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    courses = [
        {'name': 'Python Basics', 'notes': 'python_notes.pdf', 'recording': 'python_session.mp4'},
        {'name': 'Java Fundamentals', 'notes': 'java_notes.pdf', 'recording': 'java_session.mp4'},
        {'name': 'Verbal Ability', 'notes': 'verbal_notes.pdf', 'recording': 'verbal_session.mp4'},
    ]
    return render_template('material.html', courses=courses, logged_in=True, user_role=session['role'], user=session['user'])

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
            if request.method == 'POST':
                if 'update_profile' in request.form:
                    data = {
                        'name': sanitize_input(request.form.get('name')),
                        'mobile': sanitize_input(request.form.get('mobile')),
                        'degree': sanitize_input(request.form.get('degree')),
                        'course': sanitize_input(request.form.get('course')),
                        'college': sanitize_input(request.form.get('college')),
                        'branch': sanitize_input(request.form.get('branch')),
                        'hall_ticket': sanitize_input(request.form.get('hall_ticket')),
                        'semester': sanitize_input(request.form.get('semester')),
                        'cgpa': sanitize_input(request.form.get('cgpa')),
                        'location': sanitize_input(request.form.get('location')),
                        'address': sanitize_input(request.form.get('address')),
                        'state': sanitize_input(request.form.get('state')),
                    }
                    if not all(data.values()):
                        flash('All fields are required', 'danger')
                    elif not validate_mobile(data['mobile']):
                        flash('Mobile number must be exactly 10 digits', 'danger')
                    else:
                        conn.execute('''UPDATE users SET name = ?, mobile = ?, degree = ?, course = ?, college = ?, branch = ?, hall_ticket = ?, semester = ?, cgpa = ?, location = ?, address = ?, state = ?
                                        WHERE id = ?''', (*data.values(), session['user_id']))
                        conn.commit()
                        session['user']['name'] = data['name']
                        flash('Profile updated successfully', 'success')
                elif 'update_password' in request.form:
                    password = request.form.get('password')
                    confirm_password = request.form.get('confirm_password')
                    if password != confirm_password:
                        flash('Passwords do not match', 'danger')
                    elif not validate_password(password):
                        flash('Password must be at least 6 characters with uppercase, lowercase, digit, and special character', 'danger')
                    else:
                        conn.execute('UPDATE users SET password = ? WHERE id = ?', (password, session['user_id']))
                        conn.commit()
                        flash('Password updated successfully', 'success')
            user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
        return render_template('profile.html', user=user, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"Profile error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('login'))

@app.route('/admin_dashboard')
def admin_dashboard():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    return render_template('admin_dashboard.html', logged_in=True, user_role=session['role'], user=session['user'])

@app.route('/add_test', methods=['GET', 'POST'])
def add_test():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        name = sanitize_input(request.form.get('name'))
        questions = []
        i = 0
        while f'question_{i}' in request.form:
            question_text = sanitize_input(request.form.get(f'question_{i}'))
            option_1 = sanitize_input(request.form.get(f'option_1_{i}'))
            option_2 = sanitize_input(request.form.get(f'option_2_{i}'))
            option_3 = sanitize_input(request.form.get(f'option_3_{i}'))
            option_4 = sanitize_input(request.form.get(f'option_4_{i}'))
            correct_option = int(request.form.get(f'correct_option_{i}'))
            if all([question_text, option_1, option_2, option_3, option_4]) and correct_option in [1, 2, 3, 4]:
                questions.append((question_text, option_1, option_2, option_3, option_4, correct_option))
            i += 1
        if not name or not questions:
            flash('Test name and at least one valid question are required', 'danger')
            return render_template('add_test.html', logged_in=True, user_role=session['role'], user=session['user'])
        try:
            with get_db_connection() as conn:
                duration = len(questions) * 60  # 1 minute per question
                conn.execute('INSERT INTO tests (name, duration, description) VALUES (?, ?, ?)', (name, duration, f"Test on {name}"))
                test_id = conn.execute('SELECT last_insert_rowid()').fetchone()[0]
                conn.executemany('INSERT INTO test_questions (test_id, question_text, option_1, option_2, option_3, option_4, correct_option) VALUES (?, ?, ?, ?, ?, ?, ?)',
                                 [(test_id, *q) for q in questions])
                conn.commit()
            flash('Test added successfully', 'success')
            return redirect(url_for('admin_dashboard'))
        except Exception as e:
            logging.error(f"Add test error: {e}")
            flash('An error occurred. Please try again.', 'danger')
    return render_template('add_test.html', logged_in=True, user_role=session['role'], user=session['user'])

@app.route('/enrolled_tests', methods=['GET', 'POST'])
def enrolled_tests():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        test_id = request.form.get('test_id')
        date = request.form.get('date')
        start_time = request.form.get('start_time')
        end_time = request.form.get('end_time')
        if not all([test_id, date, start_time, end_time]):
            flash('All fields are required', 'danger')
        else:
            try:
                with get_db_connection() as conn:
                    test = conn.execute('SELECT name FROM tests WHERE id = ?', (test_id,)).fetchone()
                    users = conn.execute('SELECT email FROM users').fetchall()
                    for user in users:
                        conn.execute('INSERT OR IGNORE INTO test_enrollments (user_id, test_id, date, start_time, end_time) VALUES ((SELECT id FROM users WHERE email = ?), ?, ?, ?, ?)',
                                     (user['email'], test_id, date, start_time, end_time))
                        html_body = f"""
                        <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                            <h2 style="color: #2ecc71;">Test Enrollment</h2>
                            <p>You have been enrolled in {test['name']}.</p>
                            <p>Date: {date}</p>
                            <p>Start Time: {start_time}</p>
                            <p>End Time: {end_time}</p>
                        </div>
                        """
                        send_email(user['email'], "Test Enrollment", f"You have been enrolled in {test['name']}.", html_body)
                    conn.commit()
                flash('Test enrolled successfully', 'success')
                return redirect(url_for('admin_dashboard'))
            except Exception as e:
                logging.error(f"Enroll test error: {e}")
                flash('An error occurred. Please try again.', 'danger')
    try:
        with get_db_connection() as conn:
            tests = conn.execute('SELECT id, name FROM tests').fetchall()
        return render_template('enrolled_tests.html', tests=tests, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"Enroll test error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/add_challenge', methods=['GET', 'POST'])
def add_challenge():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        name = sanitize_input(request.form.get('name'))
        questions = []
        i = 0
        while f'question_{i}' in request.form:
            question_text = sanitize_input(request.form.get(f'question_{i}'))
            question_type = sanitize_input(request.form.get(f'question_type_{i}'))
            correct_answer = sanitize_input(request.form.get(f'correct_answer_{i}'))
            if all([question_text, question_type, correct_answer]):
                questions.append((question_text, question_type, correct_answer))
            i += 1
        if not name or not questions:
            flash('Challenge name and at least one valid question are required', 'danger')
            return render_template('add_challenge.html', logged_in=True, user_role=session['role'], user=session['user'])
        try:
            with get_db_connection() as conn:
                duration = len(questions) * 60  # 1 minute per question
                conn.execute('INSERT INTO challenges (name, duration, description) VALUES (?, ?, ?)', (name, duration, f"Challenge on {name}"))
                challenge_id = conn.execute('SELECT last_insert_rowid()').fetchone()[0]
                conn.executemany('INSERT INTO challenge_questions (challenge_id, question_text, question_type, correct_answer) VALUES (?, ?, ?, ?)',
                                 [(challenge_id, *q) for q in questions])
                conn.commit()
            flash('Challenge added successfully', 'success')
            return redirect(url_for('admin_dashboard'))
        except Exception as e:
            logging.error(f"Add challenge error: {e}")
            flash('An error occurred. Please try again.', 'danger')
    return render_template('add_challenge.html', logged_in=True, user_role=session['role'], user=session['user'])

@app.route('/enrolled_challenges', methods=['GET', 'POST'])
def enrolled_challenges():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        challenge_id = request.form.get('challenge_id')
        date = request.form.get('date')
        start_time = request.form.get('start_time')
        end_time = request.form.get('end_time')
        if not all([challenge_id, date, start_time, end_time]):
            flash('All fields are required', 'danger')
        else:
            try:
                with get_db_connection() as conn:
                    challenge = conn.execute('SELECT name FROM challenges WHERE id = ?', (challenge_id,)).fetchone()
                    users = conn.execute('SELECT email FROM users').fetchall()
                    for user in users:
                        conn.execute('INSERT OR IGNORE INTO challenge_enrollments (user_id, challenge_id, date, start_time, end_time) VALUES ((SELECT id FROM users WHERE email = ?), ?, ?, ?, ?)',
                                     (user['email'], challenge_id, date, start_time, end_time))
                        html_body = f"""
                        <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                            <h2 style="color: #2ecc71;">Challenge Enrollment</h2>
                            <p>You have been enrolled in {challenge['name']}.</p>
                            <p>Date: {date}</p>
                            <p>Start Time: {start_time}</p>
                            <p>End Time: {end_time}</p>
                        </div>
                        """
                        send_email(user['email'], "Challenge Enrollment", f"You have been enrolled in {challenge['name']}.", html_body)
                    conn.commit()
                flash('Challenge enrolled successfully', 'success')
                return redirect(url_for('admin_dashboard'))
            except Exception as e:
                logging.error(f"Enroll challenge error: {e}")
                flash('An error occurred. Please try again.', 'danger')
    try:
        with get_db_connection() as conn:
            challenges = conn.execute('SELECT id, name FROM challenges').fetchall()
        return render_template('enrolled_challenges.html', challenges=challenges, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"Enroll challenge error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/manage_admins', methods=['GET', 'POST'])
def manage_admins():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    if request.method == 'POST':
        email = sanitize_input(request.form.get('email'))
        password = request.form.get('password')
        name = sanitize_input(request.form.get('name'))
        username = sanitize_input(request.form.get('username'))
        if not all([email, password, name, username]):
            flash('All fields are required', 'danger')
        elif not validate_email(email):
            flash('Invalid Gmail address', 'danger')
        elif not validate_password(password):
            flash('Password must be at least 6 characters with uppercase, lowercase, digit, and special character', 'danger')
        else:
            try:
                with get_db_connection() as conn:
                    existing_admin = conn.execute('SELECT * FROM admins WHERE email = ? OR username = ?', (email, username)).fetchone()
                    if existing_admin:
                        flash('Email or username already exists', 'danger')
                    else:
                        conn.execute('INSERT INTO admins (email, password, name, username) VALUES (?, ?, ?, ?)', (email, password, name, username))
                        conn.commit()
                        html_body = f"""
                        <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                            <h2 style="color: #2ecc71;">Admin Account Created</h2>
                            <p>Welcome, {name}! Your admin account has been created.</p>
                            <p>Email: {email}</p>
                            <p>Username: {username}</p>
                            <p>Please login at <a href="{url_for('login', _external=True)}">Login</a>.</p>
                        </div>
                        """
                        send_email(email, "Admin Account Created", f"Your admin account has been created. Email: {email}, Username: {username}", html_body)
                        flash('Admin added successfully', 'success')
                        return redirect(url_for('admin_dashboard'))
            except Exception as e:
                logging.error(f"Add admin error: {e}")
                flash('An error occurred. Please try again.', 'danger')
    return render_template('manage_admins.html', logged_in=True, user_role=session['role'], user=session['user'])

@app.route('/view_users')
def view_users():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            users = conn.execute('SELECT id, name, email, username, profile_image, id_card_image FROM users').fetchall()
        return render_template('view_users.html', users=users, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"View users error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/delete_user/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            user = conn.execute('SELECT profile_image, id_card_image FROM users WHERE id = ?', (user_id,)).fetchone()
            if user:
                if user['profile_image'] and os.path.exists(user['profile_image']):
                    os.remove(user['profile_image'])
                if user['id_card_image'] and os.path.exists(user['id_card_image']):
                    os.remove(user['id_card_image'])
                conn.execute('DELETE FROM users WHERE id = ?', (user_id,))
                conn.commit()
                flash('User deleted successfully', 'success')
            else:
                flash('User not found', 'danger')
        return redirect(url_for('view_users'))
    except Exception as e:
        logging.error(f"Delete user error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('view_users'))

@app.route('/view_attempts')
def view_attempts():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            test_attempts = conn.execute('''
                SELECT ta.id, t.name, ta.date, u.name as user_name, u.college, u.hall_ticket, ta.score, ta.remarks, 'Test' as type
                FROM test_attempts ta
                JOIN tests t ON ta.test_id = t.id
                JOIN users u ON ta.user_id = u.id
            ''').fetchall()
            challenge_attempts = conn.execute('''
                SELECT ca.id, c.name, ca.date, u.name as user_name, u.college, u.hall_ticket, ca.score, ca.remarks, 'Challenge' as type
                FROM challenge_attempts ca
                JOIN challenges c ON ca.challenge_id = c.id
                JOIN users u ON ca.user_id = u.id
            ''').fetchall()
            attempts = test_attempts + challenge_attempts
        return render_template('attempts.html', attempts=attempts, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"View attempts error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/view_tests')
def view_tests():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            tests = conn.execute('SELECT id, name, duration, description FROM tests').fetchall()
        return render_template('view_tests.html', tests=tests, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"View tests error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/view_challenges')
def view_challenges():
    if 'user_id' not in session or session['role'] != 'admin':
        flash('Please login as an admin.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            challenges = conn.execute('SELECT id, name, duration, description FROM challenges').fetchall()
        return render_template('view_challenges.html', challenges=challenges, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"View challenges error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('admin_dashboard'))

@app.route('/test_page/<int:test_id>', methods=['GET', 'POST'])
def test_page(test_id):
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            test = conn.execute('SELECT id, name, duration FROM tests WHERE id = ?', (test_id,)).fetchone()
            if not test:
                flash('Test not found', 'danger')
                return redirect(url_for('user_dashboard'))
            enrollment = conn.execute('SELECT * FROM test_enrollments WHERE test_id = ? AND user_id = ? AND end_time > ?',
                                     (test_id, session['user_id'], datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))).fetchone()
            if not enrollment:
                flash('You are not enrolled or the test has expired', 'danger')
                return redirect(url_for('user_dashboard'))
            attempt = conn.execute('SELECT id FROM test_attempts WHERE test_id = ? AND user_id = ?', (test_id, session['user_id'])).fetchone()
            if attempt:
                flash('You have already attempted this test', 'danger')
                return redirect(url_for('user_dashboard'))
            questions = conn.execute('SELECT id, question_text, option_1, option_2, option_3, option_4, correct_option FROM test_questions WHERE test_id = ?', (test_id,)).fetchall()
            if not questions:
                flash('No questions available for this test', 'danger')
                return redirect(url_for('user_dashboard'))
            step = session.get(f'test_step_{test_id}', 1)
            if request.method == 'POST':
                if step == 1:
                    image_data = request.form.get('image_data')
                    if not image_data:
                        flash('Please capture an image', 'danger')
                    else:
                        try:
                            image_data = image_data.split(',')[1]
                            image_filename = f"test_{test_id}_{session['user_id']}_{uuid.uuid4()}.jpg"
                            image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
                            with open(image_path, 'wb') as f:
                                f.write(base64.b64decode(image_data))
                            adjust_image_brightness_contrast(image_path)
                            valid, msg = validate_image(image_path, enforce_face=True)
                            if not valid:
                                flash(f"Image verification failed: {msg}", 'danger')
                            else:
                                user = conn.execute('SELECT profile_image FROM users WHERE id = ?', (session['user_id'],)).fetchone()
                                if not image_comparator.compare_images(user['profile_image'], image_path):
                                    flash('Face does not match registered profile', 'danger')
                                else:
                                    session[f'test_image_{test_id}'] = image_path
                                    session[f'test_step_{test_id}'] = 2
                                    flash('Image verified successfully', 'success')
                        except Exception as e:
                            logging.error(f"Test image verification error: {e}")
                            flash('Failed to process image', 'danger')
                elif step == 4:
                    answers = []
                    start_time = session.get(f'test_start_time_{test_id}', time.time())
                    for q in questions:
                        answer = request.form.get(f'answer_{q["id"]}')
                        if answer:
                            answers.append((q['id'], int(answer)))
                    if not answers:
                        flash('No answers submitted', 'danger')
                    else:
                        score = 0
                        for q in questions:
                            user_answer = next((a[1] for a in answers if a[0] == q['id']), None)
                            if user_answer and user_answer == q['correct_option']:
                                score += 100 / len(questions)
                        remarks = "Completed" if len(answers) == len(questions) else "Incomplete"
                        time_taken = int(time.time() - start_time)
                        conn.execute('INSERT INTO test_attempts (user_id, test_id, score, date, remarks, time) VALUES (?, ?, ?, ?, ?, ?)',
                                     (session['user_id'], test_id, score, datetime.datetime.now().strftime('%Y-%m-%d'), remarks, time_taken))
                        attempt_id = conn.execute('SELECT last_insert_rowid()').fetchone()[0]
                        conn.executemany('INSERT INTO test_answers (attempt_id, question_id, answer) VALUES (?, ?, ?)',
                                         [(attempt_id, q_id, ans) for q_id, ans in answers])
                        conn.commit()
                        if score >= 80:
                            certificate_id = str(uuid.uuid4())
                            badge_path = generate_badge(test['name'], session['user']['name'], score, certificate_id, "Test")
                            conn.execute('INSERT INTO achievements (user_name, type, date, certificate_id, score) VALUES (?, ?, ?, ?, ?)',
                                         (session['user']['name'], 'Test', datetime.datetime.now().strftime('%Y-%m-%d'), certificate_id, score))
                            conn.commit()
                            html_body = f"""
                            <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                                <h2 style="color: #2ecc71;">Congratulations!</h2>
                                <p>You have earned a badge for {test['name']} with a score of {score}%.</p>
                                <p>Certificate ID: {certificate_id}</p>
                            </div>
                            """
                            send_email(session['user']['email'], "Test Badge", f"Congratulations! You earned a badge for {test['name']}.", html_body, badge_path)
                        flash('Test submitted successfully', 'success')
                        session.pop(f'test_step_{test_id}', None)
                        session.pop(f'test_image_{test_id}', None)
                        session.pop(f'test_start_time_{test_id}', None)
                        return redirect(url_for('my_learning'))
                return redirect(url_for('test_page', test_id=test_id))
            if step == 1:
                return render_template('test_page.html', test=test, questions=questions, step=1, logged_in=True, user_role=session['role'], user=session['user'])
            elif step == 2:
                return render_template('test_page.html', test=test, questions=questions, step=2, logged_in=True, user_role=session['role'], user=session['user'])
            elif step == 3:
                session[f'test_start_time_{test_id}'] = time.time()
                session[f'test_step_{test_id}'] = 4
                return render_template('test_page.html', test=test, questions=questions, step=3, logged_in=True, user_role=session['role'], user=session['user'])
            elif step == 4:
                return render_template('test_page.html', test=test, questions=questions, step=4, total_time=test['duration'], question_time=60, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"Test page error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('user_dashboard'))

@app.route('/challenge_page/<int:challenge_id>', methods=['GET', 'POST'])
def challenge_page(challenge_id):
    if 'user_id' not in session or session['role'] != 'user':
        flash('Please login as a user.', 'danger')
        return redirect(url_for('login'))
    try:
        with get_db_connection() as conn:
            challenge = conn.execute('SELECT id, name, duration FROM challenges WHERE id = ?', (challenge_id,)).fetchone()
            if not challenge:
                flash('Challenge not found', 'danger')
                return redirect(url_for('user_dashboard'))
            enrollment = conn.execute('SELECT * FROM challenge_enrollments WHERE challenge_id = ? AND user_id = ? AND end_time > ?',
                                     (challenge_id, session['user_id'], datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))).fetchone()
            if not enrollment:
                flash('You are not enrolled or the challenge has expired', 'danger')
                return redirect(url_for('user_dashboard'))
            attempt = conn.execute('SELECT id FROM challenge_attempts WHERE challenge_id = ? AND user_id = ?', (challenge_id, session['user_id'])).fetchone()
            if attempt:
                flash('You have already attempted this challenge', 'danger')
                return redirect(url_for('user_dashboard'))
            questions = conn.execute('SELECT id, question_text, question_type, correct_answer FROM challenge_questions WHERE challenge_id = ?', (challenge_id,)).fetchall()
            if not questions:
                flash('No questions available for this challenge', 'danger')
                return redirect(url_for('user_dashboard'))
            step = session.get(f'challenge_step_{challenge_id}', 1)
            if request.method == 'POST':
                if step == 1:
                    image_data = request.form.get('image_data')
                    if not image_data:
                        flash('Please capture an image', 'danger')
                    else:
                        try:
                            image_data = image_data.split(',')[1]
                            image_filename = f"challenge_{challenge_id}_{session['user_id']}_{uuid.uuid4()}.jpg"
                            image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
                            with open(image_path, 'wb') as f:
                                f.write(base64.b64decode(image_data))
                            adjust_image_brightness_contrast(image_path)
                            valid, msg = validate_image(image_path, enforce_face=True)
                            if not valid:
                                flash(f"Image verification failed: {msg}", 'danger')
                            else:
                                user = conn.execute('SELECT profile_image FROM users WHERE id = ?', (session['user_id'],)).fetchone()
                                if not image_comparator.compare_images(user['profile_image'], image_path):
                                    flash('Face does not match registered profile', 'danger')
                                else:
                                    session[f'challenge_image_{challenge_id}'] = image_path
                                    session[f'challenge_step_{challenge_id}'] = 2
                                    flash('Image verified successfully', 'success')
                        except Exception as e:
                            logging.error(f"Challenge image verification error: {e}")
                            flash('Failed to process image', 'danger')
                elif step == 4:
                    answers = []
                    start_time = session.get(f'challenge_start_time_{challenge_id}', time.time())
                    for q in questions:
                        audio_data = request.form.get(f'audio_data_{q["id"]}')
                        if audio_data:
                            try:
                                audio_data = audio_data.split(',')[1]
                                audio_filename = f"challenge_{challenge_id}_{q['id']}_{uuid.uuid4()}.wav"
                                audio_path = os.path.join(app.config['UPLOAD_FOLDER'], audio_filename)
                                with open(audio_path, 'wb') as f:
                                    f.write(base64.b64decode(audio_data))
                                transcribed_text, confidence = extract_text_from_audio(audio_path)
                                correct_answer = q['correct_answer'].lower()
                                max_len = max(len(transcribed_text), len(correct_answer))
                                similarity = 100 * (1 - levenshtein_distance(transcribed_text, correct_answer) / max_len) if max_len > 0 else 0
                                answers.append((q['id'], audio_path, transcribed_text, similarity))
                            except Exception as e:
                                logging.error(f"Audio processing error for question {q['id']}: {e}")
                                answers.append((q['id'], None, "", 0))
                    if not answers:
                        flash('No answers submitted', 'danger')
                    else:
                        score = sum(a[3] for a in answers) / len(answers)
                        remarks = "Completed" if len(answers) == len(questions) else "Incomplete"
                        time_taken = int(time.time() - start_time)
                        conn.execute('INSERT INTO challenge_attempts (user_id, challenge_id, score, date, remarks, time) VALUES (?, ?, ?, ?, ?, ?)',
                                     (session['user_id'], challenge_id, score, datetime.datetime.now().strftime('%Y-%m-%d'), remarks, time_taken))
                        attempt_id = conn.execute('SELECT last_insert_rowid()').fetchone()[0]
                        conn.executemany('INSERT INTO challenge_answers (attempt_id, question_id, answer, audio_path, score) VALUES (?, ?, ?, ?, ?)',
                                         [(attempt_id, q_id, text, path, sim) for q_id, path, text, sim in answers])
                        conn.commit()
                        if score >= 80:
                            certificate_id = str(uuid.uuid4())
                            badge_path = generate_badge(challenge['name'], session['user']['name'], score, certificate_id, "Challenge")
                            conn.execute('INSERT INTO achievements (user_name, type, date, certificate_id, score) VALUES (?, ?, ?, ?, ?)',
                                         (session['user']['name'], 'Challenge', datetime.datetime.now().strftime('%Y-%m-%d'), certificate_id, score))
                            conn.commit()
                            html_body = f"""
                            <div style="font-family: Arial, sans-serif; padding: 20px; background: #ecf0f1;">
                                <h2 style="color: #2ecc71;">Congratulations!</h2>
                                <p>You have earned a badge for {challenge['name']} with a score of {score}%.</p>
                                <p>Certificate ID: {certificate_id}</p>
                            </div>
                            """
                            send_email(session['user']['email'], "Challenge Badge", f"Congratulations! You earned a badge for {challenge['name']}.", html_body, badge_path)
                        flash('Challenge submitted successfully', 'success')
                        session.pop(f'challenge_step_{challenge_id}', None)
                        session.pop(f'challenge_image_{challenge_id}', None)
                        session.pop(f'challenge_start_time_{challenge_id}', None)
                        return redirect(url_for('my_learning'))
                return redirect(url_for('challenge_page', challenge_id=challenge_id))
            if step == 1:
                return render_template('challenge_page.html', challenge=challenge, questions=questions, step=1, logged_in=True, user_role=session['role'], user=session['user'])
            elif step == 2:
                return render_template('challenge_page.html', challenge=challenge, questions=questions, step=2, logged_in=True, user_role=session['role'], user=session['user'])
            elif step == 3:
                session[f'challenge_start_time_{challenge_id}'] = time.time()
                session[f'challenge_step_{challenge_id}'] = 4
                return render_template('challenge_page.html', challenge=challenge, questions=questions, step=3, logged_in=True, user_role=session['role'], user=session['user'])
            elif step == 4:
                return render_template('challenge_page.html', challenge=challenge, questions=questions, step=4, total_time=challenge['duration'], question_time=60, logged_in=True, user_role=session['role'], user=session['user'])
    except Exception as e:
        logging.error(f"Challenge page error: {e}")
        flash('An error occurred. Please try again.', 'danger')
        return redirect(url_for('user_dashboard'))

@app.route('/check_system/<string:type>/<int:id>', methods=['POST'])
def check_system(type, id):
    if 'user_id' not in session or session['role'] != 'user':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    checks = {
        'webcam': request.json.get('webcam', False),
        'microphone': request.json.get('microphone', False),
        'network': request.json.get('network', False),
        'fullscreen': request.json.get('fullscreen', False),
        'browser': request.json.get('browser', False)
    }
    all_passed = all(checks.values())
    if all_passed:
        session[f'{type}_step_{id}'] = 3
    return jsonify({'success': all_passed, 'checks': checks})

@app.route('/verify_image/<string:type>/<int:id>', methods=['POST'])
def verify_image(type, id):
    if 'user_id' not in session or session['role'] != 'user':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    try:
        with get_db_connection() as conn:
            user = conn.execute('SELECT profile_image FROM users WHERE id = ?', (session['user_id'],)).fetchone()
            image_data = request.json.get('image_data')
            if not image_data:
                return jsonify({'success': False, 'message': 'No image provided'})
            image_data = image_data.split(',')[1]
            image_filename = f"monitor_{type}_{id}_{uuid.uuid4()}.jpg"
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
            with open(image_path, 'wb') as f:
                f.write(base64.b64decode(image_data))
            adjust_image_brightness_contrast(image_path)
            valid, msg = validate_image(image_path, enforce_face=True)
            if not valid:
                return jsonify({'success': False, 'message': msg})
            if not image_comparator.compare_images(user['profile_image'], image_path):
                return jsonify({'success': False, 'message': 'Face does not match registered profile'})
            return jsonify({'success': True})
    except Exception as e:
        logging.error(f"Image verification error: {e}")
        return jsonify({'success': False, 'message': 'Verification failed'})

@app.route('/submit_answer/<string:type>/<int:id>/<int:question_id>', methods=['POST'])
def submit_answer(type, id, question_id):
    if 'user_id' not in session or session['role'] != 'user':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    try:
        with get_db_connection() as conn:
            if type == 'test':
                answer = request.json.get('answer')
                if answer:
                    session.setdefault(f'test_answers_{id}', []).append((question_id, int(answer)))
            else:
                audio_data = request.json.get('audio_data')
                if audio_data:
                    audio_data = audio_data.split(',')[1]
                    audio_filename = f"challenge_{id}_{question_id}_{uuid.uuid4()}.wav"
                    audio_path = os.path.join(app.config['UPLOAD_FOLDER'], audio_filename)
                    with open(audio_path, 'wb') as f:
                        f.write(base64.b64decode(audio_data))
                    transcribed_text, confidence = extract_text_from_audio(audio_path)
                    question = conn.execute('SELECT correct_answer FROM challenge_questions WHERE id = ?', (question_id,)).fetchone()
                    correct_answer = question['correct_answer'].lower()
                    max_len = max(len(transcribed_text), len(correct_answer))
                    similarity = 100 * (1 - levenshtein_distance(transcribed_text, correct_answer) / max_len) if max_len > 0 else 0
                    session.setdefault(f'challenge_answers_{id}', []).append((question_id, audio_path, transcribed_text, similarity))
            return jsonify({'success': True})
    except Exception as e:
        logging.error(f"Submit answer error: {e}")
        return jsonify({'success': False, 'message': 'Submission failed'})

@app.route('/pause_test/<string:type>/<int:id>', methods=['POST'])
def pause_test(type, id):
    if 'user_id' not in session or session['role'] != 'user':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    session[f'{type}_paused_{id}'] = True
    session[f'{type}_pause_time_{id}'] = time.time()
    return jsonify({'success': True})

@app.route('/resume_test/<string:type>/<int:id>', methods=['POST'])
def resume_test(type, id):
    if 'user_id' not in session or session['role'] != 'user':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    session.pop(f'{type}_paused_{id}', None)
    session.pop(f'{type}_pause_time_{id}', None)
    return jsonify({'success': True})

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'success')
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
